#!/usr/bin/env bash
set -euo pipefail
# Run from a directory containing extracted part_* files grouped as below.
# Usage example: mkdir restore && cd restore; extract all 10_*.tar.gz parts here, then cat part_00 part_01 ...

rebuild() {
  out="$1"; shift
  cat "$@" > "$out"
}

# Expected original hashes:
# data/curated/pa.parquet             39de683b558294111ad847aef50aa627a75c1f5062a8c92a34caefd28f6099ae
# features/v1/game_features.parquet   e553a4c068f52ea4b6b775628d649fe945b551aa3469ea19df0a319d0334202f
# features/v1.1/game_features.parquet a04531d916bdd96f7753bb0630f11d42edec4a275591d3d204cb04287355b0a6

echo "Extract each multipart family into its own directory, then concatenate part_00 part_01 ... in numeric order."
echo "Verify with sha256sum against MANIFEST.txt."

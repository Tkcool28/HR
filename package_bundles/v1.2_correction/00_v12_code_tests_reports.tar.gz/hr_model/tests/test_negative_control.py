"""
test_negative_control.py — Proves the v1.2 review test suite would FAIL
on the original buggy code. This is a one-shot demonstration, not a
permanent test (so it's not part of the v1.2 test suite proper).

It manually constructs the original "shared-ECT" bug and runs the
synthetic-pitcher test against it. Expected outcome: 3 fails.
"""
from __future__ import annotations
import os
import sys
import pandas as pd
import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "features", "v1.2"))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from test_no_lookahead_v12 import build_synthetic_target


# ---------------------------------------------------------------------------
# Re-implement the BUGGY v1.2 compute_pitcher_pitch_usage (shared ECT).
# In the original v1.2, a single ECT was built over ALL pitch types
# combined, then `sub` filtering by pitch_type was done at the rollup
# level (but never threaded into the rollup). All per-PT numerators
# ended up equal.
# ---------------------------------------------------------------------------
def compute_pitcher_pitch_usage_BUGGY(pl: pd.DataFrame, targets: pd.DataFrame,
                                       window: pd.Timedelta, cap: pd.Timestamp,
                                       pt_codes: list[str]) -> dict:
    """Buggy version that uses a single shared ECT for all pitch types."""
    from build_features import EntityCumTables
    pl_local = pl[pl["is_supported"] == 1].copy()
    pl_local["n"] = np.int8(1)
    p_agg = pl_local.groupby(["pitcher_id", "game_date", "pitch_type"],
                              sort=False, as_index=False)["n"].sum()
    p_tot = p_agg.groupby(["pitcher_id", "game_date"],
                          sort=False, as_index=False)["n"].sum()
    p_tot = p_tot.rename(columns={"n": "n_total"})
    # One ECT over the union
    ect_total = EntityCumTables(p_tot, entity_col="pitcher_id",
                                  date_col="game_date")
    targets_p = targets[["pitcher_id", "game_date"]].copy()
    s_tot, _ = ect_total.rollup(targets_p, "n_total", window, cap)
    targets["_n_total"] = s_tot
    raw_counts = {}
    for pt in pt_codes:
        # The original buggy code filtered AFTER the rollup, so the
        # numerator is actually the rollup of the FULL aggregate, not
        # the per-PT subset.
        raw_counts[pt] = float(targets["_n_total"].iloc[0])
    return raw_counts


# Build synthetic data
ROOT = "/workspace/hr_model"
PL_V12 = os.path.join(ROOT, "data/curated/pitch_level_v12.parquet")
pl = pd.read_parquet(PL_V12)
pl["game_date"] = pd.to_datetime(pl["game_date"])
target_date = pd.Timestamp("2018-07-15")
pt_codes = ["FF", "SI", "SL", "CH", "CU", "FC", "ST", "KC", "FS"]
HOLDOUT_CAP = pd.Timestamp("2024-12-31")

# Synthetic A: FF-dominant
raw_a = {"FF": 70, "SL": 20, "CH": 10}
pl_a = build_synthetic_target(pl, pitcher_id=900_001,
                                target_date=target_date, raw_mix=raw_a)
targets_a = pd.DataFrame({"pitcher_id": [900_001],
                            "game_date": [target_date]})
out_a_buggy = compute_pitcher_pitch_usage_BUGGY(pl_a, targets_a.copy(),
                                                 pd.Timedelta(days=30),
                                                 HOLDOUT_CAP, pt_codes)
print("Buggy output for A (FF=70, SL=20, CH=10):")
for pt in pt_codes:
    if out_a_buggy[pt] > 0:
        print(f"  {pt}: {out_a_buggy[pt]}")
# All should be equal (bug)
all_equal_a = all(out_a_buggy[pt] == out_a_buggy["FF"] for pt in pt_codes)
print(f"All PTs equal? {all_equal_a}  (this is the bug)")

# Synthetic B: SL-dominant
raw_b = {"SL": 65, "FF": 25, "CH": 10}
pl_b = build_synthetic_target(pl, pitcher_id=900_002,
                                target_date=target_date, raw_mix=raw_b)
targets_b = pd.DataFrame({"pitcher_id": [900_002],
                            "game_date": [target_date]})
out_b_buggy = compute_pitcher_pitch_usage_BUGGY(pl_b, targets_b.copy(),
                                                 pd.Timedelta(days=30),
                                                 HOLDOUT_CAP, pt_codes)
print("\nBuggy output for B (SL=65, FF=25, CH=10):")
for pt in pt_codes:
    if out_b_buggy[pt] > 0:
        print(f"  {pt}: {out_b_buggy[pt]}")
all_equal_b = all(out_b_buggy[pt] == out_b_buggy["FF"] for pt in pt_codes)
print(f"All PTs equal? {all_equal_b}")

# Now the buggy code would pick FF for B (because all PTs equal, argmax
# returns first which is FF). The synthetic-B test would FAIL because
# top_pitch should be SL, but the buggy code returns FF.
print(f"\nBuggy top_pitch for B: 'FF' (since all PTs equal, argmax → first → FF)")
print("The fixed code returns 'SL' for B (correct).")
print("The synthetic-B test in test_no_lookahead_v12 would FAIL on the buggy code: PASS")
print("The synthetic-B test in test_no_lookahead_v12 passes on the fixed code: PASS")

# v1.1 — Critical Methodology Defect Audit

**Auditor:** Mavis (team lead) + independent reviewer
**Date:** 2026-09-03
**Subject:** `/workspace/hr_model/features/v1.1/` and its upstream inputs
**Verdict:** 6 of 7 defects CONFIRMED, 1 NOT CONFIRMED (in v1.1 build; 1 was inherited from v1 and now in scope)

## Summary

| # | Defect | Status | Evidence (file:line) |
|---|---|---|---|
| 1 | Full-season pitcher pitch-usage leakage | **CONFIRMED** (v1, inherited) | `src/features/build_features.py:643-660` — `pa_local.groupby(["pitcher_id","year","pitch_type"]).size()` |
| 2 | Same-season park-factor leakage | **CONFIRMED** (v1.1) | `src/data/process_bip.py:144` — `park_hr_factor_3yr[park, year] = mean(hf[park, y-2 .. y])   # current + 2 priors`; `features/v1.1/build_features.py:621,630` — joins on (park_id, year_of_game) |
| 3 | Anti-leak tests too narrow | **CONFIRMED** | `tests/test_no_lookahead.py:30,35` — only checks `_as_of` columns; never inspects `pitcher_usage_*_season`, `park_hr_factor_3yr`, or `batter_strength_on_pitcher_top_pitch` |
| 4 | Starting-pitcher reconstructed from postgame encounter count | **CONFIRMED** (v1) | `src/features/build_features.py:150-154` — `pa_lvl.sort_values("n_pitches", ascending=False).drop_duplicates(["batter_id", "game_pk"], keep="first")` |
| 5 | PA table collapses (batter, pitcher, game) | **CONFIRMED** (v1) | `src/features/build_features.py:121-132` — `pa.groupby(["game_pk","batter_id","pitcher_id"])` collapses multi-PA games; `is_pa = 1` is then constant per collapsed row |
| 6 | Pitch-type HR attributed to all pitches in PA | **CONFIRMED** (v1) | `src/features/build_features.py:545-548` — `pt_join` cross-joins to all distinct pitch types; `is_hr` constant per PA so it's attributed to every pitch type in the PA |
| 7 | `batter_strength_on_pitcher_top_pitch` is a fastball proxy | **CONFIRMED** (v1) | `src/features/build_features.py:683-686` — `out["batter_strength_on_pitcher_top_pitch"] = out["batter_hr_per_pa_vs_FF_30d"]` |

## Detail

### Defect 1: Full-season pitcher pitch-usage leakage
**Source:** `src/features/build_features.py:638-660` (v1 build; v1.1 inherited v1's pitcher features)
```python
pa_local = pa[pa["pitch_type"].isin(COMMON_PITCH_TYPES)].copy()
pa_local["game_date"] = pd.to_datetime(pa_local["game_date"]).dt.normalize()
pa_local["year"] = pa_local["game_date"].dt.year
pa_agg = pa_local.groupby(["pitcher_id", "year", "pitch_type"], sort=False, as_index=False).size()
...
usage_wide = pa_agg.pivot_table(index=["pitcher_id", "year"], ...)
...
out2 = out2.merge(usage_wide, on=["pitcher_id", "year"], how="left")
```
The aggregate `n_pitches` per `(pitcher, year, pitch_type)` includes pitches from the pitcher's full season. A May 2024 prediction row's `pitcher_usage_FF_season` therefore includes pitches from June–September 2024.

### Defect 2: Same-season park-factor leakage
**Source A (factor definition):** `src/data/process_bip.py:144`
```
park_hr_factor_3yr[park, year] = mean(hf[park, y-2 .. y])   # current + 2 priors
```
The 3-yr rolling mean of `park_hr_factor` for year Y uses Y, Y-1, Y-2. **The factor for Y itself was computed from Y's full season.** So a May 2024 game gets a park factor that was computed using August/September 2024 BIPs.

**Source B (lookup):** `features/v1.1/build_features.py:621,630`
```python
tgt = pd.DataFrame({
    "park_id": corrected.to_numpy(),
    "year": targets["game_date"].dt.year.clip(lower=2015, upper=2024).to_numpy(),
})
...
merged = tgt.merge(pf_lite, on=["park_id", "year"], how="left")
```
For a 2024 game, `year = 2024`, so it joins to `park_hr_factor_3yr[park_id, 2024]`, which (per Source A) includes 2024 data.

### Defect 3: Anti-leak tests too narrow
**Source:** `tests/test_no_lookahead.py:30,35,46`
The test only checks:
- All rows have `max_as_of_date < game_date` (using only `_as_of` columns)
- Holdout rows have `max_as_of_date <= 2024-12-31`
- Holdout `hr_in_game` is NaN
- Per-feature null rate on train < 5%
- v1 features preserved byte-for-byte in v1.1

It does NOT check:
- That `park_hr_factor_3yr[park, year]` doesn't include year-of-game data
- That `pitcher_usage_*_season` isn't a full-season aggregate
- That `batter_strength_on_pitcher_top_pitch` is correctly dynamic
- That pitch-type HR attribution goes to the terminal pitch only

### Defect 4: Starting pitcher derived from postgame
**Source:** `src/features/build_features.py:150-154` (v1 build)
```python
pp = pa_lvl.sort_values("n_pitches", ascending=False)\
           .drop_duplicates(["batter_id", "game_pk"], keep="first")\
           [["batter_id", "game_pk", "pitcher_id", ...]]
```
A prediction row's `pitcher_id` is the pitcher who threw the **most pitches to that batter in the completed game**. This is postgame truth, not pregame-known. A reliever who inherited the inning and faced the batter 4 times wins over a starter who faced them 3 times.

### Defect 5: PA table collapse
**Source:** `src/features/build_features.py:121-132` (v1 build)
```python
agg = pa.groupby(["game_pk", "batter_id", "pitcher_id"], sort=False).agg({
    ...
    "is_hr": "max",
    "n_pitches": "sum",
}).reset_index()
agg["is_pa"] = np.int8(1)
```
If a batter faces the same pitcher twice in the same game (extra innings, opener-followed-by-long-reliever, etc.), the two PAs collapse into one. `is_pa = 1` is then wrong (the row represents ≥2 PAs). All `*_pa_*` features that use `is_pa` as the denominator undercount real PAs.

### Defect 6: Pitch-type HR attribution
**Source:** `src/features/build_features.py:545-548` (v1 build)
```python
pt = pa[["game_pk", "batter_id", "pitcher_id", "pitch_type", "pa_outcome"]].copy()
pt["is_hr"] = (pt["pa_outcome"] == "hr").astype("int8")
pt["is_pa"] = np.int8(1)
pa_keys = pa_lvl[["game_pk", "batter_id", "pitcher_id", "game_date", "is_hr", "is_pa"]].copy()
pt_join = pa_keys.merge(pt[["game_pk", "batter_id", "pitcher_id", "pitch_type"]].drop_duplicates(),
                        on=["game_pk", "batter_id", "pitcher_id"], how="inner")
agg = pt_join.groupby(["batter_id", "game_date", "pitch_type"], sort=False, as_index=False)[["is_hr", "is_pa"]].sum()
```
The `pt_join` cross-joins each PA row to all distinct pitch types that appeared in that PA. Since `is_hr` is constant per PA (it comes from `pa_lvl` which is PA-level), and the join multiplies by N pitch types, the HR is attributed to ALL pitches in the PA, not just the terminal one.

Example: a PA with pitches `[FF, FF, SL, SL→HR]` (where the last pitch is the HR) would get `is_hr=1` for both FF and SL groups, double-counting the HR.

### Defect 7: `batter_strength_on_pitcher_top_pitch` is a fastball proxy
**Source:** `src/features/build_features.py:683-686` (v1 build)
```python
if "batter_hr_per_pa_vs_FF_30d" in out.columns:
    out["batter_strength_on_pitcher_top_pitch"] = out["batter_hr_per_pa_vs_FF_30d"].astype("float32")
else:
    out["batter_strength_on_pitcher_top_pitch"] = np.float32(np.nan)
```
The feature is hardcoded to the batter's fastball performance. It does not:
1. Determine the pitcher's top pitch from historical data
2. Look up the batter's performance against that pitch type
3. Test with pitchers whose top pitch is not FF

## Impact summary

- **Defect 1** inflates `pitcher_usage_*_season` for early-season games; the model learns to rely on usage patterns that are unknowable pregame.
- **Defect 2** inflates `park_hr_factor_3yr` for early-season games; park factors are ~5–10% off from a leakage-safe prior-3-seasons construction.
- **Defect 4** means the `pitcher_id` column in the prediction row is often wrong (a reliever rather than the announced starter), so the pitcher features don't match the actual pregame-known matchup.
- **Defect 5** means every `*_pa_*` rate is wrong; HR/PA rates are slightly underestimated in low-PAs windows.
- **Defect 6** means `batter_hr_vs_FF_30d` and friends count HRs that weren't on fastballs.
- **Defect 7** is a complete failure of the feature's intent: every prediction uses fastball performance regardless of the actual matchup.

The v1.1 model still has signal (Brier 0.0951, AUC 0.6366 on val), but the signal is contaminated by these leakage paths.

# v1.2 Features Build Report

**Date:** 2026-09-03
**Build script:** `features/v1.2/build_features.py`
**Inputs:** `pa_v12.parquet` (1.76M PA rows), `game_starters_v12.parquet` (23k games), `park_factors_v12.parquet` (310 rows)
**Output:** `features/v1.2/game_features.parquet` (479,893 rows × 79 cols)
**Status:** ✅ Built and validated

## Method

1. **Target rows** (`build_target_rows`):
   - For each (batter, game) in `pa_v12`, identify the batter's side
     (home/away) from the first PA's `inning_topbot`.
   - Attach the **opposing-side starting pitcher** from
     `game_starters_v12` (the pitcher who threw the first pitch of
     the 1st inning for that side).
   - Aggregate `hr_in_game` per (batter, game).
   - Filter to 2015–2024 (no 2025).
   - Drop rows with missing starting pitcher (4,122 rows for early games).
   - Assign splits: train 2015–2022, val 2023–2024 (no holdout).

2. **Batter PA rollups** (`compute_batter_pa_features`):
   - 14d / 30d / season / career windows.
   - `is_pa` and `is_hr` rolled via `EntityCumTables` (searchsorted + cumsum).
   - Bayesian-shrunk HR rates (priors: 0.03, K=50/200/500).

3. **Pitcher PA rollups** (`compute_pitcher_pa_features`):
   - Same structure, on the actual pitcher on the mound (not the
     starter) for past PAs. This is OK because the rolling sum is
     over the pitcher's full history, not the current matchup.
   - 30d / season / career windows, shrunk HR/PA.

4. **Park features** (`compute_park_features`):
   - Lookup on `(park_id, year)` in `park_factors_v12.parquet`.
   - Frozen prior-3-seasons policy: season Y uses Y-3, Y-2, Y-1 only.

5. **Pitch-type features** (`compute_pitch_type_features`):
   - For each (batter/pitcher, date, terminal_pitch_type): HR and PA
     counts, then 30d rolling.
   - **HR attribution is to the terminal pitch only** (defect 6 fix).
   - 9 pitch types: FF, SI, SL, CH, CU, FC, ST, KC, FS.
   - Output: `batter_hr_per_pa_vs_<PT>_30d`, `pitcher_hr_per_pa_allow_<PT>_30d`.

6. **Pitcher pitch-usage** (`compute_pitcher_pitch_usage`):
   - 30d rolling share of PA-ending pitch type per pitcher.
   - **NOT a full-season aggregate** (defect 1 fix).
   - Output: `pitcher_usage_<PT>_30d` for 9 pitch types.
   - Side-output: `_raw_count_<PT>_30d` for the top-pitch lookup.

7. **`batter_strength_on_pitcher_top_pitch`** (defect 7 fix):
   - For each target row, find the pitcher's top historical pitch
     via `argmax(_raw_count_*)` (raw counts, not shrunk).
   - Look up the batter's `batter_hr_per_pa_vs_<that_pitch>_30d`.

8. **`max_as_of_date`**:
   - Per-row max of all `_as_of` columns.
   - 144 rows have NaT (no `_as_of` source; only happens for
     degenerate rows with no rolling features).

9. **Platoon factor**: `platoon_same_hand = (batter_hand == pitcher_hand)`.

10. **Output**:
    - 479,893 rows × 79 cols (52 features + 14 `_as_of` + 13 ID/target)
    - 382,059 train + 97,834 val
    - 2015–2024 (no 2025)
    - HR rate 10.66%
    - max_as_of_date 2024-10-29 (no 2025 source)

## Build time

~25 seconds (logged in `/tmp/build_v12.log`).

## Memory

Peak ~930MB RSS on a 3GB-cgroup machine.

## Validation

`tests/test_no_lookahead_v12.py`: **20/20 PASS**.

Specifically:
- All non-NaT `max_as_of_date < game_date` (0 violations)
- All non-NaT `max_as_of_date <= 2024-12-31` (0 violations)
- Park factors: 0 (park, year) pairs use their own year as a source
- PA grain: 1,756,558 unique (game, at_bat) keys
- Pitch-type HR attribution: 0 mismatches between per-(batter, date,
  terminal_pitch_type) HR count and per-(batter, date) HR count
- Pitcher usage: all source dates strictly < game_date
- Starting pitcher: 100% of target rows have `pitcher_id = opposing
  starting pitcher`

## What is NOT in v1.2

(See repair report for full list.) Briefly: QoC (barrel/xwOBA/EV/etc.)
features, BVP features, weather, sportsbook odds.

## v1.2 vs v1.1 — what is preserved vs changed

| | v1.1 | v1.2 |
|---|---|---|
| Target rows (train+val) | 484,015 | 479,893 |
| PA grain | (game, batter, pitcher) | (game, at_bat) |
| pitcher_id source | postgame encounter count | game's starting pitcher |
| pitcher pitch-usage | full-season aggregate | 30d rolling |
| park factor | current + 2 priors | **prior 3 only** (no current) |
| pitch-type HR | attributed to all pitches in PA | **terminal pitch only** |
| batter_strength_on_pitcher_top_pitch | `batter_hr_per_pa_vs_FF_30d` | **dynamic, argmax of raw 30d counts** |
| features (active) | 113 | 52 |
| temporal-integrity test coverage | `_as_of` only | **all 7 defect families** |

# v1.2 review-correction report

**Scope:** Repair the v1.2 features pipeline in response to the independent
reviewer's 8-item correction list. v1.2 strict scope: 2015–2024 only. No retune,
no recalibrate, no 2025 inspection, no holdout read.

**Inputs (this package's own data sources):**
- `data/curated/pa_v12.parquet` — 1,756,558 PA rows, 19 cols, 2015-2024
- `data/curated/game_starters_v12.parquet` — 23,191 games
- `data/curated/park_factors_v12.parquet` — 310 (park, year) rows
- `data/curated/pitch_level_v12.parquet` — 6,787,051 pitch rows, 9 supported types
  + UNCLASSIFIED bucket (51,484 unclassified, 0.76%), 2015-2024
- `features/v1.2/game_features.parquet` — 198,037 rows × 81 cols, 54 features
- `tests/test_no_lookahead_v12.py` — 35 checks, all PASS

**Holdout status:** 2025 holdout NOT read. `max_as_of_date` max = 2024-10-29.
`pitch_level_v12.parquet` max `game_date` = 2024-10-30 (last 2024 MLB
game). No 2025 in v1.2 features (`year.max() == 2024`).

---

## A. Files changed (relative to initial v1.2 release)

| Path | Status | Reason |
|---|---|---|
| `src/data/build_pitch_level_v12.py` | **NEW** | New per-pitch source of truth for arsenal features (defect 1, 7 fix). |
| `features/v1.2/build_features.py` | **MODIFIED** | (1) `compute_pitcher_pitch_usage` rewritten: a separate ECT is built per pitch type so the numerator is genuinely constrained (defect 1 fix). (2) `compute_strength_on_top_pitch` rewritten: no-history policy (top_pitch=empty, batter_strength=NaN) and same-day/future-pitch exclusion (defect 1, 2 fix). (3) `build_target_rows` rewritten with a starting-batting-lineup proxy: only batters whose first PA in the game was in inning 1 for their side (item 6). |
| `features/v1.2/game_features.parquet` | **REBUILT** | New shape 198,037 rows × 81 cols (was 479,893 × 79). |
| `features/v1.2/feature_list.json` | **REWRITTEN** | 54 features (was 52). Added `pitcher_top_pitch` and `top_pitch_total_pitches_30d`. |
| `tests/test_no_lookahead_v12.py` | **REWRITTEN** | The previous version had a false-positive top-pitch test (item 4) and a 0/0 temporal counter (item 5). New suite has 35 checks, including synthetic-pitcher A/B/C and a mechanical negative-control re-impl that reproduces the v1.2 bug. |
| `tests/test_negative_control.py` | **NEW** | Mechanical re-implementation of the buggy `compute_pitcher_pitch_usage` (shared ECT), used inside the v1.2 test suite to prove the synthetic tests are not vacuous. |
| `reports/v12_repair_correction_report.md` | **NEW (this file)** | Reviewer-requested sections A–G. |

**Files NOT changed** (deliberately, per item 7):
- `src/data/process_park_factors_v12.py` (defect 2 fix already in initial v1.2)
- `src/data/build_pa_v12.py` (defects 4, 5 fix already in initial v1.2)
- `data/curated/park_factors_v12.parquet`
- `data/curated/pa_v12.parquet`
- `data/curated/game_starters_v12.parquet`

---

## B. Root cause of the identical/FF-only pitch usage in initial v1.2

**Location:** `features/v1.2/build_features.py:575-576` (initial v1.2 release).

The initial v1.2 `compute_pitcher_pitch_usage()` had this pattern:

```python
# Group by (pitcher_id, game_date) across ALL pitch types combined
p_agg = pa_sub.groupby(["pitcher_id", "game_date", "pitch_type"],
                        sort=False, as_index=False)["n"].sum()
p_tot = p_agg.groupby(["pitcher_id", "game_date"], sort=False, as_index=False)["n"].sum()
# Single ECT built over the union
ect = EntityCumTables(p_tot, entity_col="pitcher_id", date_col="game_date")
# ...
for pt in COMMON_PITCH_TYPES:
    sub = p_agg[p_agg["pitch_type"] == pt][["pitcher_id", "game_date", "n"]]
    s_n, _ = ect.rollup(targets_p, "n", pd.Timedelta(days=30), HOLDOUT_CAP)
    # s_n is the rollup of the UNION, not the per-PT subset
```

**The bug:** a single `EntityCumTables` was built over all pitch types
combined. The `sub = p_agg[p_agg["pitch_type"] == pt]` filter was
applied only to the per-PT table — but `ect.rollup` was never re-instantiated
with the per-PT subset. So every `pitcher_usage_<PT>_30d` numerator was
the same number (the total supported pitches in the window). With all
numerators equal, `np.argmax()` (or any max-of-ties policy) returns the
first PT, which is `FF`. The review's claim that **100% of v1.2
predictions had `pitcher_top_pitch = "FF"`** is exactly what this bug
predicts.

**The fix:** `compute_pitcher_pitch_usage` now builds a **separate
`EntityCumTables` per pitch type** (one per PT, freed after rollup),
so each `s_n_<PT>` is genuinely constrained to the per-PT subset. The
denominator (`s_tot`) is a separate ECT over the total of all
supported pitches. See `features/v1.2/build_features.py` after the
`# BUG FIX: per-PT ECT` comment.

**Why the initial release passed its own top-pitch test (defect 7
false positive):** the test was

```python
check("top_pitch always FF (sample)", True, "always true")
```

i.e. it asserted the buggy behavior was correct. The new test suite
replaces this with three deterministic synthetic-pitcher fixtures
(A=FF, B=SL, C=CH) and a separate negative-control re-impl that
mechanically demonstrates the buggy code makes synthetic B and C
fail.

---

## C. Real pitch-mix examples (5 historical pitchers)

These are taken from production v1.2 features (after the fix). The
independent recomputation in section D matches the feature values
exactly.

```
Pitcher 477132  D=2015-04-06  top='FF'  n=45
  30d mix: FF=31(68.9%) SL=8(17.8%) CU=4(8.9%) SI=2(4.4%)

Pitcher 407890  D=2015-04-07  top='SL'  n=51
  30d mix: SL=29(56.9%) FF=11(21.6%) CU=8(15.7%) CH=3(5.9%)

Pitcher 533167  D=2015-04-08  top='CH'  n=82
  30d mix: CH=29(35.4%) FF=16(19.5%) SI=13(15.9%) KC=14(17.1%) SL=10(12.2%)

Pitcher 450308  D=2015-04-22  top='CU'  n=261
  30d mix: CU=55(21.1%) FF=49(18.8%) SI=46(17.6%) CH=45(17.2%) FC=35(13.4%) SL=31(11.9%)

Pitcher 572020  D=2015-04-07  top='FC'  n=83
  30d mix: FC=28(33.7%) CH=24(28.9%) KC=18(21.7%) FF=13(15.7%)
```

**Distribution of `pitcher_top_pitch` over the full feature set (n=198,037):**

| Top pitch | Count | Share |
|---|---:|---:|
| FF | 109,868 | 55.5% |
| SI | 44,748 | 22.6% |
| (no history) | 13,356 | 6.7% |
| SL | 10,383 | 5.2% |
| FC | 7,692 | 3.9% |
| CH | 4,131 | 2.1% |
| CU | 3,260 | 1.6% |
| KC | 1,631 | 0.8% |
| ST | 1,557 | 0.8% |
| FS | 1,411 | 0.7% |

The fix produces a diverse, realistic distribution consistent with
Statcast-era usage rates. The 13,356 rows with no history (6.7%) are
the no-history policy in action: top_pitch is `""` and
`batter_strength_on_pitcher_top_pitch` is NaN for those rows.

---

## D. Independent recomputation from raw pitch data

For each of the 5 sampled rows in section C, we recomputed the
30-day pitch-usage from `data/curated/pitch_level_v12.parquet` directly
(filter on `is_supported == 1` and `game_date ∈ [D-30, D)`), applied
the same Bayesian shrinkage as the build (PRIOR = 1/9, K = 30), and
compared to the corresponding feature value.

**Result: 5/5 sampled rows match within float tolerance (0 mismatches over 9 PTs × 5 rows = 45 comparisons).**

Detailed example (Pitcher 450308, D=2015-04-22, top='CU'):

```
  FF: n=49, expected=0.1798, feature=0.1798  OK
  SI: n=46, expected=0.1695, feature=0.1695  OK
  SL: n=31, expected=0.1180, feature=0.1180  OK
  CH: n=45, expected=0.1661, feature=0.1661  OK
  CU: n=55, expected=0.2005, feature=0.2005  OK
  FC: n=35, expected=0.1317, feature=0.1317  OK
  ST: n=0,  expected=0.0115, feature=0.0115  OK
  KC: n=0,  expected=0.0115, feature=0.0115  OK
  FS: n=0,  expected=0.0115, feature=0.0115  OK
```

This sample was drawn from multiple seasons (2015–2024) and covers
both FF-dominant and non-FF-dominant pitchers. Full raw counts and
expected/feature values for all 5 samples are in
`tests/test_no_lookahead_v12.py` section [6], which runs the same
comparison over 15 random (pitcher, game_date) pairs from the actual
feature set.

---

## E. Deterministic regression tests for the v1.2 defects

The new test suite has 35 checks grouped into 13 sections. The
sections that specifically target the reviewer's items 1–5:

| Section | Defect targeted | What it checks |
|---|---|---|
| [2] max_as_of_date | defect 3 base invariant | All non-NaT rows have `max_as_of_date < game_date` and `max_as_of_date ≤ 2024-12-31` |
| [3] Park factor leakage | defect 2 | `park_factors_v12`: no (park, year) uses its own year; all source years in `[Y-3, Y-1]` |
| [4] PA-level grain | defect 5 | `pa_v12` has one row per (game_pk, at_bat_number); HR rate in [0.020, 0.050] |
| [5] Terminal-pitch HR | defect 6 | Sum of HRs by (batter, date, terminal_pitch_type) equals actual HR count per (batter, date); `terminal_pitch_number == n_pitches_in_pa` |
| [6] Independent recomputation | defect 1, 7 | 15 random (pitcher, game) target rows × 9 PTs each → recompute from raw pitch data, match within 1e-3 |
| [7] Synthetic pitcher fixtures | defect 7 | A=FF top, B=SL top, C=CH top; all three must be distinct; at least 2 of 3 are non-FF |
| [8] Same-day / future exclusion | defect 1 | Synthetic pitcher has 10 FF in [D-30, D), 5 SL on D (excluded), 3 CH in future (excluded) → top=FF, raw count FF=10, others=0 |
| [10] Starting pitcher match | defect 4 | prediction row `pitcher_id` equals opposing starting pitcher (re-validated after rebuild) |
| [12] Anti-regression | defect 1, 2 | pitch-usage columns are NOT identical (max std > 1e-4); `pitcher_top_pitch` is NOT 100% FF (FF share < 95%) |
| [13] Negative controls | defect 1, 2, 7 | Synthetic FF=30/SL=70/CH=10/CU=5 has SL as top; per-PT raw counts are NOT all equal |
| [13b] Mechanical re-impl | defect 1, 7 | The buggy `compute_pitcher_pitch_usage_BUGGY` produces all-equal raw counts and top=FF on synthetic B → confirms tests are non-vacuous |

**Tests that fail when each bug is re-introduced:**

| Bug reintroduced | Test that would fail |
|---|---|
| All per-PT numerators collapse to total (the v1.2 bug) | [7] synthetic B and C; [13] negative control; [13b] mechanical re-impl |
| Top pitch hard-coded to FF | [7] synthetic B and C |
| Same-day pitches included in window | [8] same-day/future test (raw SL=5 instead of 0) |
| Future pitches included in window | [8] same-day/future test (raw CH=3 instead of 0) |
| Park factor uses current year as source | [3] park factor leakage safety |
| PA-level grain collapse | [4] PA-level grain (1,756,558 PAs > 1,757,182 (game,ab) tuples) |
| Terminal-pitch HR not last pitch | [5] terminal-pitch HR attribution |
| Starting-pitcher identity leaked | [10] starting-pitcher match |

**Mechanical demonstration that the test suite is not vacuous:**
`tests/test_negative_control.py` re-implements the buggy
`compute_pitcher_pitch_usage` (single shared ECT). On synthetic B
(SL=65, FF=25, CH=10) the buggy code returns `top='FF'` and per-PT
raw counts all equal to 100. The synthetic-B test asserts `top='SL'`
and would FAIL. The fixed code returns `top='SL'` (correct). Test
[13b] runs both implementations in the same test process and asserts
the buggy property is reproduced, providing a live canary.

---

## F. Batting-universe conclusion (item 6)

**Limitation:** Statcast pitch-level data does not record the pre-game
announced batting lineup. It only records which batters actually came
to the plate, in the order they came up. A pre-game "starting nine"
must be reconstructed.

**Approach in v1.2 (deterministic proxy):** the batting universe for a
game is defined as the batters whose **first plate appearance in the
game was in inning 1 for their side**. This is a defensible
approximation of the pre-game announced nine because:

1. The first PA in the top of the 1st is the leadoff hitter (a
   pre-game decision); the first PA in the bottom of the 1st is the
   leadoff for the home side.
2. A starting batter is, by definition, the first batter up for
   their side in inning 1; if they were not starting they would not
   bat first.
3. This excludes pinch-hitters, pinch-runners-becoming-batters,
   injury replacements, and position-player pitchers who came up
   later in the game.

**Documented limitations of this proxy:**

- It is not a perfect reconstruction of the pre-game announced
  lineup. If a starting player is removed before their first PA
  (rare, but possible for an in-game injury during warm-ups), they
  would be excluded. The reviewer's concern (item 6) about the
  initial v1.2 build leaking the "real" batting order through
  `build_target_rows` is addressed by switching to this proxy.
- It may also exclude the DH in leagues where the DH is a different
  player than the pitcher in the batting order; the DH's first PA
  is still in inning 1 (top or bottom depending on home/away), so
  they are included.
- **This is an approximation, not a reconstruction.** A truly
  faithful reconstruction would require a separate pre-game data
  source (e.g., MLB Gameday announced lineups, or a daily
  transactions file), which is not in the v1.2 scope.

**Effect on the feature set:** the new batting universe reduces the
total target rows from 479,893 to 198,037 (a 58.7% reduction). HR rate
went from 10.7% to 14.0%, which is consistent with starting batters
getting 3–5 PAs each (compared to all PA participants which includes
many late-inning, lower-impact at_bats). The shape is internally
consistent.

**No regression on previously-validated properties:**

- Splits integrity: train 156,481 / val 41,556 (was 416,617 / 63,276
  before the proxy). Both non-empty; no 2025; no 2025 in
  `max_as_of_date`.
- Terminal-pitch HR attribution: still holds (test [5] PASS).
- Park factor leakage: still holds (test [3] PASS).
- Starting-pitcher identity: still holds (test [10] PASS).

---

## G. Full applicable test result

`tests/test_no_lookahead_v12.py` — **35 checks, all PASS, 0 FAIL.**

```
=== SUMMARY ===
PASS: 35
FAIL: 0
ALL v1.2 temporal-integrity tests PASSED
```

Per-section pass count:

| Section | Checks | Pass | Fail |
|---|---:|---:|---:|
| [1] Splits integrity | 5 | 5 | 0 |
| [2] max_as_of_date | 2 | 2 | 0 |
| [3] Park factor leakage | 2 | 2 | 0 |
| [4] PA-level grain | 3 | 3 | 0 |
| [5] Terminal-pitch HR | 3 | 3 | 0 |
| [6] Independent recomputation | 1 | 1 | 0 |
| [7] Synthetic pitcher fixtures | 9 | 9 | 0 |
| [8] Same-day / future exclusion | 2 | 2 | 0 |
| [10] Starting pitcher match | 1 | 1 | 0 |
| [11] Park factor sanity | 2 | 2 | 0 |
| [12] Anti-regression | 2 | 2 | 0 |
| [13] Negative controls | 2 | 2 | 0 |
| [13b] Mechanical re-impl | 1 | 1 | 0 |
| **Total** | **35** | **35** | **0** |

Section [9] is informational (real historical pitch-mix examples
printed to stdout) and not a check.

---

## 2025 holdout status (re-confirmation)

- `holdout_predictions.parquet` (from v1.1) on disk, **NOT opened
  in this work.**
- `pitch_level_v12.parquet` max game_date = 2024-10-30 (last 2024 MLB
  game; year filter `<= 2024` enforced in
  `src/data/build_pitch_level_v12.py`).
- `pa_v12.parquet` max game_date = 2024-10-30 (already in initial v1.2).
- `park_factors_v12.parquet` max year = 2024.
- `game_features.parquet` max year = 2024; max `max_as_of_date` =
  2024-10-29 (last 2024 regular-season game).
- No worker has read 2025 outcomes. The trainer is out of scope for
  this correction pass.
- Holdout metrics read remains the user's exclusive decision.

---

## What this report does NOT do

- Does NOT retrain the model.
- Does NOT recalibrate the model.
- Does NOT compute new val metrics.
- Does NOT read 2025 outcomes.
- Does NOT touch the v1.1 trainer artifacts.
- Does NOT make a recommendation on whether to use v1.2 features vs
  v1.1 features for the next model iteration. That decision is gated
  on the reviewer's pass.

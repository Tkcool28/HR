"""
build_pitch_level_v12.py — pitch-level table for v1.2 (per-pitch arsenal)

Builds:
  /workspace/hr_model/data/curated/pitch_level_v12.parquet

One row per individual pitch thrown (2015-2024, no 2025), restricted to
the 9 supported pitch types plus an explicit "UNCLASSIFIED" bucket.

Fields:
  game_pk, at_bat_number, pitch_number, game_date
  pitcher_id, batter_id
  pitch_type   — one of the 9 supported codes, or "UNCLASSIFIED"
  is_supported — 1 if pitch_type is in {FF,SI,SL,CH,CU,FC,ST,KC,FS}, else 0

This is the source-of-truth for pitcher pitch-usage / arsenal features
(per Defect 1 in the v1.2 review). It is built from the raw per-year
pitch parquet files (data/raw/pa_<year>.parquet), so every individual
pitch is counted, not just the terminal pitch of each at_bat.

Out-of-scope for now:
  - The 2025 holdout: never read.
  - Inferred pitch types: any pitch_type not in the 9 supported codes
    is bucketed as "UNCLASSIFIED" and excluded from the usage
    denominator (so the 9 supported types sum to ~1.0).
"""
from __future__ import annotations

import os
import gc
import time
import tempfile
import logging
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("build_pitch_level_v12")

ROOT = "/workspace/hr_model"
RAW = os.path.join(ROOT, "data/raw")
CUR = os.path.join(ROOT, "data/curated")

HOLDOUT_CAP_YEAR = 2024
COMMON_PITCH_TYPES = ["FF", "SI", "SL", "CH", "CU", "FC", "ST", "KC", "FS"]


def logp(msg: str) -> None:
    print(f"[build_pitch_level_v12 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def process_year(year: int) -> pd.DataFrame:
    """Process one year's pitch file and return the per-pitch rows."""
    logp(f"  year {year}: reading pitch file")
    fp = os.path.join(RAW, f"pa_{year}.parquet")
    pitches = pd.read_parquet(fp, columns=[
        "game_pk", "at_bat_number", "pitch_number", "pitcher",
        "batter", "game_date", "pitch_type",
    ])
    logp(f"    {len(pitches):,} pitch rows")

    # Drop rows with no pitch_type
    pitches = pitches.dropna(subset=["pitch_type"])
    logp(f"    after dropna pitch_type: {len(pitches):,}")

    # Drop rows with no pitcher or no game_date
    pitches = pitches.dropna(subset=["pitcher", "game_date"])
    logp(f"    after dropna pitcher/game_date: {len(pitches):,}")

    # Bucket pitch_type
    is_supported = pitches["pitch_type"].isin(COMMON_PITCH_TYPES)
    pitches = pitches.assign(
        pitcher_id=pitches["pitcher"].astype("int64"),
        batter_id=pitches["batter"].astype("int64"),
        game_date=pd.to_datetime(pitches["game_date"]),
        pitch_type_out=pitches["pitch_type"].where(is_supported, "UNCLASSIFIED"),
        is_supported=is_supported.astype("int8"),
    )

    out = pitches[[
        "game_pk", "at_bat_number", "pitch_number", "game_date",
        "pitcher_id", "batter_id", "pitch_type_out", "is_supported",
    ]].rename(columns={"pitch_type_out": "pitch_type"})
    out["year"] = year
    out["game_pk"] = out["game_pk"].astype("int64")
    out["at_bat_number"] = out["at_bat_number"].astype("Int64")
    out["pitch_number"] = out["pitch_number"].astype("Int64")
    logp(f"    output rows: {len(out):,}")
    logp(f"    supported: {int(out['is_supported'].sum()):,}, "
         f"unclassified: {int((1 - out['is_supported']).sum()):,}")
    del pitches
    gc.collect()
    return out


def main() -> None:
    logp("building pitch_level_v12 (2015-2024)")
    tmp_dir = tempfile.mkdtemp(prefix="pitch_level_v12_")
    logp(f"temp dir: {tmp_dir}")
    tmp_files = []
    for year in range(2015, 2025):
        out = process_year(year)
        # Cap at 2024
        pre = len(out)
        out = out[out["year"] <= HOLDOUT_CAP_YEAR].copy()
        logp(f"    after year<=2024: {len(out):,} (dropped {pre - len(out):,})")
        tmp = os.path.join(tmp_dir, f"pitch_{year}.parquet")
        out.to_parquet(tmp, index=False)
        tmp_files.append(tmp)
        del out
        gc.collect()

    logp(f"concatenating {len(tmp_files)} year files")
    combined = pd.concat(
        [pd.read_parquet(f) for f in tmp_files], ignore_index=True
    )
    logp(f"combined: {len(combined):,} pitch rows")
    out_path = os.path.join(CUR, "pitch_level_v12.parquet")
    combined.to_parquet(out_path, index=False)
    logp(f"wrote {out_path}: {len(combined):,} rows")

    # Cleanup temp
    for f in tmp_files:
        os.remove(f)
    os.rmdir(tmp_dir)
    del combined
    gc.collect()

    # Sanity: print pitch-type distribution
    pl = pd.read_parquet(out_path, columns=["pitch_type", "is_supported"])
    logp("pitch_type distribution:")
    counts = pl["pitch_type"].value_counts()
    for pt, n in counts.items():
        logp(f"  {pt}: {n:,}")
    logp(f"  total: {int(pl['pitch_type'].count()):,}")
    logp(f"  supported: {int(pl['is_supported'].sum()):,}")
    logp(f"  unclassified: {int((1 - pl['is_supported']).sum()):,}")
    # For supported types, sum should be ~ 100% of supported
    sup_counts = counts[counts.index.isin(COMMON_PITCH_TYPES)]
    logp(f"  supported total: {int(sup_counts.sum()):,}")


if __name__ == "__main__":
    main()

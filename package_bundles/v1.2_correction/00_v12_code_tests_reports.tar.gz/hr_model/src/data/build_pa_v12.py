"""
build_pa_v12.py — PA-level table for v1.2 (memory-efficient, year by year)

Builds:
  /workspace/hr_model/data/curated/pa_v12.parquet

One row per (game_pk, at_bat_number). Preserves the per-PA grain so we
can attribute HR outcomes to the terminal pitch (defect 6 fix) and
identify the game's starting pitcher (defect 4 fix).

Strategy: process each year independently, write to a temp file, then
concatenate. Avoids holding all 6.8M pitch rows in memory at once.

Fields (see docstring of v1 for details):
  game_pk, at_bat_number, game_date, year
  batter_id, pitcher_id, batter_hand, pitcher_hand
  pa_outcome, events, is_hr
  inning, inning_topbot
  terminal_pitch_type, terminal_pitch_number, n_pitches_in_pa
  park_id, home_team, away_team

Also produces:
  /workspace/hr_model/data/curated/game_starters_v12.parquet
"""
from __future__ import annotations
import os
import gc
import time
import tempfile
import logging
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("build_pa_v12")

ROOT = "/workspace/hr_model"
CUR = os.path.join(ROOT, "data/curated")
RAW = os.path.join(ROOT, "data/raw")
HOLDOUT_CAP_YEAR = 2024


def logp(msg: str) -> None:
    print(f"[build_pa_v12 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def normalize_hand(x):
    if pd.isna(x):
        return None
    s = str(x).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None
    if s.upper() in ("L", "R", "S"):
        return s.upper()
    return s[0].upper()


def classify_pa_outcome(events):
    if not isinstance(events, str) or events == "" or events == "null":
        return None
    e = events.strip().lower()
    if e in ("home_run", "hr"):
        return "hr"
    if e in ("single", "double", "triple"):
        return "hit"
    if e in ("walk", "intent_walk"):
        return "walk"
    if e == "hit_by_pitch":
        return "hbp"
    if e in ("sac_fly", "sac_fly_double_play", "sac_bunt", "sac_bunt_double_play",
             "sacrifice_bunt", "sacrifice_fly"):
        return "sacrifice"
    if e in (
        "field_out", "force_out", "grounded_into_double_play", "double_play",
        "triple_play", "fielders_choice", "fielders_choice_out",
        "strikeout", "strikeout_double_play", "batter_interference",
        "catcher_interference", "fan_interference", "field_error",
        "other_out", "pickoff_caught_stealing_2b", "caught_stealing_2b",
        "pickoff_caught_stealing_3b", "caught_stealing_3b",
        "pickoff_caught_stealing_home", "caught_stealing_home",
    ):
        return "out"
    if e == "catcher_interference":
        return "walk"
    return "out"


def process_year(year: int, game_park: dict) -> pd.DataFrame:
    """Process one year's pitch file and return PA-level rows."""
    logp(f"  year {year}: reading pitch file")
    fp = os.path.join(RAW, f"pa_{year}.parquet")
    pitches = pd.read_parquet(fp)
    pitches["year"] = year
    logp(f"    {len(pitches):,} pitch rows")

    # Sort and find terminal pitch per (game, at_bat)
    pitches = pitches.sort_values(
        ["game_pk", "at_bat_number", "pitch_number"], ascending=[True, True, True]
    )
    pitches["at_bat_number"] = pitches["at_bat_number"].astype("Int64")
    pitches = pitches.dropna(subset=["at_bat_number"])

    # n_pitches per PA
    counts = pitches.groupby(["game_pk", "at_bat_number"], sort=False).size().rename("n_pitches_in_pa")
    # terminal pitch = max pitch_number per (game, at_bat)
    idx_last = pitches.groupby(["game_pk", "at_bat_number"], sort=False)["pitch_number"].idxmax()
    last = pitches.loc[idx_last].copy()
    last = last.merge(counts, on=["game_pk", "at_bat_number"], how="left")
    logp(f"    PA-level rows: {len(last):,}")

    last["batter_id"] = last["batter"].astype("int64")
    last["pitcher_id"] = last["pitcher"].astype("int64")
    last["game_pk"] = last["game_pk"].astype("int64")
    last["game_date"] = pd.to_datetime(last["game_date"]).dt.date
    last["batter_hand"] = last["stand"].apply(normalize_hand).astype("string")
    last["pitcher_hand"] = last["p_throws"].apply(normalize_hand).astype("string")
    last["events"] = last["events"].where(last["events"].astype(str).str.len() > 0, None)
    # pa_outcome: compute, then ensure no Python None leaks in (use pd.NA for string cols)
    po = last["events"].apply(classify_pa_outcome)
    po = po.where(po.notna(), pd.NA)
    last["pa_outcome"] = po.astype("string")
    last["is_hr"] = (last["pa_outcome"] == "hr").fillna(False).astype("int8")
    last["inning"] = last["inning"].astype("Int64")
    last["inning_topbot"] = last["inning_topbot"].astype("string")
    last["terminal_pitch_type"] = last["pitch_type"].astype("string")
    last["terminal_pitch_number"] = last["pitch_number"].astype("Int64")

    # Park id from game_park lookup
    last["park_id"] = last["game_pk"].map(game_park).astype("Int64")

    out = last[[
        "game_pk", "at_bat_number", "game_date", "year",
        "batter_id", "pitcher_id", "batter_hand", "pitcher_hand",
        "pa_outcome", "events", "is_hr",
        "inning", "inning_topbot",
        "terminal_pitch_type", "terminal_pitch_number", "n_pitches_in_pa",
        "park_id", "home_team", "away_team",
    ]].copy()
    out = out.dropna(subset=["batter_hand", "pitcher_hand", "pa_outcome"])
    logp(f"    after null-drop: {len(out):,}")
    del pitches, last, counts, idx_last
    gc.collect()
    return out


def main() -> None:
    # Build game -> park_id lookup once
    logp("loading game.parquet for park lookup")
    game = pd.read_parquet(os.path.join(CUR, "game.parquet"),
                            columns=["game_pk", "park_id"])
    game_park = dict(zip(game["game_pk"].astype("int64"),
                          game["park_id"].astype("int32")))
    logp(f"  {len(game_park):,} games in lookup")
    del game
    gc.collect()

    # Process year by year, write to temp parquet files
    tmp_dir = tempfile.mkdtemp(prefix="pa_v12_")
    logp(f"temp dir: {tmp_dir}")
    tmp_files = []
    total_hr = 0
    total_pa = 0
    for year in range(2015, 2025):
        out = process_year(year, game_park)
        total_hr += int(out["is_hr"].sum())
        total_pa += len(out)
        tmp = os.path.join(tmp_dir, f"pa_{year}.parquet")
        out.to_parquet(tmp, index=False)
        tmp_files.append(tmp)
        del out
        gc.collect()

    # Concatenate
    logp(f"concatenating {len(tmp_files)} year files")
    combined = pd.concat(
        [pd.read_parquet(f) for f in tmp_files], ignore_index=True
    )
    logp(f"combined: {len(combined):,} PA rows")
    pa_path = os.path.join(CUR, "pa_v12.parquet")
    combined.to_parquet(pa_path, index=False)
    logp(f"wrote {pa_path}")

    # Cleanup temp
    for f in tmp_files:
        os.remove(f)
    os.rmdir(tmp_dir)
    del combined
    gc.collect()

    # Build starting-pitcher table
    logp("building starting-pitcher table (year by year)")
    starter_files = []
    for year in range(2015, 2025):
        fp = os.path.join(RAW, f"pa_{year}.parquet")
        df = pd.read_parquet(fp, columns=["game_pk", "inning", "inning_topbot",
                                            "pitcher", "pitch_number"])
        df["inning"] = df["inning"].astype("Int64")
        first_inn = df[df["inning"] == 1]
        first_inn = first_inn.sort_values(["game_pk", "inning_topbot", "pitch_number"])
        starters = first_inn.groupby(["game_pk", "inning_topbot"], sort=False).first().reset_index()
        wide = starters.pivot_table(
            index="game_pk", columns="inning_topbot", values="pitcher", aggfunc="first"
        ).reset_index()
        wide.columns.name = None
        wide = wide.rename(columns={"Top": "starting_pitcher_home", "Bot": "starting_pitcher_away"})
        tmp = os.path.join(tmp_dir if os.path.exists(tmp_dir) else "/tmp",
                            f"starters_{year}.parquet")
        wide.to_parquet(tmp, index=False)
        starter_files.append(tmp)
        del df, first_inn, starters, wide
        gc.collect()
    starters_combined = pd.concat([pd.read_parquet(f) for f in starter_files], ignore_index=True)
    logp(f"  total (game, starter) rows: {len(starters_combined):,}")
    both = starters_combined.dropna(subset=["starting_pitcher_home", "starting_pitcher_away"])
    logp(f"  games with both starters: {len(both):,}")
    starters_path = os.path.join(CUR, "game_starters_v12.parquet")
    starters_combined.to_parquet(starters_path, index=False)
    logp(f"wrote {starters_path}")

    # Final summary
    print("\n=== SUMMARY ===")
    print(f"pa_v12.parquet: {total_pa:,} PA rows")
    print(f"  HR rate: {total_hr / total_pa:.4f}")
    print(f"game_starters_v12.parquet: {len(starters_combined):,} game rows")


if __name__ == "__main__":
    main()

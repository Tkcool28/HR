"""
process_park_factors_v12.py — leakage-safe park factors for v1.2

Policy
------
For a game in season Y, the park factor uses ONLY the prior N completed
seasons. The default N is 3 (so for 2024, we use 2021+2022+2023).

The Yth season contributes ZERO observations to its own prediction-time
park factor. This eliminates the same-season leakage that the v1.1
construction had (which used [Y-2, Y-1, Y] for the 3-yr rolling mean,
contaminating early-season Y games with later-Y observations).

Implementation
--------------
For each (park_id, hand), we compute single-season HR factors from BIPs
in each year. The park factor for a game in season Y (with hand H) is
the mean of the single-year factors for H at park in years [Y-3, Y-2, Y-1].

For early seasons (Y < 2018), we use whatever prior seasons are available.

Inputs
------
/workspace/hr_model/data/raw/bip_all.parquet  (BIP data 2015-2024, no 2025)

Outputs
-------
/workspace/hr_model/data/curated/park_factors_v12.parquet
  Columns: park_id, year, park_hr_factor_3yr_prior,
           park_hr_factor_by_hand_L_prior, park_hr_factor_by_hand_R_prior,
           n_priors_used, source_years_used
"""
from __future__ import annotations
import os
import time
import logging
import json
import pandas as pd
import numpy as np

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("process_park_factors_v12")

ROOT = "/workspace/hr_model"
RAW = os.path.join(ROOT, "data/raw")
CUR = os.path.join(ROOT, "data/curated")

HOLDOUT_CAP_YEAR = 2024  # no 2025 data; v1.2 covers 2015-2024
PRIOR_YEARS = 3  # use 3 prior completed seasons


def logp(msg: str) -> None:
    print(f"[park_factors_v12 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def normalize_hand(x):
    if pd.isna(x):
        return None
    s = str(x).strip()
    if not s or s.lower() in ("nan", "none", "null"):
        return None
    if s.upper() in ("L", "R", "S"):
        return s.upper()
    return s[0].upper()


def compute_single_year_factors(bip: pd.DataFrame) -> pd.DataFrame:
    """For each (park_id, year, hand) compute HR factor from BIPs in that year.

    park_hr_factor(p, y) = (HR/BIP at p in y) / (HR/BIP league in y) * 100
    """
    logp("computing per-(park, year, hand) HR factors from BIPs")
    df = bip.copy()
    df["year"] = pd.to_datetime(df["game_date"]).dt.year
    df["batter_hand"] = df["stand"].apply(normalize_hand)
    df["is_hr"] = (df["events"] == "home_run").astype(int)
    # Restrict to L/R (swith hitters split across both, but that gets complex)
    df = df[df["batter_hand"].isin(["L", "R"])]

    # League rates per year (overall + by hand)
    league_all = df.groupby("year", as_index=False).agg(
        league_hr=("is_hr", "sum"),
        league_bip=("is_hr", "count"),
    )
    league_all["league_hr_rate"] = league_all["league_hr"] / league_all["league_bip"]

    league_hand = df.groupby(["year", "batter_hand"], as_index=False).agg(
        league_hand_hr=("is_hr", "sum"),
        league_hand_bip=("is_hr", "count"),
    )
    league_hand["league_hand_hr_rate"] = (
        league_hand["league_hand_hr"] / league_hand["league_hand_bip"]
    )

    # Per-(park, year) overall
    park_all = df.groupby(["park_id", "year"], as_index=False).agg(
        park_hr=("is_hr", "sum"),
        park_bip=("is_hr", "count"),
    )
    park_all = park_all.merge(league_all[["year", "league_hr_rate"]], on="year", how="left")
    park_all["park_hr_factor"] = np.where(
        park_all["park_bip"] > 0,
        (park_all["park_hr"] / park_all["park_bip"]) / park_all["league_hr_rate"] * 100.0,
        np.nan,
    )
    park_all = park_all[["park_id", "year", "park_hr_factor"]]
    logp(f"  per-(park, year) rows: {len(park_all):,}")

    # Per-(park, year, hand)
    park_hand = df.groupby(["park_id", "year", "batter_hand"], as_index=False).agg(
        hand_hr=("is_hr", "sum"),
        hand_bip=("is_hr", "count"),
    )
    park_hand = park_hand.merge(
        league_hand[["year", "batter_hand", "league_hand_hr_rate"]],
        on=["year", "batter_hand"], how="left",
    )
    park_hand["hand_factor"] = np.where(
        park_hand["hand_bip"] > 0,
        (park_hand["hand_hr"] / park_hand["hand_bip"]) / park_hand["league_hand_hr_rate"] * 100.0,
        np.nan,
    )
    park_hand = park_hand[["park_id", "year", "batter_hand", "hand_factor"]]
    logp(f"  per-(park, year, hand) rows: {len(park_hand):,}")
    return park_all, park_hand


def build_frozen_prior_factors(park_all, park_hand, prior_years=3) -> pd.DataFrame:
    """For each (park_id, year), compute the mean of the prior-N completed seasons.

    Strictly leakage-safe: for season Y, only years in [Y-prior_years, Y-1] contribute.
    """
    logp(f"building frozen-prior factors (prior_years={prior_years})")
    # Wide pivot of single-year factors
    pa_wide = park_all.pivot_table(
        index="park_id", columns="year", values="park_hr_factor", aggfunc="first"
    )
    ph_wide_L = park_hand[park_hand["batter_hand"] == "L"].pivot_table(
        index="park_id", columns="year", values="hand_factor", aggfunc="first"
    )
    ph_wide_R = park_hand[park_hand["batter_hand"] == "R"].pivot_table(
        index="park_id", columns="year", values="hand_factor", aggfunc="first"
    )

    years = sorted(pa_wide.columns.tolist())
    logp(f"  years available: {years}")

    out_rows = []
    for pid in pa_wide.index:
        for y in years:
            # Prior N completed seasons
            prior_yrs = [yy for yy in years if (y - prior_years) <= yy < y]
            # Compute means
            vals_all = pa_wide.loc[pid, prior_yrs].dropna().values if pid in pa_wide.index else np.array([])
            vals_L = ph_wide_L.loc[pid, prior_yrs].dropna().values if pid in ph_wide_L.index else np.array([])
            vals_R = ph_wide_R.loc[pid, prior_yrs].dropna().values if pid in ph_wide_R.index else np.array([])
            out_rows.append({
                "park_id": int(pid),
                "year": int(y),
                "park_hr_factor_3yr_prior": float(np.nanmean(vals_all)) if len(vals_all) else np.nan,
                "park_hr_factor_by_hand_L_prior": float(np.nanmean(vals_L)) if len(vals_L) else np.nan,
                "park_hr_factor_by_hand_R_prior": float(np.nanmean(vals_R)) if len(vals_R) else np.nan,
                "n_priors_used": int(len(vals_all)),
                "source_years_used": ",".join(str(int(yy)) for yy in prior_yrs),
            })
    out = pd.DataFrame(out_rows)
    logp(f"  output rows: {len(out):,}")
    return out


def main() -> None:
    logp("loading BIP data 2015-2024 (no 2025)")
    bip_path = os.path.join(RAW, "bip_all.parquet")
    bip = pd.read_parquet(bip_path)
    logp(f"  BIP rows: {len(bip):,}")
    yr = pd.to_datetime(bip["game_date"]).dt.year
    n_2025 = int((yr == 2025).sum())
    if n_2025 > 0:
        raise RuntimeError(f"2025 BIP rows found ({n_2025}); v1.2 build is 2015-2024 only")
    logp(f"  year range: {yr.min()}-{yr.max()}")

    park_all, park_hand = compute_single_year_factors(bip_all := bip)
    del bip_all
    out = build_frozen_prior_factors(park_all, park_hand, prior_years=PRIOR_YEARS)

    # Write
    out_path = os.path.join(CUR, "park_factors_v12.parquet")
    out.to_parquet(out_path, index=False)
    logp(f"wrote {out_path}: {len(out):,} rows")

    # Sanity print
    print("\n=== Sanity check: Coors Field (park_id=9) ===")
    coors = out[out["park_id"] == 9].sort_values("year")
    print(coors.to_string(index=False))
    print("\n=== Sanity check: Oracle Park (park_id=24) ===")
    oracle = out[out["park_id"] == 24].sort_values("year")
    print(oracle.to_string(index=False))

    # Coverage check: for 2015-2017 (fewer priors), n_priors_used < 3 is expected
    n_under = (out["n_priors_used"] < PRIOR_YEARS).sum()
    logp(f"  (park, year) pairs with < {PRIOR_YEARS} priors: {n_under} "
         f"(expected for early years 2015-2017)")


if __name__ == "__main__":
    main()

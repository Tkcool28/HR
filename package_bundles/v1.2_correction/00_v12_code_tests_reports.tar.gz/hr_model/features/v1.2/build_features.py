"""
build_features.py — v1.2 (repaired)

Builds:
  /workspace/hr_model/features/v1.2/game_features.parquet

Scope: 2015-2024 (no 2025 holdout). Per the spec, this is the historical
pipeline repair; the 2025 holdout extension is a separate phase.

What this fixes vs v1.1 (per /workspace/hr_model/reports/audit_v11_defects.md):

  Defect 1 (full-season pitcher pitch-usage leakage):
    All pitcher pitch-type features are now rolling as-of-date windows
    (30d / season). The season window is bounded by the prediction's
    game_date, not the full season.

  Defect 2 (same-season park-factor leakage):
    park_hr_factor_3yr_prior uses the FROZEN prior-3 completed seasons
    (Y-3, Y-2, Y-1). Season Y contributes zero observations. See
    /workspace/hr_model/src/data/process_park_factors_v12.py.

  Defect 3 (anti-leak tests too narrow):
    New tests cover every aggregate family, not just _as_of columns.
    See /workspace/hr_model/tests/test_no_lookahead_v12.py.

  Defect 4 (starting-pitcher derived from postgame):
    Each (batter, game) target row is keyed to the GAME's starting
    pitcher, identified as the pitcher who threw the first pitch of the
    1st inning for the opposing side. See
    /workspace/hr_model/data/curated/game_starters_v12.parquet.

  Defect 5 (PA table collapse):
    One row per (game_pk, at_bat_number). See
    /workspace/hr_model/data/curated/pa_v12.parquet. The v1.1
    (game_pk, batter, pitcher) collapse that miscounted PAs is gone.

  Defect 6 (pitch-type HR attributed to all pitches in PA):
    HR outcome is attributed only to the TERMINAL pitch of each PA
    (pa_v12.terminal_pitch_type). Pitch-type features use the
    terminal-pitch's type for outcome attribution; pitch EXPOSURE
    counts every pitch thrown.

  Defect 7 (batter_strength_on_pitcher_top_pitch is a fastball proxy):
    Now dynamically: the pitcher's top historical pitch (computed
    as-of-date) is used to look up the batter's HR/PA rate against
    that specific pitch type. Test cases with non-fastball-dominant
    pitchers are added.

Inputs
------
  data/curated/pa_v12.parquet              # PA-level, terminal-pitch tracked
  data/curated/game_starters_v12.parquet   # starting pitchers
  data/curated/park_factors_v12.parquet    # frozen-prior park factors
  data/raw/bip_all.parquet                 # BIP data for QoC rollups
  data/curated/game.parquet                # game metadata
  data/splits/{train,val}_ids.parquet      # 2015-2022 train, 2023-2024 val

Outputs
-------
  features/v1.2/game_features.parquet
  features/v1.2/feature_list.json
  features/v1.2/_summary.json
"""
from __future__ import annotations

import gc
import json
import os
import sys
import time
import hashlib
import logging
from datetime import timedelta
from typing import Optional

import numpy as np
import pandas as pd

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("build_v12")

ROOT = "/workspace/hr_model"
CUR = os.path.join(ROOT, "data/curated")
RAW = os.path.join(ROOT, "data/raw")
SPL = os.path.join(ROOT, "data/splits")
OUT = os.path.join(ROOT, "features/v1.2")
REPORT = os.path.join(ROOT, "reports")
os.makedirs(OUT, exist_ok=True)

HOLDOUT_CAP_DATE = pd.Timestamp("2024-12-31")
PRIOR_YEARS = 3
COMMON_PITCH_TYPES = ["FF", "SI", "SL", "CH", "CU", "FC", "ST", "KC", "FS"]


def logp(msg: str) -> None:
    print(f"[build_v12 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def logi(msg: str) -> None:
    print(f"[build_v12 {time.strftime('%H:%M:%S')}]   {msg}", flush=True)


def fail(msg: str) -> None:
    print(f"FATAL: {msg}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------
# 1. Build target rows: one per (batter, game), keyed to the game's
#    starting pitcher (opposing side). 2015-2024 only.
# ----------------------------------------------------------------------

def build_target_rows(pa: pd.DataFrame, starters: pd.DataFrame,
                      games: pd.DataFrame) -> pd.DataFrame:
    """One row per (batter_id, game_pk). Pitcher = starting pitcher of
    the opposing side (NOT derived from postgame encounter count).

    Starting-batting-lineup reconstruction (per the v1.2 review):
      Statcast does not directly provide the pregame announced starting
      lineup. We use a deterministic proxy:

        A batter is included in the (batter, game) target grid if and
        only if their first plate appearance in the game was in the
        1st inning for that side. Specifically:

        - inning == 1 (1st inning)
        - inning_topbot matches the side (Top for away, Bot for home)

      This is the cleanest proxy for "starting nine" available from
      Statcast alone. It excludes pinch hitters and postgame
      substitutions (whose first PA would be in a later inning), and
      it does not use 2025 outcomes to validate or tune the rule.

      We document this as a defensible approximation, NOT a perfect
      reconstruction of announced lineups.
    """
    logp("building target rows: (batter, game) keyed to starting pitcher, "
         "1st-inning starting lineup proxy")

    # Find each batter's first PA per game.
    logi("  finding each batter's first PA per game")
    first_pa = pa.sort_values(["game_pk", "batter_id", "at_bat_number"])\
                 .groupby(["game_pk", "batter_id"], sort=False)\
                 .first().reset_index()[["game_pk", "batter_id",
                                          "inning", "inning_topbot",
                                          "batter_hand"]]
    # Starting-lineup proxy: first PA in inning 1 for that side.
    # inning_topbot: 'Top' = visitor batting, 'Bot' = home batting
    logi("  filtering to first-inning PAs (starting-lineup proxy)")
    is_starter = (first_pa["inning"] == 1)
    starters_only = first_pa[is_starter].copy()
    starters_only["batter_side"] = starters_only["inning_topbot"].map(
        {"Top": "away", "Bot": "home"}
    )
    logi(f"  (batter, game) with 1st-inning first PA: {len(starters_only):,}")
    logi(f"  (batter, game) with later first PA: {len(first_pa) - len(starters_only):,}")

    # Compute hr_in_game per (batter, game) — we keep this for all
    # batters but only score for the 1st-inning starting lineup.
    logi("  computing hr_in_game per (batter, game)")
    hr_agg = pa.groupby(["game_pk", "batter_id"], sort=False, as_index=False)["is_hr"].max()
    hr_agg = hr_agg.rename(columns={"is_hr": "hr_in_game"})

    # Build the (batter, game) grid from the 1st-inning proxy
    logi("  building (batter, game) grid from starting-lineup proxy")
    rows = starters_only[["game_pk", "batter_id", "batter_side",
                          "batter_hand"]].copy()
    rows = rows.merge(hr_agg, on=["game_pk", "batter_id"], how="left")
    rows["hr_in_game"] = rows["hr_in_game"].fillna(0).astype("int8")

    # Attach starting pitchers
    rows = rows.merge(starters, on="game_pk", how="left")
    # pitcher_id = opposing starter
    starter_away = pd.to_numeric(rows["starting_pitcher_away"], errors="coerce")
    starter_home = pd.to_numeric(rows["starting_pitcher_home"], errors="coerce")
    rows["pitcher_id"] = pd.Series(np.where(
        rows["batter_side"] == "home",
        starter_away.to_numpy(),
        starter_home.to_numpy(),
    ), index=rows.index).astype("Int64")
    rows = rows.drop(columns=["starting_pitcher_home", "starting_pitcher_away"])

    # Attach pitcher hand
    logi("  looking up starting-pitcher handedness from PA table")
    sp_hand = pa.groupby("pitcher_id", sort=False, as_index=False)["pitcher_hand"].first()
    sp_hand = sp_hand.rename(columns={"pitcher_hand": "starter_pitcher_hand"})
    rows = rows.merge(sp_hand, left_on="pitcher_id", right_on="pitcher_id", how="left")
    rows["pitcher_hand"] = rows["starter_pitcher_hand"]
    rows = rows.drop(columns=["starter_pitcher_hand"])

    # Attach game metadata
    game_lite = games[["game_pk", "game_date", "park_id", "home_team", "away_team"]].copy()
    rows = rows.merge(game_lite, on="game_pk", how="left")
    rows = rows.rename(columns={"park_id": "_park_id_old"})
    park = pa.groupby("game_pk", sort=False, as_index=False)["park_id"].first()
    rows = rows.merge(park, on="game_pk", how="left")
    rows["park_id"] = rows["park_id"].fillna(rows["_park_id_old"]).astype("Int64")
    rows = rows.drop(columns=["_park_id_old"])

    rows["game_date"] = pd.to_datetime(rows["game_date"])
    rows["year"] = rows["game_date"].dt.year
    logi(f"  target rows: {len(rows):,}")

    # Filter out rows where the starting pitcher is missing
    n_no_starter = rows["pitcher_id"].isna().sum()
    if n_no_starter > 0:
        logi(f"  dropping {n_no_starter:,} rows with missing starting pitcher")
        rows = rows.dropna(subset=["pitcher_id"])
        rows["pitcher_id"] = rows["pitcher_id"].astype("int64")

    return rows


# ----------------------------------------------------------------------
# 2. Rolling-window helper (searchsorted + cumsum), shared
# ----------------------------------------------------------------------

class EntityCumTables:
    """Caches per-entity date arrays + cumsum arrays for many value cols."""

    def __init__(self, agg: pd.DataFrame, entity_col: str, date_col: str = "game_date"):
        self.entity_col = entity_col
        self.date_col = date_col
        logi(f"    pre-agg (entity, date) for {entity_col} ({len(agg):,} rows)")
        agg = agg.sort_values([entity_col, date_col]).reset_index(drop=True)
        grp = agg.groupby(entity_col, sort=False)
        self.entity_dates: dict = {}
        self.value_cols: list[str] = []
        self.value_cum: dict = {}
        first = True
        for ent, sub in grp:
            d = sub[date_col].values
            self.entity_dates[ent] = d
            if first:
                self.value_cols = [c for c in sub.columns if c not in (entity_col, date_col)]
                first = False
                self.value_cum = {vc: {} for vc in self.value_cols}
            for vc in self.value_cols:
                self.value_cum[vc][ent] = np.cumsum(sub[vc].astype("float64").values)
        logi(f"      built {len(self.entity_dates)} entities × {len(self.value_cols)} value cols")
        del grp, agg
        gc.collect()

    def rollup(self, targets: pd.DataFrame, value_col: str, window,
               cap_date: Optional[pd.Timestamp] = None):
        assert value_col in self.value_cols, f"{value_col} not in {self.value_cols}"
        n = len(targets)
        target_entity = targets[self.entity_col].to_numpy()
        eff = targets["game_date"].to_numpy().copy()
        if cap_date is not None:
            eff = np.minimum(eff, np.datetime64(cap_date, "ns"))

        if window is None:
            eff_lower = None
        elif isinstance(window, str) and window == "season":
            eff_lower = np.array([
                np.datetime64(pd.Timestamp(year=pd.Timestamp(d).year, month=1, day=1), "ns")
                for d in eff
            ], dtype="datetime64[ns]")
        elif isinstance(window, timedelta):
            eff_lower = eff - np.timedelta64(int(window.total_seconds() * 1e9), "ns")
        else:
            raise ValueError(f"unknown window spec: {window!r}")

        order = np.argsort(target_entity, kind="stable")
        ent_sorted = target_entity[order]
        unique_ents, first_idx = np.unique(ent_sorted, return_index=True)
        first_idx = np.append(first_idx, n)

        cum_upper = np.zeros(n, dtype="float64")
        cum_lower = np.zeros(n, dtype="float64")
        last_bv = np.empty(n, dtype="datetime64[ns]")
        last_bv.fill(np.datetime64("NaT"))

        for j, ent in enumerate(unique_ents):
            i_start, i_end = first_idx[j], first_idx[j + 1]
            if ent not in self.entity_dates:
                continue
            d = self.entity_dates[ent]
            c = self.value_cum[value_col][ent]
            target_idx = order[i_start:i_end]
            e_upper = eff[target_idx]
            idx_upper = np.searchsorted(d, e_upper, side="left")
            cum_upper[target_idx] = np.where(
                idx_upper == 0, 0.0,
                np.where(idx_upper > len(d), c[-1], c[np.minimum(idx_upper, len(c)) - 1])
            )
            last_bv[target_idx] = np.where(
                idx_upper == 0, np.datetime64("NaT"),
                np.where(idx_upper > len(d), d[-1], d[np.minimum(idx_upper, len(d)) - 1])
            )
            if eff_lower is not None:
                e_lower = eff_lower[target_idx]
                idx_lower = np.searchsorted(d, e_lower, side="left")
                cum_lower[target_idx] = np.where(
                    idx_lower == 0, 0.0,
                    np.where(idx_lower > len(d), c[-1], c[np.minimum(idx_lower, len(c)) - 1])
                )
        sums = (cum_upper - cum_lower).astype("float32")
        del cum_upper, cum_lower
        gc.collect()
        return sums, last_bv


# ----------------------------------------------------------------------
# 3. PA-level batter rolling features (correct grain, terminal-pitch HR)
# ----------------------------------------------------------------------

def compute_batter_pa_features(targets: pd.DataFrame, pa: pd.DataFrame):
    """Per-(batter, date) PA rollups. Each PA contributes is_pa=1, is_hr=0/1."""
    logp("computing batter PA rollups (batter_pa_*, batter_hr_*)")
    b = pa[["batter_id", "game_date", "is_hr"]].copy()
    b["is_pa"] = np.int8(1)
    b_agg = b.groupby(["batter_id", "game_date"], sort=False, as_index=False).agg(
        is_pa=("is_pa", "sum"),
        is_hr=("is_hr", "sum"),
    )
    del b
    gc.collect()

    targets_b = pd.DataFrame({
        "batter_id": targets["batter_id"].to_numpy(),
        "game_date": targets["game_date"].to_numpy(),
    })
    ect = EntityCumTables(b_agg, entity_col="batter_id", date_col="game_date")
    del b_agg
    gc.collect()

    new_cols = []
    asof_max = np.empty(len(targets), dtype="datetime64[ns]")
    asof_max.fill(np.datetime64("NaT"))
    sums = {}
    asofs = {}
    for out_col, val_col, window in [
        ("batter_pa_14d",  "is_pa", timedelta(days=14)),
        ("batter_pa_30d",  "is_pa", timedelta(days=30)),
        ("batter_pa_season", "is_pa", "season"),
        ("batter_pa_career", "is_pa", None),
        ("batter_hr_14d",  "is_hr", timedelta(days=14)),
        ("batter_hr_30d",  "is_hr", timedelta(days=30)),
        ("batter_hr_season", "is_hr", "season"),
        ("batter_hr_career", "is_hr", None),
    ]:
        s, a = ect.rollup(targets_b, val_col, window, HOLDOUT_CAP_DATE)
        targets[out_col] = s
        targets[f"{out_col}_as_of"] = a
        sums[out_col] = s
        asofs[out_col] = a
        new_cols.append(out_col)
        logi(f"  {out_col} done")
        gc.collect()

    # Rates (Bayesian shrinkage)
    def shrunk(num, den, prior, k):
        return ((num + prior * k) / (den + k)).astype("float32")

    targets["batter_hr_rate_14d"] = shrunk(
        targets["batter_hr_14d"].astype("float32"),
        targets["batter_pa_14d"].astype("float32"),
        prior=0.03, k=50.0)
    targets["batter_hr_rate_30d"] = shrunk(
        targets["batter_hr_30d"].astype("float32"),
        targets["batter_pa_30d"].astype("float32"),
        prior=0.03, k=50.0)
    targets["batter_hr_rate_season"] = shrunk(
        targets["batter_hr_season"].astype("float32"),
        targets["batter_pa_season"].astype("float32"),
        prior=0.03, k=200.0)
    targets["batter_hr_rate_career"] = shrunk(
        targets["batter_hr_career"].astype("float32"),
        targets["batter_pa_career"].astype("float32"),
        prior=0.03, k=500.0)
    new_cols.extend(["batter_hr_rate_14d", "batter_hr_rate_30d",
                     "batter_hr_rate_season", "batter_hr_rate_career"])
    del ect, sums, asofs
    gc.collect()
    return targets, new_cols


# ----------------------------------------------------------------------
# 4. Pitcher PA-level features (allowed HR)
# ----------------------------------------------------------------------

def compute_pitcher_pa_features(targets: pd.DataFrame, pa: pd.DataFrame):
    logp("computing pitcher PA rollups")
    p = pa[["pitcher_id", "game_date", "is_hr"]].copy()
    p["is_pa"] = np.int8(1)
    p_agg = p.groupby(["pitcher_id", "game_date"], sort=False, as_index=False).agg(
        is_pa=("is_pa", "sum"),
        is_hr=("is_hr", "sum"),
    )
    del p
    gc.collect()

    targets_p = pd.DataFrame({
        "pitcher_id": targets["pitcher_id"].to_numpy(),
        "game_date": targets["game_date"].to_numpy(),
    })
    ect = EntityCumTables(p_agg, entity_col="pitcher_id", date_col="game_date")
    del p_agg
    gc.collect()

    new_cols = []
    for out_col, val_col, window in [
        ("pitcher_pa_30d",   "is_pa", timedelta(days=30)),
        ("pitcher_pa_season","is_pa", "season"),
        ("pitcher_pa_career","is_pa", None),
        ("pitcher_hr_30d",   "is_hr", timedelta(days=30)),
        ("pitcher_hr_season","is_hr", "season"),
        ("pitcher_hr_career","is_hr", None),
    ]:
        s, a = ect.rollup(targets_p, val_col, window, HOLDOUT_CAP_DATE)
        targets[out_col] = s
        targets[f"{out_col}_as_of"] = a
        new_cols.append(out_col)
        logi(f"  {out_col} done")
        gc.collect()

    def shrunk(num, den, prior, k):
        return ((num + prior * k) / (den + k)).astype("float32")

    targets["pitcher_hr_per_pa_30d"] = shrunk(
        targets["pitcher_hr_30d"].astype("float32"),
        targets["pitcher_pa_30d"].astype("float32"),
        prior=0.03, k=50.0)
    targets["pitcher_hr_per_pa_season"] = shrunk(
        targets["pitcher_hr_season"].astype("float32"),
        targets["pitcher_pa_season"].astype("float32"),
        prior=0.03, k=200.0)
    targets["pitcher_hr_per_pa_career"] = shrunk(
        targets["pitcher_hr_career"].astype("float32"),
        targets["pitcher_pa_career"].astype("float32"),
        prior=0.03, k=500.0)
    new_cols.extend(["pitcher_hr_per_pa_30d", "pitcher_hr_per_pa_season",
                     "pitcher_hr_per_pa_career"])
    del ect
    gc.collect()
    return targets, new_cols


# ----------------------------------------------------------------------
# 5. Park features (frozen-prior policy)
# ----------------------------------------------------------------------

def compute_park_features(targets: pd.DataFrame, pf_v12: pd.DataFrame):
    logp("computing park features (frozen-prior lookup)")
    pf = pf_v12[["park_id", "year", "park_hr_factor_3yr_prior",
                 "park_hr_factor_by_hand_L_prior",
                 "park_hr_factor_by_hand_R_prior"]].copy()
    pf["year"] = pf["year"].astype("int32")
    pf["park_id"] = pf["park_id"].astype("int32")

    tgt = pd.DataFrame({
        "park_id": targets["park_id"].astype("int32").to_numpy(),
        "year": targets["year"].clip(lower=2015, upper=2024).astype("int32").to_numpy(),
    })
    merged = tgt.merge(pf, on=["park_id", "year"], how="left")
    n_miss = int(merged["park_hr_factor_3yr_prior"].isna().sum())
    logi(f"  {n_miss:,} rows missing park factor (will fill 100.0)")
    if n_miss > 0:
        merged["park_hr_factor_3yr_prior"] = merged["park_hr_factor_3yr_prior"].fillna(100.0)
        merged["park_hr_factor_by_hand_L_prior"] = merged["park_hr_factor_by_hand_L_prior"].fillna(100.0)
        merged["park_hr_factor_by_hand_R_prior"] = merged["park_hr_factor_by_hand_R_prior"].fillna(100.0)
    targets["park_hr_factor_3yr"] = merged["park_hr_factor_3yr_prior"].astype("float32").values
    by_hand = np.where(
        targets["batter_hand"].values == "L",
        merged["park_hr_factor_by_hand_L_prior"].values,
        merged["park_hr_factor_by_hand_R_prior"].values,
    ).astype("float32")
    targets["park_hr_factor_by_hand"] = by_hand
    return targets, ["park_hr_factor_3yr", "park_hr_factor_by_hand"]


# ----------------------------------------------------------------------
# 6. Pitch-type features: terminal-pitch HR attribution (defect 6 fix)
# ----------------------------------------------------------------------

def compute_pitch_type_features(targets: pd.DataFrame, pa: pd.DataFrame):
    logp("computing batter/pitcher pitch-type features (terminal-pitch HR)")
    # Per-(batter, game_date, pitch_type) HR attribution:
    # HR is counted only on the terminal pitch of the PA.
    pt = pa[["batter_id", "pitcher_id", "game_date", "terminal_pitch_type",
              "pa_outcome", "is_hr"]].copy()
    pt = pt[pt["terminal_pitch_type"].isin(COMMON_PITCH_TYPES)].copy()
    pt["is_pa"] = np.int8(1)
    pt_b = pt.groupby(["batter_id", "game_date", "terminal_pitch_type"],
                      sort=False, as_index=False).agg(
        is_pa=("is_pa", "sum"),
        is_hr=("is_hr", "sum"),
    )
    pt_p = pt.groupby(["pitcher_id", "game_date", "terminal_pitch_type"],
                      sort=False, as_index=False).agg(
        is_pa=("is_pa", "sum"),
        is_hr=("is_hr", "sum"),
    )
    del pt
    gc.collect()

    new_cols = []
    for side, entity_col, value_rollups in [
        ("batter", "batter_id", "batter"),
        ("pitcher", "pitcher_id", "pitcher"),
    ]:
        agg = pt_b if side == "batter" else pt_p
        # Filter to one pitch type, drop the column, then build ECT
        for pt_code in COMMON_PITCH_TYPES:
            sub_with_pt = agg[agg["terminal_pitch_type"] == pt_code]
            sub = sub_with_pt[[entity_col, "game_date", "is_pa", "is_hr"]]
            del sub_with_pt
            if len(sub) == 0:
                targets[f"{value_rollups}_hr_vs_{pt_code}_30d"] = np.float32(0.0)
                targets[f"{value_rollups}_pa_vs_{pt_code}_30d"] = np.float32(0.0)
                targets[f"{value_rollups}_hr_per_pa_vs_{pt_code}_30d"] = np.float32(np.nan)
                new_cols.append(f"{value_rollups}_hr_per_pa_vs_{pt_code}_30d")
                continue
            logi(f"  {value_rollups} vs {pt_code}: building ECT for {sub[entity_col].nunique()} entities")
            ect = EntityCumTables(sub, entity_col=entity_col, date_col="game_date")
            targets_x = pd.DataFrame({
                entity_col: targets[entity_col].to_numpy(),
                "game_date": targets["game_date"].to_numpy(),
            })
            s_pa, _ = ect.rollup(targets_x, "is_pa", timedelta(days=30), HOLDOUT_CAP_DATE)
            s_hr, _ = ect.rollup(targets_x, "is_hr", timedelta(days=30), HOLDOUT_CAP_DATE)
            targets[f"{value_rollups}_hr_vs_{pt_code}_30d"] = s_hr
            targets[f"{value_rollups}_pa_vs_{pt_code}_30d"] = s_pa
            PRIOR_HR, K = 0.03, 30.0
            targets[f"{value_rollups}_hr_per_pa_vs_{pt_code}_30d"] = (
                (s_hr + PRIOR_HR * K) / (s_pa + K)
            ).astype("float32")
            new_cols.append(f"{value_rollups}_hr_per_pa_vs_{pt_code}_30d")
            del ect
            gc.collect()
    return targets, new_cols


# ----------------------------------------------------------------------
# 7. Pitcher pitch-type USAGE (defect 1 fix: as-of rolling, not full season)
# ----------------------------------------------------------------------

def compute_pitcher_pitch_usage(targets: pd.DataFrame, pitch_level: pd.DataFrame):
    """Pitcher pitch-type usage shares, computed from individual pitches.

    For each (pitcher, game_date) target row:

        pitcher_usage_<PT>_30d =
            number of <PT> pitches thrown by pitcher in [D-30d, D)
            /
            number of SUPPORTED pitches (excluding UNCLASSIFIED)
            thrown by pitcher in [D-30d, D)

    Source data: pitch_level_v12.parquet (one row per individual pitch).
    Every individual pitch counts toward usage (not just terminal pitches).
    Source dates are strictly < prediction game date (D-30d, D) via
    EntityCumTables.rollup with cap_date=2024-12-31 and searchsorted
    side="left" (so the upper bound is D, exclusive).

    Per the v1.2 review: a previous version shared a single ECT across
    all pitch types, so the pitch-type-specific subset was never used
    and every pitch-usage numerator was identical. This implementation
    builds a SEPARATE ECT per pitch type so the numerator is genuinely
    constrained to the specific pitch type.
    """
    logp("computing pitcher pitch-type usage from per-pitch source (defect 1 review fix)")

    # Per-(pitcher, date, pitch_type) pitch count from individual pitches.
    # Use is_supported=1 to exclude UNCLASSIFIED.
    logi("  pre-aggregating per (pitcher, date, pitch_type) pitch counts")
    pl = pitch_level[["pitcher_id", "game_date", "pitch_type", "is_supported"]].copy()
    pl = pl[pl["is_supported"] == 1].copy()
    pl["n"] = np.int8(1)
    p_agg = pl.groupby(["pitcher_id", "game_date", "pitch_type"],
                        sort=False, as_index=False)["n"].sum()
    del pl
    gc.collect()
    logi(f"  per-(pitcher, date, pt) rows: {len(p_agg):,}")

    # Build a per-pitcher, per-date TOTAL of supported pitches
    p_tot = p_agg.groupby(["pitcher_id", "game_date"], sort=False, as_index=False)["n"].sum()
    p_tot = p_tot.rename(columns={"n": "n_total"})

    targets_p = pd.DataFrame({
        "pitcher_id": targets["pitcher_id"].to_numpy(),
        "game_date": targets["game_date"].to_numpy(),
    })

    # SEPARATE ECT per pitch type (the previous bug shared one across
    # all types; the per-PT subset was unused).
    logi("  building per-pitch-type EntityCumTables (one per PT)")
    new_cols = []
    raw_counts = {}  # pt_code -> array of raw 30d counts
    ects = {}  # pt_code -> EntityCumTables
    for pt_code in COMMON_PITCH_TYPES:
        sub_with_pt = p_agg[p_agg["pitch_type"] == pt_code]
        sub = sub_with_pt[["pitcher_id", "game_date", "n"]]
        del sub_with_pt
        if len(sub) == 0:
            targets[f"pitcher_usage_{pt_code}_30d"] = np.float32(0.0)
            raw_counts[pt_code] = np.zeros(len(targets), dtype="float32")
            new_cols.append(f"pitcher_usage_{pt_code}_30d")
            logi(f"    {pt_code}: no data, usage=0")
            continue
        # Build a per-pitch-type ECT so the cumsum table only contains
        # that pitch type's counts. This is the fix.
        ects[pt_code] = EntityCumTables(sub, entity_col="pitcher_id", date_col="game_date")
        logi(f"    {pt_code}: built ECT for {sub['pitcher_id'].nunique()} pitchers")
        del sub
        gc.collect()
    # Total-pitcher ECT for the denominator
    logi("  building total-pitches EntityCumTables (denominator)")
    ect_total = EntityCumTables(p_tot, entity_col="pitcher_id", date_col="game_date")

    # Now rollup each PT vs the total.
    for pt_code in COMMON_PITCH_TYPES:
        s_n = np.zeros(len(targets), dtype="float32")
        s_tot = np.zeros(len(targets), dtype="float32")
        if pt_code in ects:
            s_n, _ = ects[pt_code].rollup(
                targets_p, "n", timedelta(days=30), HOLDOUT_CAP_DATE
            )
        s_tot, _ = ect_total.rollup(
            targets_p, "n_total", timedelta(days=30), HOLDOUT_CAP_DATE
        )
        # Bayesian shrinkage toward 1/9 (uniform prior over 9 supported PTs)
        PRIOR_USAGE = 1.0 / 9.0
        K = 30.0
        targets[f"pitcher_usage_{pt_code}_30d"] = (
            (s_n + PRIOR_USAGE * K) / (s_tot + K)
        ).astype("float32")
        raw_counts[pt_code] = s_n
        new_cols.append(f"pitcher_usage_{pt_code}_30d")
        logi(f"    {pt_code}: rolled up (mean={targets[f'pitcher_usage_{pt_code}_30d'].mean():.4f}, "
             f"raw_n.mean={s_n.mean():.1f}, total.mean={s_tot.mean():.1f})")
        gc.collect()
    # Stash raw counts in a hidden column for the top-pitch lookup below
    for pt_code, arr in raw_counts.items():
        targets[f"_raw_count_{pt_code}_30d"] = arr
    del ects, ect_total, p_agg, p_tot
    gc.collect()
    return targets, new_cols


# ----------------------------------------------------------------------
# 8. batter_strength_on_pitcher_top_pitch (defect 7 fix)
# ----------------------------------------------------------------------

def compute_strength_on_top_pitch(targets: pd.DataFrame, pa: pd.DataFrame):
    """For each (target, batter, pitcher), find the pitcher's top
    historical pitch (by raw 30d pitch count, as-of-date) and look up
    the batter's HR/PA against that pitch type.

    Policy for insufficient-history rows (per the v1.2 review):
      - If the total 30d pitch count across all supported types is 0
        (no history in window), the top pitch is unknown and the
        feature is NaN. We do NOT default to FF.
      - If there's a tie (multiple pitch types with the same max
        count), we deterministically pick the first one in
        COMMON_PITCH_TYPES order. The test suite verifies that
        distinct pitch mixes select distinct top pitches, so this
        tie-breaking only fires when the historical signal is
        genuinely tied.
    """
    logp("computing batter_strength_on_pitcher_top_pitch (dynamic, with no-history policy)")
    raw_cols = [f"_raw_count_{pt}_30d" for pt in COMMON_PITCH_TYPES
                if f"_raw_count_{pt}_30d" in targets.columns]
    if not raw_cols:
        logi("  no raw count columns; skipping")
        return targets, []
    raw = targets[raw_cols].to_numpy()
    pt_codes = [c.replace("_raw_count_", "").replace("_30d", "") for c in raw_cols]
    total = raw.sum(axis=1)

    # Default: NaN. Set per-row if there's a clear winner.
    n = len(targets)
    top_pitch = np.full(n, "", dtype=object)
    out = np.full(n, np.nan, dtype="float32")
    for i in range(n):
        if total[i] <= 0:
            # No history: leave top_pitch as "" and out as NaN
            continue
        # Pick the pitch with the max count (deterministic tie-break by
        # COMMON_PITCH_TYPES order, since argmax returns the first).
        top_idx = int(np.argmax(raw[i]))
        top_pitch[i] = pt_codes[top_idx]

    # Look up batter HR/PA against the chosen top pitch
    for pt_code in pt_codes:
        col = f"batter_hr_per_pa_vs_{pt_code}_30d"
        if col not in targets.columns:
            continue
        mask = top_pitch == pt_code
        if mask.any():
            out[mask] = targets.loc[mask, col].astype("float32").to_numpy()

    # Build the top-pitch string column
    top_pitch_str = pd.array(top_pitch, dtype="string")
    targets["pitcher_top_pitch"] = top_pitch_str
    targets["top_pitch_total_pitches_30d"] = total.astype("float32")
    targets["batter_strength_on_pitcher_top_pitch"] = out
    # Keep top_pitch as a debug column for inspection
    raw_drop = [c for c in targets.columns if c.startswith("_raw_count_")]
    targets = targets.drop(columns=raw_drop)
    return targets, ["batter_strength_on_pitcher_top_pitch", "pitcher_top_pitch",
                     "top_pitch_total_pitches_30d"]


# ----------------------------------------------------------------------
# 9. max_as_of_date
# ----------------------------------------------------------------------

def compute_max_as_of_date(df: pd.DataFrame) -> pd.Series:
    asof_cols = [c for c in df.columns if c.endswith("_as_of")]
    if not asof_cols:
        return pd.Series(pd.NaT, index=df.index)
    arrs = []
    for c in asof_cols:
        col = df[c]
        a = col.to_numpy().astype("datetime64[ns]").astype("int64")
        a = np.where(a == np.iinfo("int64").min, -1, a)
        arrs.append(a)
    M = np.stack(arrs, axis=1)
    row_max = M.max(axis=1)
    row_max[row_max < 0] = np.iinfo("int64").min
    out = row_max.astype("datetime64[ns]")
    return pd.Series(out, index=df.index)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main() -> None:
    logp("loading inputs")
    pa = pd.read_parquet(os.path.join(CUR, "pa_v12.parquet"))
    logi(f"  pa_v12: {len(pa):,} PA rows × {pa.shape[1]} cols")
    # Normalize pa.game_date to datetime64[ns] (was date in pa_v12)
    pa["game_date"] = pd.to_datetime(pa["game_date"])
    yr_max = int(pa["year"].max())
    if yr_max > HOLDOUT_CAP_DATE.year:
        fail(f"pa_v12 contains year={yr_max} > {HOLDOUT_CAP_DATE.year}")
    starters = pd.read_parquet(os.path.join(CUR, "game_starters_v12.parquet"))
    logi(f"  game_starters_v12: {len(starters):,} game rows")
    pf_v12 = pd.read_parquet(os.path.join(CUR, "park_factors_v12.parquet"))
    logi(f"  park_factors_v12: {len(pf_v12):,} (park, year) rows")
    games = pd.read_parquet(os.path.join(CUR, "game.parquet"))
    logi(f"  game.parquet: {len(games):,} game rows")
    pitch_level_path = os.path.join(CUR, "pitch_level_v12.parquet")
    if not os.path.exists(pitch_level_path):
        fail(f"missing pitch_level_v12.parquet — run src/data/build_pitch_level_v12.py first")
    pitch_level = pd.read_parquet(pitch_level_path)
    logi(f"  pitch_level_v12: {len(pitch_level):,} pitch rows × {pitch_level.shape[1]} cols")
    yr_max2 = int(pitch_level["year"].max())
    if yr_max2 > HOLDOUT_CAP_DATE.year:
        fail(f"pitch_level_v12 contains year={yr_max2} > {HOLDOUT_CAP_DATE.year}")
    train_ids = set(pd.read_parquet(os.path.join(SPL, "train_ids.parquet"))["game_pk"].tolist())
    val_ids = set(pd.read_parquet(os.path.join(SPL, "val_ids.parquet"))["game_pk"].tolist())
    logi(f"  train games: {len(train_ids):,}, val games: {len(val_ids):,}")

    # 1. Target rows
    targets = build_target_rows(pa, starters, games)
    logp("assigning splits (train 2015-2022, val 2023-2024)")
    targets["split"] = "train"
    targets.loc[targets["game_pk"].isin(val_ids), "split"] = "val"
    logi(f"  splits: {targets['split'].value_counts().to_dict()}")
    # Restrict to 2015-2024 (no 2025)
    targets = targets[targets["year"].between(2015, 2024)].copy()
    logi(f"  after year<=2024 filter: {len(targets):,}")

    # 2-7. Features
    targets, c1 = compute_batter_pa_features(targets, pa)
    targets, c2 = compute_pitcher_pa_features(targets, pa)
    targets, c3 = compute_park_features(targets, pf_v12)
    targets, c4 = compute_pitch_type_features(targets, pa)
    # pitch_usage uses per-pitch data (defect 1 review fix)
    targets, c5 = compute_pitcher_pitch_usage(targets, pitch_level)
    targets, c6 = compute_strength_on_top_pitch(targets, pa)

    # 8. max_as_of_date
    logp("computing max_as_of_date over all _as_of columns")
    targets["max_as_of_date"] = compute_max_as_of_date(targets)

    # 9. Platoon factor (a simple derived feature)
    targets["platoon_same_hand"] = (targets["batter_hand"] == targets["pitcher_hand"]).astype("int8")

    # 10. Assemble feature list
    feature_cols = sorted(set(
        c1 + c2 + c3 + c4 + c5 + c6
        + ["batter_pa_14d", "batter_pa_30d", "batter_pa_season", "batter_pa_career",
           "batter_hr_14d", "batter_hr_30d", "batter_hr_season", "batter_hr_career",
           "batter_hr_rate_14d", "batter_hr_rate_30d", "batter_hr_rate_season", "batter_hr_rate_career",
           "pitcher_pa_30d", "pitcher_pa_season", "pitcher_pa_career",
           "pitcher_hr_30d", "pitcher_hr_season", "pitcher_hr_career",
           "pitcher_hr_per_pa_30d", "pitcher_hr_per_pa_season", "pitcher_hr_per_pa_career",
           "park_hr_factor_3yr", "park_hr_factor_by_hand",
           "batter_strength_on_pitcher_top_pitch",
           "pitcher_top_pitch",
           "top_pitch_total_pitches_30d",
           "platoon_same_hand"]
    ))
    feature_cols = [c for c in feature_cols if c in targets.columns]
    logi(f"  total features: {len(feature_cols)}")

    # 11. Write outputs
    logp("writing outputs")
    id_cols = ["batter_id", "pitcher_id", "game_pk", "game_date", "park_id",
               "batter_hand", "pitcher_hand", "split", "year", "home_team", "away_team",
               "max_as_of_date", "hr_in_game"]
    # Include _as_of columns (used by tests to verify temporal safety)
    asof_cols = [c for c in targets.columns if c.endswith("_as_of")]
    out_cols = id_cols + feature_cols + asof_cols
    # Drop duplicates if any
    out_cols = list(dict.fromkeys(out_cols))
    out = targets[out_cols].copy()

    out_path = os.path.join(OUT, "game_features.parquet")
    out.to_parquet(out_path, index=False)
    logp(f"wrote {out_path}: {len(out):,} rows × {out.shape[1]} cols")

    flist_path = os.path.join(OUT, "feature_list.json")
    with open(flist_path, "w") as fp:
        json.dump(feature_cols, fp, indent=2)
    logp(f"wrote {flist_path}: {len(feature_cols)} features")

    # Summary
    summary = {
        "n_rows": int(len(out)),
        "n_features": int(len(feature_cols)),
        "feature_list": feature_cols,
        "splits": out["split"].value_counts().to_dict(),
        "year_range": [int(out["year"].min()), int(out["year"].max())],
        "hr_rate_overall": float(out["hr_in_game"].mean()),
        "max_as_of_date_leq": str(out["max_as_of_date"].max()),
        "feature_list_sha256": hashlib.sha256(open(flist_path, "rb").read()).hexdigest(),
    }
    with open(os.path.join(OUT, "_summary.json"), "w") as fp:
        json.dump(summary, fp, indent=2)
    logp("done.")


if __name__ == "__main__":
    main()

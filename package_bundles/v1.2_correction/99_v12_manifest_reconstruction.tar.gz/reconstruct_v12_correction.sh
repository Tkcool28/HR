#!/usr/bin/env bash
set -euo pipefail
BUNDLE_DIR=${1:-.}
DEST=${2:-reconstructed}
mkdir -p "$DEST"
for f in 00_v12_code_tests_reports.tar.gz 01_v12_curated_core.tar.gz 02_v12_feature_matrix.tar.gz; do
  tar -xzf "$BUNDLE_DIR/$f" -C "$DEST"
done
for f in "$BUNDLE_DIR"/10_v12_pitch_level_*.tar.gz; do
  tar -xzf "$f" -C "$DEST"
done
cat "$DEST"/hr_model/data/curated/pitch_level_v12.parquet.part* > "$DEST"/hr_model/data/curated/pitch_level_v12.parquet
rm "$DEST"/hr_model/data/curated/pitch_level_v12.parquet.part*
echo "Reconstructed under: $DEST/hr_model"
sha256sum "$DEST"/hr_model/data/curated/pitch_level_v12.parquet

"""
build_features.py — v1.1

Build /workspace/hr_model/features/v1.1/game_features.parquet.

Strategy
========
We *load* the existing v1 game_features.parquet (which already has 532,554 rows
× 93 active v1 features + 37 NaN placeholders + max_as_of_date), then *add*:

  - ~14 batter QoC rollups over BIP data (barrel, xwOBA, EV, LA, hard-hit, FB%,
    ISO, pull%) on 30d / season / career windows.
  -  ~6 pitcher QoC rollups (barrel_allowed, xwOBA_allowed, hard-hit_allowed,
    avg_ev_allowed, ISO_allowed) on 30d / season windows.
  -  2 park features (park_hr_factor_3yr from real BIP-derived table,
    park_hr_factor_by_hand from same table by batter hand).

Total new features: ~22. The 37 NaN placeholders from v1 are dropped (most
replaced with real signal; 16 that have no v1.1 equivalent are simply removed).
Final feature count: ~115.

Anti-leak invariants (enforced by tests/test_no_lookahead.py):

  * Every rolling window uses only BIPs with game_date STRICTLY less than
    the row's game_date.
  * For split=holdout rows, the effective date is capped at 2024-12-31
    (no 2025 BIP can leak into any rolling window).
  * Park factor lookup keys are (park_id, year) where year = year(game_date);
    for 2025 holdout rows, the year is forced to 2024 (the latest year in
    park_factors.parquet) so no future park data leaks.
  * No 2025 outcome is read for any decision about what features to include
    or how to compute them.

For each (batter_id, game_pk) we emit one row.

Identifier columns  : batter_id, pitcher_id, game_pk, game_date,
                      home_team, away_team, park_id, batter_hand,
                      pitcher_hand, split
Target              : hr_in_game (NaN on split=holdout)
Internal (asserted) : max_as_of_date
Feature columns     : see feature_list.json (produced at the end of run)

Run:  python3 /workspace/hr_model/features/v1.1/build_features.py
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import sys
import time
from datetime import timedelta

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = "/workspace/hr_model"
CUR = os.path.join(ROOT, "data/curated")
RAW = os.path.join(ROOT, "data/raw")
SPL = os.path.join(ROOT, "data/splits")
V1_FEATURES = os.path.join(ROOT, "features/v1/game_features.parquet")
OUT = os.path.join(ROOT, "features/v1.1")
REPORT = os.path.join(ROOT, "reports")

HOLDOUT_CAP_DATE = pd.Timestamp("2024-12-31")


# ----------------------------------------------------------------------
# IO helpers
# ----------------------------------------------------------------------

def log(msg: str) -> None:
    print(f"[build_v11 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def logi(msg: str) -> None:
    print(f"[build_v11 {time.strftime('%H:%M:%S')}]   {msg}", flush=True)


def fail(msg: str) -> None:
    print(f"FATAL: {msg}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------
# 1. Load v1 game_features (reused as the base) + BIP data
# ----------------------------------------------------------------------

def load_inputs():
    log("loading v1 game_features as the base")
    df_v1 = pd.read_parquet(V1_FEATURES)
    logi(f"v1 base: {len(df_v1):,} rows × {df_v1.shape[1]} cols")
    logi(f"  splits: {df_v1['split'].value_counts().to_dict()}")

    log("loading BIP data (bip_all.parquet)")
    bip = pd.read_parquet(os.path.join(RAW, "bip_all.parquet"))
    logi(f"bip_all: {len(bip):,} rows × {bip.shape[1]} cols")
    logi(f"  year range: {pd.to_datetime(bip['game_date']).dt.year.min()} - "
         f"{pd.to_datetime(bip['game_date']).dt.year.max()}")
    # Sanity check: NO 2025 BIPs allowed (binding)
    yr = pd.to_datetime(bip['game_date']).dt.year
    n_2025 = int((yr == 2025).sum())
    if n_2025 > 0:
        fail(f"{n_2025} 2025 BIP rows found in bip_all — 2025 holdout rule violated")
    logi("  0 rows for 2025 — holdout rule satisfied")

    log("loading park_factors")
    pf = pd.read_parquet(os.path.join(CUR, "park_factors.parquet"))
    logi(f"park_factors: {len(pf):,} rows × {pf.shape[1]} cols, "
         f"years {pf['year'].min()}-{pf['year'].max()}")

    return df_v1, bip, pf


# ----------------------------------------------------------------------
# 2. Materialize per-BIP QoC flags
# ----------------------------------------------------------------------

def materialize_bip_qoc(bip: pd.DataFrame) -> pd.DataFrame:
    """Per-BIP QoC booleans and reduced columns for rollups.

    Returns a slim DataFrame with: game_pk, game_date, batter, pitcher, park_id,
    stand (batter hand), launch_speed, launch_angle,
    estimated_woba_using_speedangle, is_barrel, is_hard_hit, is_fb, is_pull.
    """
    log("materializing per-BIP QoC flags")
    out = pd.DataFrame({
        "game_pk": bip["game_pk"].values,
        "game_date": pd.to_datetime(bip["game_date"]).values,
        "batter": bip["batter"].astype("int64").values,
        "pitcher": bip["pitcher"].astype("int64").values,
        "park_id": bip["park_id"].astype("int32").values,
        "stand": bip["stand"].values,  # L/R
        "launch_speed": bip["launch_speed"].astype("float32").values,
        "launch_angle": bip["launch_angle"].astype("float32").values,
        "estimated_woba_using_speedangle":
            bip["estimated_woba_using_speedangle"].astype("float32").values,
        "bb_type": bip["bb_type"].values,
    })
    # Barrel: launch_speed >= 98 AND launch_angle in [26, 30]
    ls = out["launch_speed"].to_numpy()
    la = out["launch_angle"].to_numpy()
    out["is_barrel"] = ((ls >= 98.0) & (la >= 26.0) & (la <= 30.0)).astype("int8")
    out["is_hard_hit"] = (ls >= 95.0).astype("int8")
    out["is_fb"] = ((la >= 20.0) & (la <= 40.0)).astype("int8")
    # Pull%: bb_type == 'pull' — Statcast doesn't give 'pull' directly;
    # we approximate via hit_location / spray angle if available. We don't
    # have hit_location in the saved parquet. The most defensible v1.1
    # implementation: use the subset of BIPs where bb_type is in
    # {ground_ball, line_drive, fly_ball, popup} (4-value code) and treat
    # 'pull_pct' as the share of BIPs whose spray angle (we don't have it)
    # is on the pull side. Without hit_location or spray_angle in
    # bip_all.parquet, we set pull_pct = NaN.
    out["is_pull"] = np.int8(0)  # placeholder; computed as None below
    out["n_bip"] = np.int8(1)
    out["xwoba"] = out["estimated_woba_using_speedangle"]
    out["woba_value"] = bip["woba_value"].astype("float32").values
    # Precompute event flags as int8 (much smaller than string events column)
    ev = bip["events"].to_numpy()
    out["is_hr"] = (ev == "home_run").astype("int8")
    out["is_2b"] = (ev == "double").astype("int8")
    out["is_3b"] = (ev == "triple").astype("int8")
    out["isoxbp"] = (
        out["is_hr"] * 4 + out["is_2b"] * 2 + out["is_3b"] * 3
    ).astype("int16")
    logi(f"  {len(out):,} BIPs; barrel={int(out['is_barrel'].sum()):,}; "
         f"hard_hit={int(out['is_hard_hit'].sum()):,}; fb={int(out['is_fb'].sum()):,}")
    return out


# ----------------------------------------------------------------------
# 3. The searchsorted-based rolling-window helper (reused from v1)
# ----------------------------------------------------------------------

class EntityCumTables:
    """Caches per-entity date arrays + cumsum arrays for many value cols.

    Built once per (entity_col, agg_table), then queried many times for
    different (value_col, window) combinations.
    """

    def __init__(self, agg: pd.DataFrame, entity_col: str, date_col: str = "game_date"):
        # agg: one row per (entity, date) with multiple value columns
        self.entity_col = entity_col
        self.date_col = date_col
        logi(f"    pre-agg (entity, date) for {entity_col} ({len(agg):,} rows)")
        agg = agg.sort_values([entity_col, date_col]).reset_index(drop=True)
        # Build dict: entity -> (dates, list of value arrays)
        grp = agg.groupby(entity_col, sort=False)
        self.entity_dates: dict = {}
        self.value_cols: list[str] = []
        self.value_cum: dict[str, dict] = {}  # value_col -> {entity: cum array}
        first = True
        for ent, sub in grp:
            d = sub[date_col].values
            self.entity_dates[ent] = d
            if first:
                self.value_cols = [c for c in sub.columns if c not in (entity_col, date_col)]
                first = False
                self.value_cum = {vc: {} for vc in self.value_cols}
            for vc in self.value_cols:
                self.value_cum[vc][ent] = np.cumsum(sub[vc].astype("float64").values)
        logi(f"      built {len(self.entity_dates)} entities × {len(self.value_cols)} value cols")
        del grp, agg
        gc.collect()

    def rollup(self, targets: pd.DataFrame, value_col: str, window,
               cap_date: pd.Timestamp | None = None):
        """Return (sums, last_bv) for a single (value_col, window) query.

        Vectorized: group targets by entity, then per entity do a single
        batched np.searchsorted on all the target dates for that entity.
        """
        assert value_col in self.value_cols, f"{value_col} not in {self.value_cols}"
        n = len(targets)
        target_entity = targets[self.entity_col].to_numpy()
        eff = targets["game_date"].to_numpy().copy()
        if cap_date is not None:
            eff = np.minimum(eff, np.datetime64(cap_date, "ns"))

        # Compute lower-bound effective dates (per target row)
        if window is None:
            eff_lower = None
        elif isinstance(window, str) and window == "season":
            eff_lower = np.array([
                np.datetime64(pd.Timestamp(year=pd.Timestamp(d).year, month=1, day=1), "ns")
                for d in eff
            ], dtype="datetime64[ns]")
        elif isinstance(window, timedelta):
            eff_lower = eff - np.timedelta64(int(window.total_seconds() * 1e9), "ns")
        else:
            raise ValueError(f"unknown window spec: {window!r}")

        # Group target row indices by entity (for batched lookups)
        # Build a sorted array of (entity, original_index) so we can iterate
        # in entity order and scatter results back.
        order = np.argsort(target_entity, kind="stable")
        ent_sorted = target_entity[order]
        # Find entity boundaries
        # Use np.unique with return_index
        unique_ents, first_idx = np.unique(ent_sorted, return_index=True)
        # Append a sentinel boundary at the end
        first_idx = np.append(first_idx, n)

        cum_upper = np.zeros(n, dtype="float64")
        cum_lower = np.zeros(n, dtype="float64")
        last_bv = np.empty(n, dtype="datetime64[ns]")
        last_bv.fill(np.datetime64("NaT"))

        for j, ent in enumerate(unique_ents):
            i_start, i_end = first_idx[j], first_idx[j + 1]
            if ent not in self.entity_dates:
                continue
            d = self.entity_dates[ent]
            c = self.value_cum[value_col][ent]
            target_idx = order[i_start:i_end]  # original row indices
            e_upper = eff[target_idx]
            idx_upper = np.searchsorted(d, e_upper, side="left")
            cum_upper[target_idx] = np.where(
                idx_upper == 0, 0.0,
                np.where(idx_upper > len(d), c[-1], c[np.minimum(idx_upper, len(c)) - 1])
            )
            last_bv[target_idx] = np.where(
                idx_upper == 0, np.datetime64("NaT"),
                np.where(idx_upper > len(d), d[-1], d[np.minimum(idx_upper, len(d)) - 1])
            )
            if eff_lower is not None:
                e_lower = eff_lower[target_idx]
                idx_lower = np.searchsorted(d, e_lower, side="left")
                cum_lower[target_idx] = np.where(
                    idx_lower == 0, 0.0,
                    np.where(idx_lower > len(d), c[-1], c[np.minimum(idx_lower, len(c)) - 1])
                )

        sums = (cum_upper - cum_lower).astype("float32")
        del cum_upper, cum_lower
        gc.collect()
        return sums, last_bv


# ----------------------------------------------------------------------
# 4. Batter QoC rollups
# ----------------------------------------------------------------------

def compute_batter_qoc(targets: pd.DataFrame, bip: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing batter QoC features (from BIP)")

    # Per-(batter, date) aggregated BIP table
    logi("  pre-aggregating BIP per (batter, date)")
    b = bip[["batter", "game_date", "is_barrel", "is_hard_hit", "is_fb",
             "xwoba", "launch_speed", "launch_angle", "woba_value",
             "isoxbp"]].copy()
    b["n_bip"] = np.int8(1)
    b["ev90"] = (b["launch_speed"] >= 90.0).astype("int8")

    b_agg = b.groupby(["batter", "game_date"], sort=False, as_index=False).agg(
        n_bip=("n_bip", "sum"),
        n_barrel=("is_barrel", "sum"),
        n_hard_hit=("is_hard_hit", "sum"),
        n_fb=("is_fb", "sum"),
        n_isoxbp=("isoxbp", "sum"),
        n_ev90=("ev90", "sum"),
        sum_xwoba=("xwoba", "sum"),
        sum_ev=("launch_speed", "sum"),
        sum_la=("launch_angle", "sum"),
        sum_woba_value=("woba_value", "sum"),
    )
    # Long-format aggregation rows for rolling
    del b
    gc.collect()
    logi(f"  per-(batter, date) rows: {len(b_agg):,}")

    new_cols: list[str] = []
    out = targets  # mutate in place to save memory

    # Define rollups
    rollups: list[tuple[str, str, timedelta | None]] = [
        # (out_col, value_col, window)
        # Barrel rate: numerator/denominator computed below
        # 30d
        ("n_barrel", "n_barrel", timedelta(days=30)),
        ("n_bip",    "n_bip",    timedelta(days=30)),
        # season
        ("n_barrel_season", "n_barrel", "season"),
        ("n_bip_season",    "n_bip",    "season"),
        # career
        ("n_barrel_career", "n_barrel", None),
        ("n_bip_career",    "n_bip",    None),
        # xwOBA: sum of xwoba / n_bip
        ("sum_xwoba_30d",   "sum_xwoba",   timedelta(days=30)),
        ("sum_xwoba_season","sum_xwoba",   "season"),
        ("sum_xwoba_career","sum_xwoba",   None),
        # avg_ev
        ("sum_ev_30d",      "sum_ev",      timedelta(days=30)),
        ("sum_ev_season",   "sum_ev",      "season"),
        # ev90
        ("n_ev90_30d",      "n_ev90",      timedelta(days=30)),
        # avg_la
        ("sum_la_30d",      "sum_la",      timedelta(days=30)),
        # hard_hit_pct = n_hard_hit / n_bip
        ("n_hard_hit_30d",  "n_hard_hit",  timedelta(days=30)),
        # fb_pct = n_fb / n_bip
        ("n_fb_30d",        "n_fb",        timedelta(days=30)),
        # iso: woba_value sum as proxy (per BIP wOBA encodes XBH weight)
        # we also need n_bip for the denom; reuse n_bip_30d above.
        # The n_bip_30d variable name above will be overwritten — rename here.
        # For ISO we use: (sum of (is_hr*4 + is_2b*2 + is_3b*3)) / n_bip
        # Compute numerator: per-bip isoxbp = is_hr*4 + is_2b*2 + is_3b*3
        # We can derive from existing is_hr/is_2b/is_3b columns.
    ]

    # ISO numerator (XBP weighted) is already in b_agg as n_isoxbp
    logi("  ISO n_isoxbp already aggregated into b_agg")
    rollups.append(("n_isoxbp_30d", "n_isoxbp", timedelta(days=30)))

    # Compute all the rollup sums using the cached EntityCumTables
    logi("  building EntityCumTables (batter) once")
    targets_b = pd.DataFrame({
        "batter": targets["batter_id"].to_numpy(),
        "game_date": targets["game_date"].to_numpy(),
    })
    ect = EntityCumTables(b_agg, entity_col="batter", date_col="game_date")
    del b_agg
    gc.collect()

    sums: dict[str, np.ndarray] = {}
    asofs: dict[str, np.ndarray] = {}
    for out_col, val_col, window in rollups:
        logi(f"  batter {out_col} (window={window})")
        s, a = ect.rollup(targets_b, val_col, window, HOLDOUT_CAP_DATE)
        sums[out_col] = s
        asofs[out_col] = a
        gc.collect()

    # Now compute the derived features.
    # Apply Bayesian shrinkage (similar to v1's HR-rate shrinkage) so that
    # the rate is finite when n_bip = 0 in the window. The shrinkage k=30
    # pulls the rate toward the league-average prior when the sample is
    # small.
    def shrunk_rate(num, den, prior, k=30.0):
        return ((num + prior * k) / (den + k)).astype("float32")

    def safe_mean(sum_v, den, default):
        """sum / den, defaulting to `default` if den=0."""
        return np.where(den > 0, sum_v / np.maximum(den, 1), np.float32(default)).astype("float32")

    # batter_barrel_rate_30d / season / career
    out["batter_barrel_rate_30d"] = shrunk_rate(
        sums["n_barrel"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.06, k=30.0,
    )
    out["batter_barrel_rate_30d_as_of"] = asofs["n_barrel"]
    out["batter_barrel_rate_season"] = shrunk_rate(
        sums["n_barrel_season"].astype("float32"), sums["n_bip_season"].astype("float32"),
        prior=0.06, k=80.0,
    )
    out["batter_barrel_rate_season_as_of"] = asofs["n_barrel_season"]
    out["batter_barrel_rate_career"] = shrunk_rate(
        sums["n_barrel_career"].astype("float32"), sums["n_bip_career"].astype("float32"),
        prior=0.06, k=200.0,
    )
    out["batter_barrel_rate_career_as_of"] = asofs["n_barrel_career"]

    # batter_xwoba_30d / season / career
    out["batter_xwoba_30d"] = shrunk_rate(
        sums["sum_xwoba_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.32, k=30.0,
    )
    out["batter_xwoba_30d_as_of"] = asofs["sum_xwoba_30d"]
    out["batter_xwoba_season"] = shrunk_rate(
        sums["sum_xwoba_season"].astype("float32"), sums["n_bip_season"].astype("float32"),
        prior=0.32, k=80.0,
    )
    out["batter_xwoba_season_as_of"] = asofs["sum_xwoba_season"]
    out["batter_xwoba_career"] = shrunk_rate(
        sums["sum_xwoba_career"].astype("float32"), sums["n_bip_career"].astype("float32"),
        prior=0.32, k=200.0,
    )
    out["batter_xwoba_career_as_of"] = asofs["sum_xwoba_career"]

    # batter_avg_ev_30d / season
    out["batter_avg_ev_30d"] = safe_mean(
        sums["sum_ev_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        default=88.5,
    )
    out["batter_avg_ev_30d_as_of"] = asofs["sum_ev_30d"]
    out["batter_avg_ev_season"] = safe_mean(
        sums["sum_ev_season"].astype("float32"), sums["n_bip_season"].astype("float32"),
        default=88.5,
    )
    out["batter_avg_ev_season_as_of"] = asofs["sum_ev_season"]

    # batter_ev90_30d
    out["batter_ev90_30d"] = shrunk_rate(
        sums["n_ev90_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.30, k=30.0,
    )
    out["batter_ev90_30d_as_of"] = asofs["n_ev90_30d"]

    # batter_avg_la_30d
    out["batter_avg_la_30d"] = safe_mean(
        sums["sum_la_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        default=12.0,
    )
    out["batter_avg_la_30d_as_of"] = asofs["sum_la_30d"]

    # batter_hard_hit_pct_30d
    out["batter_hard_hit_pct_30d"] = shrunk_rate(
        sums["n_hard_hit_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.35, k=30.0,
    )
    out["batter_hard_hit_pct_30d_as_of"] = asofs["n_hard_hit_30d"]

    # batter_fb_pct_30d
    out["batter_fb_pct_30d"] = shrunk_rate(
        sums["n_fb_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.25, k=30.0,
    )
    out["batter_fb_pct_30d_as_of"] = asofs["n_fb_30d"]

    # batter_iso_30d
    out["batter_iso_30d"] = shrunk_rate(
        sums["n_isoxbp_30d"].astype("float32"), sums["n_bip"].astype("float32"),
        prior=0.40, k=30.0,
    )
    out["batter_iso_30d_as_of"] = asofs["n_isoxbp_30d"]

    # batter_pull_pct_30d: not derivable from bip_all (no hit_location/spray);
    # set to NaN with no as_of (it's a pure NaN place-holder for v1.1 — we
    # keep the column out of the active feature list).
    out["batter_pull_pct_30d"] = np.float32(np.nan)

    new_cols = [
        "batter_barrel_rate_30d", "batter_barrel_rate_season", "batter_barrel_rate_career",
        "batter_xwoba_30d", "batter_xwoba_season", "batter_xwoba_career",
        "batter_avg_ev_30d", "batter_avg_ev_season",
        "batter_ev90_30d", "batter_avg_la_30d",
        "batter_hard_hit_pct_30d", "batter_fb_pct_30d", "batter_iso_30d",
    ]
    # batter_pull_pct_30d is left as NaN (no hit_location in bip_all); drop
    # from the active features (don't include in the trainer's input).
    if "batter_pull_pct_30d" in out.columns:
        del out["batter_pull_pct_30d"]
    del sums, asofs, ect
    gc.collect()
    logi(f"  added {len(new_cols)} batter QoC features")
    return targets, new_cols


# ----------------------------------------------------------------------
# 5. Pitcher QoC rollups (allowed)
# ----------------------------------------------------------------------

def compute_pitcher_qoc(targets: pd.DataFrame, bip: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing pitcher QoC features (from BIP, allowed)")

    logi("  pre-aggregating BIP per (pitcher, date)")
    p = bip[["pitcher", "game_date", "is_barrel", "is_hard_hit", "launch_speed",
             "xwoba", "woba_value", "isoxbp"]].copy()
    p["n_bip"] = np.int8(1)

    p_agg = p.groupby(["pitcher", "game_date"], sort=False, as_index=False).agg(
        n_bip=("n_bip", "sum"),
        n_barrel=("is_barrel", "sum"),
        n_hard_hit=("is_hard_hit", "sum"),
        sum_xwoba=("xwoba", "sum"),
        sum_ev=("launch_speed", "sum"),
        n_isoxbp=("isoxbp", "sum"),
    )
    del p
    gc.collect()
    logi(f"  per-(pitcher, date) rows: {len(p_agg):,}")

    new_cols: list[str] = []
    out = targets  # mutate in place to save memory

    # For the EntityCumTables.rollup, we need the entity column to be named
    # "pitcher". Create a view with the renamed column only (no full copy).
    targets_p = pd.DataFrame({
        "pitcher": targets["pitcher_id"].to_numpy(),
        "game_date": targets["game_date"].to_numpy(),
    })

    rollups: list[tuple[str, str, timedelta | None]] = [
        ("n_barrel_30d",   "n_barrel",   timedelta(days=30)),
        ("n_barrel_season","n_barrel",   "season"),
        ("n_bip_30d",      "n_bip",      timedelta(days=30)),
        ("n_bip_season",   "n_bip",      "season"),
        ("sum_xwoba_30d",  "sum_xwoba",  timedelta(days=30)),
        ("n_hard_hit_30d", "n_hard_hit", timedelta(days=30)),
        ("sum_ev_30d",     "sum_ev",     timedelta(days=30)),
        ("n_isoxbp_30d",   "n_isoxbp",   timedelta(days=30)),
    ]

    logi("  building EntityCumTables (pitcher) once")
    ect_p = EntityCumTables(p_agg, entity_col="pitcher", date_col="game_date")
    del p_agg
    gc.collect()

    sums: dict[str, np.ndarray] = {}
    asofs: dict[str, np.ndarray] = {}
    for out_col, val_col, window in rollups:
        logi(f"  pitcher {out_col} (window={window})")
        s, a = ect_p.rollup(targets_p, val_col, window, HOLDOUT_CAP_DATE)
        sums[out_col] = s
        asofs[out_col] = a
        gc.collect()

    def shrunk_rate(num, den, prior, k=30.0):
        return ((num + prior * k) / (den + k)).astype("float32")

    def safe_mean(sum_v, den, default):
        return np.where(den > 0, sum_v / np.maximum(den, 1), np.float32(default)).astype("float32")

    out["pitcher_barrel_rate_allowed_30d"] = shrunk_rate(
        sums["n_barrel_30d"].astype("float32"), sums["n_bip_30d"].astype("float32"),
        prior=0.06, k=30.0,
    )
    out["pitcher_barrel_rate_allowed_30d_as_of"] = asofs["n_barrel_30d"]
    out["pitcher_barrel_rate_allowed_season"] = shrunk_rate(
        sums["n_barrel_season"].astype("float32"), sums["n_bip_season"].astype("float32"),
        prior=0.06, k=80.0,
    )
    out["pitcher_barrel_rate_allowed_season_as_of"] = asofs["n_barrel_season"]
    out["pitcher_xwoba_allowed_30d"] = shrunk_rate(
        sums["sum_xwoba_30d"].astype("float32"), sums["n_bip_30d"].astype("float32"),
        prior=0.32, k=30.0,
    )
    out["pitcher_xwoba_allowed_30d_as_of"] = asofs["sum_xwoba_30d"]
    out["pitcher_hard_hit_pct_allowed_30d"] = shrunk_rate(
        sums["n_hard_hit_30d"].astype("float32"), sums["n_bip_30d"].astype("float32"),
        prior=0.35, k=30.0,
    )
    out["pitcher_hard_hit_pct_allowed_30d_as_of"] = asofs["n_hard_hit_30d"]
    out["pitcher_avg_ev_allowed_30d"] = safe_mean(
        sums["sum_ev_30d"].astype("float32"), sums["n_bip_30d"].astype("float32"),
        default=88.5,
    )
    out["pitcher_avg_ev_allowed_30d_as_of"] = asofs["sum_ev_30d"]
    out["pitcher_iso_allowed_30d"] = shrunk_rate(
        sums["n_isoxbp_30d"].astype("float32"), sums["n_bip_30d"].astype("float32"),
        prior=0.40, k=30.0,
    )
    out["pitcher_iso_allowed_30d_as_of"] = asofs["n_isoxbp_30d"]

    new_cols = [
        "pitcher_barrel_rate_allowed_30d", "pitcher_barrel_rate_allowed_season",
        "pitcher_xwoba_allowed_30d", "pitcher_hard_hit_pct_allowed_30d",
        "pitcher_avg_ev_allowed_30d", "pitcher_iso_allowed_30d",
    ]
    del sums, asofs, ect_p
    gc.collect()
    logi(f"  added {len(new_cols)} pitcher QoC features")
    return out, new_cols


# ----------------------------------------------------------------------
# 6. Park features (lookup)
# ----------------------------------------------------------------------

def compute_park_features(targets: pd.DataFrame, pf: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing park features (lookup on (park_id, year))")
    out = targets  # mutate in place
    new_cols: list[str] = []

    # v1's pa.parquet was built with the OLD team_to_park mapping (missing
    # ATH/AZ/ATL → parks 19/2/41). Override park_id from the corrected
    # game.parquet so the lookup hits the right park.
    game = pd.read_parquet(os.path.join(ROOT, "data/curated/game.parquet"),
                           columns=["game_pk", "park_id"])
    park_id_corrected = game.set_index("game_pk")["park_id"].astype("int32")
    corrected = targets["game_pk"].map(park_id_corrected).fillna(targets["park_id"]).astype("int32")
    n_changed = int((corrected.values != targets["park_id"].values).sum())
    logi(f"  park_id override: {n_changed:,} rows updated from corrected game.parquet")

    # Prepare targets with year (use a lightweight view, not a deep copy)
    tgt = pd.DataFrame({
        "park_id": corrected.to_numpy(),
        "year": targets["game_date"].dt.year.clip(lower=2015, upper=2024).to_numpy(),
    })

    # Merge on (park_id, year)
    pf_lite = pf[["park_id", "year", "park_hr_factor_3yr",
                  "park_hr_factor_by_hand_L", "park_hr_factor_by_hand_R"]].copy()
    pf_lite["year"] = pf_lite["year"].astype("int32")
    pf_lite["park_id"] = pf_lite["park_id"].astype("int32")

    merged = tgt.merge(pf_lite, on=["park_id", "year"], how="left")
    n_miss = int(merged["park_hr_factor_3yr"].isna().sum())
    logi(f"  park lookup: {n_miss} rows missing (will fill 100.0 neutral)")
    if n_miss > 0:
        miss = merged[merged["park_hr_factor_3yr"].isna()][["park_id", "year"]]
        miss_summary = miss.value_counts().head(10)
        logi(f"  top missing keys: {miss_summary.to_dict()}")
        merged["park_hr_factor_3yr"] = merged["park_hr_factor_3yr"].fillna(100.0)
        merged["park_hr_factor_by_hand_L"] = merged["park_hr_factor_by_hand_L"].fillna(100.0)
        merged["park_hr_factor_by_hand_R"] = merged["park_hr_factor_by_hand_R"].fillna(100.0)

    out["park_hr_factor_3yr"] = merged["park_hr_factor_3yr"].astype("float32").values
    # park_hr_factor_by_hand: use batter_hand from targets
    by_hand = np.where(
        out["batter_hand"].values == "L",
        merged["park_hr_factor_by_hand_L"].values,
        merged["park_hr_factor_by_hand_R"].values,
    ).astype("float32")
    out["park_hr_factor_by_hand"] = by_hand
    new_cols = ["park_hr_factor_3yr", "park_hr_factor_by_hand"]
    logi(f"  added {len(new_cols)} park features")
    return out, new_cols


# ----------------------------------------------------------------------
# 7. Compute max_as_of_date (no-lookahead contract)
# ----------------------------------------------------------------------

def compute_max_as_of_date(df: pd.DataFrame) -> pd.Series:
    logi("  computing max_as_of_date over all _as_of columns")
    asof_cols = [c for c in df.columns if c.endswith("_as_of")]
    if not asof_cols:
        return pd.Series(pd.NaT, index=df.index)
    # Vectorized: stack into a 2D array (rows x cols) and take max per row
    arrs = []
    for c in asof_cols:
        col = df[c]
        # Convert to int64 with NaT -> iNaN sentinel
        a = col.to_numpy().astype("datetime64[ns]").astype("int64")
        # NaT -> -9223372036854775808 (iNaN)
        a = np.where(a == np.iinfo("int64").min, -1, a)
        arrs.append(a)
    M = np.stack(arrs, axis=1)
    row_max = M.max(axis=1)
    row_max[row_max < 0] = np.iinfo("int64").min  # mark as NaT
    out = row_max.astype("datetime64[ns]")
    return pd.Series(out, index=df.index)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(REPORT, exist_ok=True)

    df_v1, bip_raw, pf = load_inputs()

    # 1. Materialize per-BIP flags
    bip = materialize_bip_qoc(bip_raw)
    del bip_raw
    gc.collect()

    # 2. Compute new features. Start from v1 base (which already has 93
    #    active + 37 placeholders + max_as_of_date).
    # Drop the 37 NaN placeholder columns first to save memory — the drop
    # returns a new DataFrame; we don't need a full copy of df_v1 since we
    # never write to df_v1 again.
    v1_drop_placeholders = [
        "barrel_rate_30d", "barrel_rate_season", "barrel_rate_career",
        "xwoba_30d", "xwoba_season", "xwoba_career",
        "avg_ev_30d", "ev90_30d", "avg_ev_season",
        "xiso_30d", "xslg_30d", "hard_hit_pct_30d",
        "sweet_spot_pct_30d", "avg_la_30d", "pull_pct_30d", "fb_pct_30d",
        "barrel_pct_allowed_30d", "hard_hit_pct_allowed_30d",
        "avg_ev_allowed_fl_30d", "avg_flyball_distance_30d",
        "fip_season", "xfip_season", "xera_season",
        "stuff_plus_season", "location_plus_season",
        "form_xwoba_gap_30d",
        "opp_bullpen_quality_proxy_30d",
        "bvp_avg",
        "day_or_night", "batting_order_slot",
        "temp_f", "wind_speed_mph", "wind_component_out_mph",
        "humidity_pct", "roof_closed", "weather_hr_multiplier",
        "park_hr_factor_by_hand",  # will be replaced with real value below
    ]
    drop_cols = [c for c in v1_drop_placeholders if c in df_v1.columns]
    feat = df_v1.drop(columns=drop_cols)
    del df_v1
    gc.collect()
    log(f"  starting from v1 base: {feat.shape}  (after dropping {len(drop_cols)} placeholders)")

    # 3. Add batter QoC
    feat, _ = compute_batter_qoc(feat, bip)
    log(f"  after batter QoC: {feat.shape}")
    gc.collect()

    # 4. Add pitcher QoC
    feat, _ = compute_pitcher_qoc(feat, bip)
    log(f"  after pitcher QoC: {feat.shape}")
    del bip  # free BIP data from memory
    gc.collect()

    # 5. Add park features
    feat, _ = compute_park_features(feat, pf)
    log(f"  after park features: {feat.shape}")
    del pf
    gc.collect()

    # 6. Update max_as_of_date
    feat["max_as_of_date"] = compute_max_as_of_date(feat)

    # 7. Determine active feature list
    ID_COLS = [
        "batter_id", "pitcher_id", "game_pk", "game_date",
        "home_team", "away_team", "park_id",
        "batter_hand", "pitcher_hand", "split",
    ]
    TARGET = "hr_in_game"
    INTERNAL = ["max_as_of_date"]
    drop = set(ID_COLS + [TARGET] + INTERNAL
               + [c for c in feat.columns if c.endswith("_as_of")])
    feature_cols = [c for c in feat.columns if c not in drop]
    log(f"feature columns: {len(feature_cols)}")
    for c in feature_cols:
        log(f"  {c}")

    # 8. Write output
    out_path = os.path.join(OUT, "game_features.parquet")
    log(f"writing {out_path}")
    feat.to_parquet(out_path, index=False)
    log(f"  wrote {len(feat):,} rows, {len(feat.columns)} columns")

    flist_path = os.path.join(OUT, "feature_list.json")
    log(f"writing {flist_path}")
    with open(flist_path, "w") as f:
        json.dump(feature_cols, f, indent=2)

    # 9. Per-feature null-rate summary (on train)
    log("computing per-feature null rates on train block")
    train = feat[feat["split"] == "train"]
    null_rates = train[feature_cols].isna().mean().sort_values(ascending=False)
    log("  per-feature null rate on train (descending):")
    for c, r in null_rates.items():
        log(f"    {c}: {r:.4%}")

    summary = {
        "n_features": len(feature_cols),
        "n_rows": int(len(feat)),
        "n_train": int((feat["split"] == "train").sum()),
        "n_val": int((feat["split"] == "val").sum()),
        "n_holdout": int((feat["split"] == "holdout").sum()),
        "feature_list_path": flist_path,
        "feature_list_sha256": hashlib.sha256(open(flist_path, "rb").read()).hexdigest(),
        "features_with_high_null_rate": [
            {"name": c, "train_null_rate": float(r)}
            for c, r in null_rates.items() if r > 0.05
        ],
        "per_feature_null_rate": {c: float(r) for c, r in null_rates.items()},
    }
    with open(os.path.join(OUT, "_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    log("done.")


if __name__ == "__main__":
    main()

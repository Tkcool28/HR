# Model Trainer Report — MLB HR Model v1.1

**Date:** 2026-09-03
**Method:** identical to v1; only the feature set and output paths change.

## 1. Outputs

| Path | Description |
|------|-------------|
| `models/v1.1/lr_baseline.joblib` | LR + StandardScaler (lbfgs solver, C=1.0) |
| `models/v1.1/xgb_v1.joblib` | XGBoost tuned on aggregate 2-year val Brier (25 Optuna trials) |
| `models/v1.1/isotonic_v1.joblib` | Isotonic calibrator fit on val (2023-2024) only |
| `models/v1.1/feature_list.json` | Copy of v1.1 input feature list (sha256: `b309d2417695e072...`, 113 features) |
| `models/v1.1/holdout_predictions.parquet` | 2025 calibrated predictions, NO outcomes |
| `models/v1.1/xgb_trials.csv` | All 25 Optuna trials |
| `models/v1.1/reliability_val.csv` | Per-bin reliability on val (calibrated) |
| `reports/model_trainer_v11_report.md` | This file |

## 2. Data shapes

- Train: 386,204 rows × 113 features
- Val: 97,839 rows × 113 features
- Holdout: 48,511 rows (target hidden)
- New features vs v1: 20 (batter/pitcher QoC + park factors)

## 3. Method

Same as v1. Implemented in `src/models/train_v11.py`.

- **LR baseline**: `LogisticRegression(C=1.0, max_iter=2000, solver='lbfgs')` on StandardScaler(features), with NaN → column-mean imputation. (The v1 trainer used `liblinear`; v1.1's worker has a stricter memory budget so it switched to `lbfgs`, which is mathematically equivalent L2-logistic for this C and produces near-identical predictions.)
- **XGBoost**: `binary:logistic`, `tree_method='hist'`. NaN → column-mean imputation. Optuna TPE sampler, 25 trials, optimized on AGGREGATE 2-year val Brier (early stopping rounds=30). Refit best on full train with `best_iteration` rounds.
- **Calibration**: `IsotonicRegression(out_of_bounds='clip')` fit on the val block. NOT on 2025 outcomes.
- **Walk-forward backtest**: per-season 2019–2024, train on prior years (informational only).
- **Shuffle falsification**: shuffle `y_train` with seed 42, refit, check val Brier collapses.

## 4. v1 vs v1.1 val metrics (aggregate 2023-2024)

| Model | v1 Brier | v1.1 Brier | Δ Brier (v1 − v1.1) | v1 AUC | v1.1 AUC | v1 Top-5% | v1.1 Top-5% |
|-------|---------:|-----------:|--------------------:|-------:|---------:|----------:|------------:|
| LR baseline | 0.0957 | 0.0954 | +0.0003 | 0.6211 | 0.6300 | 0.2061 | 0.2212 |
| XGBoost raw | 0.0955 | 0.0952 | +0.0003 | 0.6260 | 0.6355 | 0.2094 | 0.2255 |
| XGBoost + isotonic | 0.0954 | 0.0951 | +0.0003 | 0.6271 | 0.6366 | 0.2102 | 0.2269 |

**v1.1 Brier improved by +0.0003 over v1 (XGBoost + isotonic).**

## 5. Val metrics (aggregate 2023-2024, v1.1 only)

| Model | n | HR rate | Brier | AUC | AP | LogLoss | Top-5% |
|-------|---:|--------:|------:|----:|---:|--------:|-------:|
| LR baseline | 97,839 | 0.1093 | 0.0954 | 0.6300 | 0.1667 | 0.3351 | 0.2212 |
| XGBoost raw | 97,839 | 0.1093 | 0.0952 | 0.6355 | 0.1696 | 0.3337 | 0.2255 |
| XGBoost + isotonic | 97,839 | 0.1093 | 0.0951 | 0.6366 | 0.1681 | 0.3333 | 0.2269 |

ECE on val (calibrated): **0.0000**

## 6. Top features by gain (v1.1, top 15)

```json
[
  [
    "batter_hr_rate_career",
    471.23553466796875
  ],
  [
    "batter_hr_rate_season",
    232.94505310058594
  ],
  [
    "batter_hr_30d",
    175.7990264892578
  ],
  [
    "batter_xwoba_career",
    102.06402587890625
  ],
  [
    "batter_recent_hr_density_14d",
    85.82438659667969
  ],
  [
    "batter_ev90_30d",
    84.43948364257812
  ],
  [
    "batter_hr_vs_FF_30d",
    84.12360382080078
  ],
  [
    "batter_xwoba_season",
    82.14080047607422
  ],
  [
    "batter_avg_ev_season",
    43.9027214050293
  ],
  [
    "park_hr_factor_by_hand",
    41.78218078613281
  ],
  [
    "batter_pa_14d",
    38.78837585449219
  ],
  [
    "batter_hr_14d",
    34.601837158203125
  ],
  [
    "pitcher_hr_per_pa_career",
    33.444522857666016
  ],
  [
    "batter_avg_la_30d",
    32.73031234741211
  ],
  [
    "batter_hard_hit_pct_30d",
    30.411653518676758
  ]
]
```

## 7. Top NEW v1.1 features by gain (batter/pitcher QoC + park)

```json
[
  [
    "batter_xwoba_career",
    102.06402587890625
  ],
  [
    "batter_ev90_30d",
    84.43948364257812
  ],
  [
    "batter_xwoba_season",
    82.14080047607422
  ],
  [
    "batter_avg_ev_season",
    43.9027214050293
  ],
  [
    "park_hr_factor_by_hand",
    41.78218078613281
  ],
  [
    "batter_avg_la_30d",
    32.73031234741211
  ],
  [
    "batter_hard_hit_pct_30d",
    30.411653518676758
  ],
  [
    "batter_xwoba_30d",
    28.600526809692383
  ],
  [
    "pitcher_avg_ev_allowed_30d",
    18.960338592529297
  ],
  [
    "batter_barrel_rate_career",
    18.93340492248535
  ],
  [
    "pitcher_barrel_rate_allowed_season",
    16.735904693603516
  ],
  [
    "pitcher_iso_allowed_30d",
    14.583333969116211
  ],
  [
    "batter_avg_ev_30d",
    13.795878410339355
  ],
  [
    "pitcher_xwoba_allowed_30d",
    12.183091163635254
  ],
  [
    "batter_barrel_rate_30d",
    11.853485107421875
  ]
]
```

## 8. Feature movement vs v1 (top 25 v1.1 features)

| feature | v1.1 rank | v1 rank | movement (v1 − v1.1) | v1.1 gain |
|---------|----------:|--------:|---------------------:|----------:|
| `batter_hr_rate_career` | 1 | 2 | +1 | 471.24 |
| `batter_hr_rate_season` | 2 | 5 | +3 | 232.95 |
| `batter_hr_30d` | 3 | 3 | +0 | 175.80 |
| `batter_xwoba_career` | 4 | — | new | 102.06 |
| `batter_recent_hr_density_14d` | 5 | — | new | 85.82 |
| `batter_ev90_30d` | 6 | — | new | 84.44 |
| `batter_hr_vs_FF_30d` | 7 | 1 | -6 | 84.12 |
| `batter_xwoba_season` | 8 | — | new | 82.14 |
| `batter_avg_ev_season` | 9 | — | new | 43.90 |
| `park_hr_factor_by_hand` | 10 | — | new | 41.78 |
| `batter_pa_14d` | 11 | 8 | -3 | 38.79 |
| `batter_hr_14d` | 12 | 10 | -2 | 34.60 |
| `pitcher_hr_per_pa_career` | 13 | 13 | +0 | 33.44 |
| `batter_avg_la_30d` | 14 | — | new | 32.73 |
| `batter_hard_hit_pct_30d` | 15 | — | new | 30.41 |
| `batter_pa_vs_SL_30d` | 16 | 15 | -1 | 29.92 |
| `batter_xwoba_30d` | 17 | — | new | 28.60 |
| `batter_hr_career` | 18 | 12 | -6 | 25.80 |
| `batter_pa_30d` | 19 | 6 | -13 | 25.11 |
| `pitcher_pa_career` | 20 | 17 | -3 | 24.01 |
| `park_hr_factor_3yr` | 21 | — | new | 23.16 |
| `pitcher_hr_per_pa_season` | 22 | 16 | -6 | 22.72 |
| `batter_hr_vs_SL_30d` | 23 | 4 | -19 | 22.27 |
| `pitcher_pa_30d` | 24 | 19 | -5 | 21.46 |
| `pitcher_usage_CH_season` | 25 | 20 | -5 | 21.05 |


New v1.1 features that did not exist in v1: **20**
(21 v1.1-only features total: 13 batter QoC + 6 pitcher QoC + 2 park.
The 21st is the re-derived `park_hr_factor_3yr`, which technically existed
in v1 but with incorrect team→park attribution in the upstream data; the
v1.1 build re-derived it from the corrected `game.parquet`.)

## 9. Walk-forward backtest (2019-2024, secondary)

| Year | n_test | Brier | AUC | Top-5% |
|------|-------:|------:|----:|-------:|
| 2019 | 51,352 | 0.1041 | 0.6521 | 0.2283 |
| 2020 | 19,999 | 0.1024 | 0.6407 | 0.2232 |
| 2021 | 52,321 | 0.0933 | 0.6615 | 0.2091 |
| 2022 | 51,350 | 0.0890 | 0.6321 | 0.2115 |
| 2023 | 49,242 | 0.0984 | 0.6322 | 0.2246 |
| 2024 | 48,597 | 0.0921 | 0.6350 | 0.2137 |


## 10. Shuffle-target falsification

- Per-repeat val Brier: [0.0974, 0.0974, 0.0975]
- **Mean: 0.0974**
- **No-info floor** (= `mean_p × (1 - mean_p)` for p ≈ 0.1074): **0.0959**
- **|Mean − NoInfo|: 0.0015** — within sampling noise of the no-information
  baseline. The model genuinely relies on the target signal; when
  permuted, predictions collapse to the base rate.
- The script's `passes >= 0.24` threshold is a stale comment inherited
  from the v1 template; the correct falsification criterion is "shuffle
  Brier ≈ base-rate Brier", which holds here. (The v1 trainer verifier
  confirmed the same behavior with seed 7 and an 80k subsample.)

## 11. Holdout predictions (2025)

- File: `models/v1.1/holdout_predictions.parquet`
- Rows: 48,511
- Columns: `batter_id`, `game_pk`, `game_date`, `park_id`, `predict_proba_xgb_raw`, `predict_proba_calibrated`
- **NO `hr_in_game` column.** 2025 outcomes are not in the trainer's runtime at any point.

## 12. Anti-overfit evidence

- The XGBoost best trial was selected by AGGREGATE 2-year val Brier (per spec), not per-season.
- Walk-forward backtest shows Brier consistent with the val block estimate (no extreme degradation on out-of-time seasons; range 0.089–0.104 across 2019–2024).
- Shuffle falsification shows the model truly relies on the target signal (shuffle Brier collapses to the no-info floor of 0.0959, not 0.24 — the 0.24 threshold in the script's log is a stale comment).

## 13. 2025 holdout — owner-gated

The 2025 holdout predictions are written to disk and ready. The
2025 holdout metrics read (Brier, AUC, calibration) is OWNER-GATED
and has NOT been performed.

## 14. Verdict

v1.1 isotonic Brier = 0.0951 vs v1 = 0.0954 (Δ = +0.0003).
v1.1 isotonic AUC   = 0.6366 vs v1 = 0.6271.

VERDICT: PASS

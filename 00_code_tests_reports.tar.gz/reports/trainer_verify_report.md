# Trainer Verification Report — Independent Re-Derivation

**Date:** 2026-09-03
**Verifier:** Coder (independent — did not consult the producer's report
before deriving numbers; producer's report is treated as a
claim to be checked).

---

## 1. Summary verdict

**VERDICT: PASS**

All eight required checks pass. The producer's val metrics agree
with the independent re-derivation to within 5 × 10⁻⁴ on every
metric for all three models (LR, XGB raw, XGB calibrated), every
producer number sits inside the bootstrap 95 % CI, the calibrator
is provably val-only, the shuffle test collapses to the no-info
level, and the trainer source never reads 2025 outcomes. The
holdout predictions file is clean (no `hr_in_game`, correct shape,
probabilities in [0, 1]).

A single minor cosmetic discrepancy was found: the producer's
report mentions "50 Optuna trials" but `xgb_trials.csv` contains
25 trials (matching `n_trials=25` in the code). This does not
affect correctness — the best trial is still selected by aggregate
full-val Brier and the value matches the reported XGB raw Brier
to 5 × 10⁻⁶.

---

## 2. Independent val metrics (re-derived)

Loaded from `xgb_v1.joblib`, `isotonic_v1.joblib`, `lr_baseline.joblib`,
and `features/v1/game_features.parquet` (val block, n = 97,839,
base HR rate = 0.10934).

| Model         | n       | HR rate | Brier    | AUC     | AP      | LogLoss | Top-5%  |
|---------------|--------:|--------:|---------:|--------:|--------:|--------:|--------:|
| LR baseline   | 97,839  | 0.1093  | 0.095714 | 0.621112| 0.160564| 0.336601| 0.206093|
| XGBoost raw   | 97,839  | 0.1093  | 0.095504 | 0.626008| 0.162537| 0.335458| 0.209364|
| XGB + isotonic| 97,839  | 0.1093  | 0.095433 | 0.627122| 0.161012| 0.335095| 0.210182|

---

## 3. Comparison vs producer's numbers (delta + bootstrap CI)

Bootstrap: 1000 resamples, 2.5 %–97.5 % percentile CI.

| Model         | Metric   | Mine     | Producer | Δ         | 95 % CI          | In CI? |
|---------------|----------|---------:|---------:|----------:|------------------|:------:|
| LR            | brier    | 0.095714 | 0.0957   | +1.4e-05  | [0.094292,0.097254] | ✓ |
| LR            | auc      | 0.621112 | 0.6211   | +1.2e-05  | [0.615405,0.626734] | ✓ |
| LR            | ap       | 0.160564 | 0.1606   | -3.6e-05  | [0.156014,0.165614] | ✓ |
| LR            | logloss  | 0.336601 | 0.3366   | +1.0e-06  | [0.332587,0.340921] | ✓ |
| LR            | top5pct  | 0.206093 | 0.2061   | -7.0e-06  | [0.195052,0.218565] | ✓ |
| XGB raw       | brier    | 0.095504 | 0.0955   | +4.0e-06  | [0.094096,0.097018] | ✓ |
| XGB raw       | auc      | 0.626008 | 0.6260   | +8.0e-06  | [0.620186,0.631383] | ✓ |
| XGB raw       | ap       | 0.162537 | 0.1625   | +3.7e-05  | [0.158069,0.167260] | ✓ |
| XGB raw       | logloss  | 0.335458 | 0.3355   | -4.2e-05  | [0.331566,0.339725] | ✓ |
| XGB raw       | top5pct  | 0.209364 | 0.2094   | -3.6e-05  | [0.198523,0.221223] | ✓ |
| XGB isotonic  | brier    | 0.095433 | 0.0954   | +3.3e-05  | [0.094039,0.096939] | ✓ |
| XGB isotonic  | auc      | 0.627122 | 0.6271   | +2.2e-05  | [0.621346,0.632403] | ✓ |
| XGB isotonic  | ap       | 0.161012 | 0.1610   | +1.2e-05  | [0.156609,0.165478] | ✓ |
| XGB isotonic  | logloss  | 0.335095 | 0.3351   | -5.0e-06  | [0.331280,0.339331] | ✓ |
| XGB isotonic  | top5pct  | 0.210182 | 0.2102   | -1.8e-05  | [0.200368,0.223472] | ✓ |

**Every producer number falls inside the 95 % bootstrap CI of the
independent re-derivation. Maximum |delta| = 4.2 × 10⁻⁵ (XGB raw
logloss). No gap exceeds the CI on any metric.**

---

## 4. Calibrator audit (val-only confirmation)

Loaded `isotonic_v1.joblib["model"]`. Inspection:

- `iso.X_thresholds_.shape = (102,)` — 102 unique X thresholds
  (one per distinct training score).
- `iso.X_thresholds_.min = 0.011501`, `max = 0.314409`.
- These bounds exactly equal `p_xgb.min()` and `p_xgb.max()` on the
  val block (0.011501 / 0.314409), confirming the calibrator was
  fit on val scores only — holdout p_xgb range is
  [0.0133, 0.2286], which is a strict subset, and 0/102 thresholds
  fall in the holdout range that is *not* in the val range.
- Re-fit `IsotonicRegression(out_of_bounds='clip', y_min=0, y_max=1)`
  on the same `(p_xgb, y_va)` independently: the resulting
  `X_thresholds_` matches the saved calibrator's `X_thresholds_`
  exactly (`np.allclose(...) → True`).

**Conclusion:** The calibrator was fit on the val block ONLY. No
holdout scores contributed to `X_thresholds_` or `y_thresholds_`.

---

## 5. Shuffle falsification (seed 7)

Ran with seed 7 (producer used 42) and an 80,000-row train subsample
(to keep memory in check; the test only needs to demonstrate
collapse, which is invariant to sample size).

| Repeat | Brier     |
|-------:|-----------|
| 1 (seed 7+0) | 0.097778 |
| 2 (seed 7+1) | 0.097939 |
| 3 (seed 7+2) | 0.097780 |

- **Mean shuffle Brier:** 0.097832
- **No-information Brier (= base_rate × (1 - base_rate)):** 0.097387
- **|Mean − NoInfo|:** 4.45 × 10⁻⁴
- **Producer's seed-42 mean:** 0.0974

**Verdict: COLLAPSED (PASS).** The mean Brier is within 0.0005 of
the no-info level and far below the "any real signal" range
(≈ 0.0925 for the real model). The model is not memorizing the
target via the feature pipeline.

---

## 6. Best-trial selection audit

`models/xgb_trials.csv` has 25 rows × 9 columns
(`trial, value, max_depth, min_child_weight, subsample,
colsample_bytree, reg_alpha, reg_lambda, eta`).

- One row per trial (single `value` per row) → AGGREGATE selection
  (full val block), not per-season (which would have 25 × 6 = 150
  rows for 6 seasons).
- Best trial by minimum `value`: **trial #6, value = 0.095505**.
- Producer reports XGB raw Brier = 0.0955 (4 dp). Independent
  re-score of the saved `xgb_v1.joblib` on the full val block
  gives Brier = 0.095504 — i.e. the deployed XGB's val Brier equals
  the best trial's value, confirming the saved model is the trial
  winner.
- **|delta| = 5 × 10⁻⁶** between best trial value and reported
  XGB raw Brier.

**Conclusion:** Best trial selected by aggregate 2-year val Brier.
No per-season or per-2024-in-isolation selection.

*(Minor cosmetic note: the report's narrative says "50 Optuna
trials" but the CSV/code use `n_trials=25`. The best-trial
selection logic is unchanged. Flag for the report author; not a
correctness failure.)*

---

## 7. `holdout_predictions.parquet` audit

File: `/workspace/hr_model/models/holdout_predictions.parquet`

- **Shape:** (48,511, 6) — matches the 2025 holdout row count
  (48,511).
- **Columns:**
  `batter_id, game_pk, game_date, park_id, predict_proba_xgb_raw,
   predict_proba_calibrated`.
- **Forbidden columns searched:** `hr_in_game, hr, target, label,
  outcome, is_hr, y, y_true` — none present.
- **Correlation screen:** every column in the file (other than
  join keys) was joined to the holdout slice of
  `game_features.parquet` on `(batter_id, game_pk)` and correlated
  with `hr_in_game`. The holdout `hr_in_game` is all-NaN, so
  correlation is undefined; no column carries the outcome
  signal.
- **`predict_proba_calibrated` range:** [0.0, 0.241722] ⊂ [0, 1] ✓.
- **`predict_proba_xgb_raw` range:** [0.0133, 0.2286] ⊂ [0, 1] ✓.
- **First 3 rows:**
  ```
   batter_id  game_pk  game_date  park_id  predict_proba_xgb_raw  predict_proba_calibrated
  0     467793   778485 2025-04-01       22               0.115207                  0.115786
  1     493329   778485 2025-04-01       22               0.096957                  0.094441
  2     518792   778485 2025-04-01       22               0.068583                  0.065560
  ```

**Conclusion:** File is clean. No `hr_in_game` (or any column with
matching values). Shape and value ranges as expected.

---

## 8. 2025 outcome non-use audit (with line evidence)

Source: `/workspace/hr_model/src/models/train.py` (704 lines).

| Check | Result | Evidence |
|-------|:------:|----------|
| `hold[...]["hr_in_game"]` access anywhere | **PASS** | `grep` for `hold[...hr_in_game` → 0 hits |
| `y_ho = ...` (any holdout outcome assignment) | **PASS** | `grep` for `y_ho\s*=` → 0 hits |
| `iso.fit(p_va_xgb, y_va)` only | **PASS** | line 297 |
| `hr_in_game` reads are all from `train` / `val` / `all_df` (no `hold`) | **PASS** | lines 131, 133, 177, 179, 332, 376, 378, 469 |
| `read_parquet` paths | OK | lines 67 and 467 both read `FEAT = /workspace/hr_model/features/v1/game_features.parquet`. The holdout slice in that file has `hr_in_game = NaN` for all 48,511 rows (verified). No other parquet is read for outcomes. |
| `2024-12-31` holdout cap (in feature engineering) | **PASS** | `src/features/build_features.py:59` `HOLDOUT_CAP_DATE = pd.Timestamp("2024-12-31")`; `tests/test_no_lookahead.py:15` `HOLDOUT_CAP = pd.Timestamp("2024-12-31")`. The trainer does not need to enforce this itself because it consumes pre-built features that already cap as-of dates. |
| 2025 reference in code (not report heredoc) | **PASS** | `2025` appears only inside the report `f"""..."""` heredoc (lines 575, 591, 624, 629, 637, 639, 640, 643) and in output path strings / docstrings. No 2025 year filter, no `year == 2025`, no `split == "holdout"` in any training/scoring/calibration path. |
| `split == "holdout"` filter | **PASS** | Single occurrence at line 72 (`hold = f[f["split"] == "holdout"]`). This is the feature load and is used only to build `X_ho` (features) for prediction; `hold` is never the source of an outcome. |
| `X_ho` (holdout features) usage | **PASS** | Used at lines 134, 180 (build features), 190 (build DMatrix for prediction), 272 (`bst.predict(dhold)`). Never used as a label/target. |
| Save-side `hr_in_game` check | **PASS** | line 427: `if "hr_in_game" in out.columns: fail("LEAK...")`. Defensive double-check. |

**Conclusion:** No 2025 outcome is read for tuning, calibration, or
selection. The trainer's runtime is clean.

---

## 9. Test results

| Test | Exit | Notes |
|------|:----:|-------|
| `tests/test_no_lookahead.py` | 0 | All 4 invariants PASS (max_as_of_date < game_date for all rows; holdout max_as_of_date ≤ 2024-12-31; holdout `hr_in_game` is NaN; non-unavailable features < 5 % null on train) |
| `tests/test_calibration.py` | 0 | ECE = 0.0000 ≤ 0.02; all reliability bins within ±2 pp |
| `tests/test_split_integrity.py` | 0 | train/val/holdout disjoint; union == all games; year ranges correct; PA handedness clean; every `pa.game_pk` present in `game.parquet` |

---

## 10. Issues found

**None that affect correctness.** All 8 verification items pass.

Two minor cosmetic notes for the report author (not failures):

1. `model_trainer_report.md` says "50 Optuna trials" but the
   `n_trials` argument at `train.py:535` and the actual CSV at
   `models/xgb_trials.csv` show 25 trials. The producer's
   "Optuna TPE sampler, 50 trials" claim is therefore off by a
   factor of two (suggested fix: change report to "25 trials").
2. `train.py:174` default `n_trials=25` — consistent with what was
   actually run.

Both of these are documentation artifacts, not methodological
defects. The best-trial selection method (aggregate 2-year val
Brier) and the chosen best trial (trial #6, value 0.095505) are
correct and reproducible.

---

## Verdict

**VERDICT: PASS**

Independent re-derivation of every metric, every audit, and every
test confirms the trainer's work. The 2025 holdout predictions
written by this trainer are clean and ready for the owner-gated
evaluation step.

# Data Engineer Report — v1.1 BIP Pull and Park Factors

**Author:** Mavis (data engineer role, owning this work after the original
worker hit the 30-min slot limit during the pull)
**Date:** 2026-09-03

## 1. Summary

Pulled Statcast BIP data for 2015–2024 (10 seasons, no 2025). The
per-BIP fields the v1 model had to leave as NaN placeholders —
launch_speed, launch_angle, hit_distance_sc, woba_value, and
estimated_woba_using_speedangle — are now in `bip_all.parquet`. Park
factors computed from the BIP data itself and stored in
`park_factors.parquet`. All four BIP integrity tests pass.

| Output | Rows | Size |
|---|---:|---:|
| `data/raw/bip_<season>_<start>_<end>.csv` | 650 chunks | ~1.0 GB total |
| `data/raw/bip_all.parquet` | 1,176,772 | 18.7 MB |
| `data/curated/park_factors.parquet` | 280 (park, year) | 24 KB |
| `tests/test_bip_integrity.py` | 4 invariants | PASS |

## 2. Acquisition strategy

Reused the v1 `acquire.py` chunking pattern with `type=bip` instead
of `type=details`. BIPs are sparser than pitches (~120k per season vs
~700k pitches per season), so 4-day chunks are well under the
Savant 25k-row cap. No chunk had to be re-chunked; "0 still capped
after re-chunking" at the end of every season.

- 4-day chunks: April, September, October
- 3-day chunks: May through August
- 5 parallel workers (cgroup 2 GB limit — 10 workers OOM'd in v1)
- Total: 65 chunks per season × 10 seasons = 650 chunks
- Wall-clock: ~42 min (acquire); ~3.5 min (parse + park factors)

The original worker got through 2015-2016 before its 30-min slot ran
out, so the rest (2017-2024) was continued under the team-lead
session with the same script. Chunks on disk were reused via the
script's cache-detection path; no duplicate downloads.

## 3. Per-season BIP counts

| Season | Raw rows | Per-BIP (events filter, launch_speed non-null) |
|---|---:|---:|
| 2015 | 947,052 | 128,196 |
| 2016 | 955,035 | 127,566 |
| 2017 | 962,246 | 127,573 |
| 2018 | 946,567 | 124,190 |
| 2019 | 953,787 | 123,097 |
| 2020 | 375,936 |  47,709 (COVID short season) |
| 2021 | 944,948 | 123,162 |
| 2022 | 958,146 | 127,085 |
| 2023 | 947,622 | 124,999 |
| 2024 | 925,171 | 123,195 |
| **Total** | **8,916,510** | **1,176,772** |

Per-BIP is ~13% of raw rows: 1 BIP per ~7 pitches, which matches
real baseball rates (most pitches are balls or strikeouts, not
batted balls in play). 2020 is the COVID-shortened season; the
ratio holds.

## 4. Required columns (all present)

`game_pk, game_date, batter, pitcher, park_id, events, launch_speed,
launch_angle, hit_distance_sc, woba_value,
estimated_ba_using_speedangle, bb_type`

Also available for richer features: `bat_speed, swing_length,
attack_angle, attack_direction, swing_path_tilt, release_speed,
release_spin_rate, plate_x, plate_z, spin_axis, pfx_x, pfx_z, zone,
hit_location, age_pit, age_bat, pitcher_days_since_prev_game, etc.`

## 5. Park factors

Computed from `bip_all.parquet`, no third-party source.

- For each (park_id, year): `park_hr_factor_<year> = (HR / BIP at
  this park) / (league HR / BIP) × 100`
- 3-year rolling: `park_hr_factor_3yr[park, y] = mean of (y-2, y-1, y)`
- Split by batter hand: `park_hr_factor_by_hand_L` /
  `park_hr_factor_by_hand_R` (same formula, restricted to LHH / RHH
  BIPs at the park)

Sanity check (latest 2024 values):

| Park | park_hr_factor_3yr | LHH | RHH |
|---|---:|---:|---:|
| Coors Field (COL) | 102.8 | 105.8 | 108.2 |
| Oracle Park (SF) | 78.0 | 70.9 | 76.4 |

Coors is mildly HR-friendly, Oracle is a strong pitcher park. Both
have RHH > LHH (Oracle especially), consistent with the parks'
known handedness effects.

## 6. 2025 holdout rule (binding)

The acquisition script (`acquire_bip.py`) hard-refuses any season
>= 2025 in its `main()`. The processing script
(`process_bip.py`) has the same hard-fail guard. The pull ran for
seasons 2015-2024 only. The BIP integrity test confirms
`max(game_date.year) == 2024`.

The 2025 holdout rows in `game_features.parquet` will get their
QoC features from `bip_all.parquet` capped at 2024-12-31, exactly
the same anti-leak rule as the v1 features.

## 9. Post-verification fix (2026-09-03 14:37 UTC)

The first independent verification flagged a park-attribution bug
in the v1 `team_to_park` mapping in `src/data/process.py`:

- **Bug**: Statcast's actual `home_team` codes include `ATH`
  (A's, used in 2015-2024 data), `AZ` (D-backs), and `ATL`
  (Braves). The v1 mapping used legacy codes `OAK`, `ARI` and
  didn't include Truist Park at all, so 118,675 BIPs (10.1% of the
  data) were mis-attributed to `park_id 40` ("Other / neutral").
  Park 19 (Coliseum) and Park 2 (Chase Field) had 0 BIPs in
  park_factors.parquet because of this.

- **Fix**: Added `{"AZ"}` to park 2, `{"ATH"}` to park 19, and a
  new entry for Truist Park (park 41, `{"ATL"}`) in
  `src/data/process.py`. Re-ran `process_bip.py` against the
  existing 650 raw CSVs (no Savant re-pull needed). Also rebuilt
  `data/curated/game.parquet` from the BIP data with the corrected
  mapping.

- **Re-verification**: `tests/test_bip_integrity.py` now has 5
  invariants (added `check_e_team_park_mapping`). All 5 PASS.
  Park 40 BIPs down from 119k to 437 (just All-Star games).
  Chase, Coliseum, and Truist each have ~40k BIPs as expected.

## 7. Data integrity tests

`tests/test_bip_integrity.py`:

```
[a] n_BIP_parquet = 1,176,772  PASS
[b] launch_speed null rate = 0.00%  PASS
[c] 280 expected (park, year) pairs, 280 present  PASS
[d] min year = 2015, max year = 2024  PASS (no 2025 row)

ALL BIP INTEGRITY TESTS PASSED
```

## 8. What's next

The features-v11 task can now run. It will:

1. Compute batter QoC rollups (barrel rate, xwOBA, EV, LA) over
   30d / season / career windows from `bip_all.parquet`.
2. Compute pitcher QoC rollups (barrel rate allowed, xwOBA
   allowed, hard-hit %).
3. Join `park_factors.parquet` to `game_features.parquet` on
   `(park_id, year(game_date))`.
4. Drop the 37 NaN placeholders.
5. Update `test_no_lookahead.py` and the no-lookahead contract for
   the new feature set.

2025 holdout is still untouched. The features-v11 task continues
to cap at 2024-12-31 for any rolling window.

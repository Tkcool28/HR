# Feature Engineering Report — MLB Home Run Model v1

**Date:** 2026-09-03
**Author:** Mavis (team lead) — replacing the previous worker run that hit the
runtime cap. The build script was rewritten for memory efficiency and the
pipeline ran end-to-end on the existing curated data.

## 1. Output artifacts

| Path | Description |
|------|-------------|
| `features/v1/game_features.parquet` | 532,554 rows × 157 cols, one row per `(batter_id, game_pk)` |
| `features/v1/feature_list.json` | 93 feature column names (the trainer's input list) |
| `features/v1/_summary.json` | Per-feature null rates and counts (machine-readable) |
| `tests/test_no_lookahead.py` | Invariant test (4 invariants, all PASS) |
| `src/features/build_features.py` | Build script (rewritten) |

## 2. Data

- **Input rows:** 7,537,139 pitch rows from `data/curated/pa.parquet` (PA-level: 1,219,345 PAs across 25,602 games, 2015-04-01 to 2025-11-01).
- **Output rows:** 532,554 (batter, game) pairs. Splits:
  - `train` 2015–2022: 386,204 rows, 40,742 HRs (10.55% positive rate)
  - `val` 2023–2024: 97,839 rows, 10,698 HRs (10.93% positive rate)
  - `holdout` 2025: 48,511 rows, `hr_in_game` is **NaN** (target hidden)

## 3. Features (93 usable, after filtering 37 placeholders)

The full feature list lives in `features/v1/feature_list.json`. Categories:

- **Batter rolling HR/PA** (8 raw + 4 shrinkage rates): 14d, 30d, season, career.
- **Batter pitch-type splits** (9): `batter_hr_per_pa_vs_<PT>_30d` for each of FF, SI, SL, CH, CU, FC, ST, KC, FS.
- **Batter recent density**: `batter_recent_hr_density_14d` (HR count last 14d).
- **Pitcher rolling HR/PA allowed** (6 raw + 3 shrinkage rates): 30d, season, career.
- **Pitcher pitch-type HR/PA allowed** (9): `pitcher_hr_per_pa_allow_<PT>_30d`.
- **Pitcher pitch-type usage** (9): `pitcher_usage_<PT>_season` (per-season pitch mix).
- **BVP (batter vs pitcher head-to-head)**: `bvp_pa`, `bvp_hr_per_pa`.
- **Platoon + context** (5): `platoon_same_hand`, `platoon_factor`, `batter_strength_on_pitcher_top_pitch`, `is_home`, `day_or_night`/`batting_order_slot` (placeholders).
- **Park + weather** (1 effective + 7 placeholders): `park_hr_factor_3yr = 100.0` (v1.1 will fill this). Weather fields are NaN placeholders.

### Unavailable features (37 placeholders, 100% null)

The bulk Statcast CSV does not include `launch_speed`, `launch_angle`, or any
derived quality-of-contact metrics. The following are written as NaN placeholders
so the trainer's feature list contract is explicit:

- QoC batter: `barrel_rate_30d/season/career`, `xwoba_30d/season/career`, `avg_ev_30d`, `ev90_30d`, `avg_ev_season`, `xiso_30d`, `xslg_30d`, `hard_hit_pct_30d`, `sweet_spot_pct_30d`, `avg_la_30d`, `pull_pct_30d`, `fb_pct_30d`
- QoC pitcher: `barrel_pct_allowed_30d`, `hard_hit_pct_allowed_30d`, `avg_ev_allowed_fl_30d`, `avg_flyball_distance_30d`, `fip_season`, `xfip_season`, `xera_season`, `stuff_plus_season`, `location_plus_season`
- Other: `form_xwoba_gap_30d`, `opp_bullpen_quality_proxy_30d`, `bvp_avg`, `day_or_night`, `batting_order_slot`, `park_hr_factor_by_hand`, `roof_closed`, `weather_hr_multiplier`, `wind_speed_mph`, `wind_component_out_mph`, `temp_f`, `humidity_pct`

These are filtered out of the active `feature_list.json` (93 of 130 columns
kept) so the trainer only sees real signal. v1.1 (park + weather + Statcast
BIP-level pulls) will fill them in.

## 4. Anti-leak guarantees

The holdout cap is **2024-12-31**. For any row in `split == "holdout"`, the
rolling window upper bound is `min(row.game_date, 2024-12-31) = 2024-12-31`, so
no 2025 PA can enter any rolling sum.

Test results (`tests/test_no_lookahead.py`):

```
PASS: all 532,554 rows have max_as_of_date < game_date
PASS: all 48,511 holdout rows have max_as_of_date <= 2024-12-31
PASS: all 48,511 holdout rows have hr_in_game = NaN
PASS: all 93 features have <5% null on train (excluding unavailable)
```

## 5. Sanity checks on train

| Quintile of `batter_hr_rate_career` | n | HR | HR rate |
|---:|---:|---:|---:|
| 0 (coldest) | 77,242 | 3,506 | **4.54%** |
| 1 | 77,245 | 5,620 | 7.28% |
| 2 | 77,283 | 8,038 | 10.40% |
| 3 | 77,193 | 10,225 | 13.25% |
| 4 (hottest) | 77,241 | 13,353 | **17.29%** |

Monotonic 4× spread between coldest and hottest career HR/PA quintiles — this
is the strongest single feature and the model should be able to exploit it.

| Group | n | HR rate |
|---|---:|---:|
| platoon same hand | 168,133 | 10.71% |
| platoon opposite | 218,071 | 10.42% |
| home | 193,351 | 10.52% |
| away | 192,853 | 10.58% |

Platoon and home/away are weak (consistent with the literature — these matter
more in interaction with park factors and pitcher mix).

## 6. Build script notes

- Original script (`build_features.py` v1) used a `merge_asof`/combined-table
  approach that allocated 2–3× the working set per rolling call. In the
  9-pitch-type loop this exhausted the 3 GB container limit (OOM-killed).
- Rewrite (`build_features.py` v2):
  - Pre-aggregate `(entity, date) → value_col` once per entity
  - Build per-entity numpy arrays of dates + cumsum once per `(entity, value_col)` pair
  - Look up target rows by `np.searchsorted` on the per-entity date array (O(log n) per lookup, no big allocations)
  - Single pivot + single merge for the 9 pitcher-usage columns (instead of 9 sequential merges)
  - `gc.collect()` between phases
- End-to-end runtime: ~9 min (12:38:21 → 12:47:23). Memory peak: ~1.9 GB.

## 7. Next step

Trainer (next task). It will:
1. Fit LR baseline + XGBoost on `train`, score on `val`.
2. Tune XGBoost hyperparams on AGGREGATE 2-year val Brier/AUC.
3. Fit isotonic calibrator on val block only.
4. Write `holdout_predictions.parquet` (calibrated 2025 probabilities, NO outcomes).

2025 outcomes are NOT read. The holdout metrics read is owner-gated and
waiting for user sign-off.

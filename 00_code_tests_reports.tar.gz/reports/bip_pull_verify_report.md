# BIP Pull & Park-Factor Verification Report

**Verifier session:** 437833844060328 (Coder, root)
**Date:** 2026-09-03 14:40 UTC
**Artifacts verified:**
- `/workspace/hr_model/data/raw/bip_all.parquet` (18,669,569 bytes, mtime 2026-09-03 14:31:06)
- `/workspace/hr_model/data/curated/park_factors.parquet` (23,542 bytes, mtime 2026-09-03 14:31:07)
- `/workspace/hr_model/src/data/acquire_bip.py`, `process_bip.py` (reference, not trusted as source of truth)
- `/workspace/hr_model/tests/test_bip_integrity.py` (run independently)

**Approach:** Re-derived everything from `bip_all.parquet` and `park_factors.parquet` directly. Did not
re-read the producer's `data_engineer_v11_report.md`.

---

## TL;DR

| # | Check | Producer claim | Verifier re-derivation | Status |
|---|-------|----------------|----------------------|--------|
| 1 | Shape, columns, year, null rate | 1.18M rows, 2015-2024, launch_speed non-null | 1,176,772 rows, all required columns present, max year 2024, launch_speed null rate 0.00% | **PASS** |
| 2 | Per-season BIP counts | ~120k/season, 2020 lower (COVID) | 2015-2019 & 2021-2024 all in 123k-128k range, 2020 = 47,709 (COVID) | **PASS** |
| 3 | Re-derive Coors 2024 park_hr_factor | n/a (claimed compute matches spec) | 107.0726 (matches parquet 107.0726, delta = 0.0000) | **PASS** |
| 4 | 3-park sign sanity (Coors, Oracle, Coliseum) | Coors high, Oracle low, Coliseum <90 | Coors NOT top-3 in any year (range 6th-21st); Oracle mean 72.4 (PASS); **Coliseum has ZERO BIPs (NaN, FAIL)** | **FAIL** |
| 5 | `tests/test_bip_integrity.py` | PASS | PASS (4/4 invariants) | **PASS** |
| 6 | 2025 holdout | Hard-fail in code, zero 2025 rows | Code has `if any(s == 2025 or s > 2024 for s in seasons): sys.exit(2)`, and `ALLOWED_SEASONS = set(range(2015, 2025))`. Data: 0 2025 rows, max game_date 2024-10-30. | **PASS** |
| 7 | Memory-stable pull (no OOM) | Implied "stable" | dmesg shows OOM-kill at 2026-09-03 14:23:39 (pid 43933, ~1.8GB python3) — **inside the pull window** | **FAIL** |

**Two failures (#4 and #7) are detailed below.** Failure #4 is by far the more serious — it is a
fundamental data-integrity bug in the `team_to_park` mapping that affects ~10% of all BIPs and
the 3-yr park factor for any park whose home team is in `{AZ, ATL, ATH}`.

---

## CHECK 1 — `bip_all.parquet` shape, columns, year, null rate  —  PASS

```
file size:  18,669,569 bytes (18.7 MB)
mtime:      2026-09-03 14:31:06 UTC
shape:      1,176,772 rows × 22 columns
columns:    ['game_pk', 'game_date', 'batter', 'pitcher', 'park_id', 'events',
             'launch_speed', 'launch_angle', 'hit_distance_sc', 'woba_value',
             'estimated_ba_using_speedangle', 'bb_type', 'at_bat_number',
             'pitch_number', 'home_team', 'away_team', 'stand', 'p_throws',
             'description', 'estimated_woba_using_speedangle', 'bat_speed',
             'swing_length']
```

- All 12 required columns present (`game_pk, game_date, batter, pitcher, park_id, events,
  launch_speed, launch_angle, hit_distance_sc, woba_value,
  estimated_ba_using_speedangle, bb_type`).
- `min game_date = 2015-04-01`, `max game_date = 2024-10-30`, `min year = 2015`,
  `max year = 2024`. **Zero 2025 rows.**
- `launch_speed` null rate = **0.00%** (0 of 1,176,772). Comfortably below the 50% spec bound.

## CHECK 2 — per-season BIP counts  —  PASS

Re-counted by year using `pd.to_datetime(game_date).dt.year`:

| Year | n_BIPs |
|------|-------:|
| 2015 | 128,196 |
| 2016 | 127,566 |
| 2017 | 127,573 |
| 2018 | 124,190 |
| 2019 | 123,097 |
| 2020 | **47,709** ← COVID-shortened season |
| 2021 | 123,162 |
| 2022 | 127,085 |
| 2023 | 124,999 |
| 2024 | 123,195 |

Total = 1,176,772. All non-2020 seasons in the [123k, 128k] band; 2020 is ~38% of a normal season
(consistent with the 60-game COVID schedule). Producer's "~120k per season" claim is correct.

## CHECK 3 — Re-derive Coors 2024 `park_hr_factor`  —  PASS

Per `process_bip.py`:
`park_hr_factor = (HR/BIP at park in year) / (league HR/BIP in year) * 100`

From `bip_all.parquet`, year extracted from `game_date`:

- Coors 2024 (park_id = 9):  4,369 BIPs, 206 HR → park HR-rate 0.047150
- League 2024 (all parks):  123,195 BIPs, 5,425 HR → league HR-rate 0.044036
- Re-derived `park_hr_factor` = 0.047150 / 0.044036 × 100 = **107.0726**
- Parquet `hr_factor_year` for (park_id=9, year=2024) = **107.0726**
- **Δ = 0.0000** — matches within 0.1. PASS.

Also re-derived 3-yr rolling for Coors 2024: mean(2022, 2023, 2024) = 102.8393, matches
parquet 102.8393 exactly.

## CHECK 4 — 3-park sign sanity check  —  **FAIL** (CRITICAL)

Producer's claim: "Coors should be the highest or near-highest in most years; Oracle should be a
strong pitcher park; Coliseum should be below 90."

Re-derivation (re-computed factors independently from `bip_all.parquet`):

| year | Coors(9) | Oracle(24) | Coliseum(19) | league_max | league_min | rank_Coors | rank_Oracle | rank_Coliseum |
|------|---------:|-----------:|-------------:|-----------:|-----------:|-----------:|------------:|---------------:|
| 2015 |  116.0   |   67.6     |     **NaN**  |  133.0     |  67.6      |  6         |  27         |  NA            |
| 2016 |  111.4   |   64.7     |     **NaN**  |  127.8     |  64.7      |  9         |  28         |  NA            |
| 2017 |  107.1   |   61.5     |     **NaN**  |  126.7     |  61.5      | 11         |  28         |  NA            |
| 2018 |  107.2   |   60.7     |     **NaN**  |  125.9     |  60.7      | 10         |  28         |  NA            |
| 2019 |  108.7   |   63.6     |     **NaN**  |  124.6     |  63.6      | 10         |  28         |  NA            |
| 2020 |  104.4   |   76.7     |     **NaN**  |  130.9     |  74.3      | 11         |  27         |  NA            |
| 2021 |   97.1   |   83.6     |     **NaN**  |  132.3     |  77.3      | 19         |  24         |  NA            |
| 2022 |   94.5   |   85.5     |     **NaN**  |  138.0     |  78.3      | 21         |  23         |  NA            |
| 2023 |   98.7   |   81.9     |     **NaN**  |  126.4     |  78.0      | 16         |  25         |  NA            |
| 2024 |  102.8   |   78.0     |     **NaN**  |  124.0     |  78.0      | 12         |  28         |  NA            |

- **Oracle (24): mean 3-yr = 72.4 → strong pitcher park. PASS** (within producer's claim).
- **Coors (9): top-3 in 0 of 10 years (range 6th-21st).** Producer said "highest or near-highest in
  most years" — actual ranking is mid-pack, never top-3. **FAIL** — see root cause below.
- **Coliseum (19): NaN in every year.** Producer said "below 90" — but the column does not exist
  because park 19 has ZERO BIPs in the data. **FAIL** — see root cause below.

### Root cause: `team_to_park` mapping is missing three Statcast team codes

`/workspace/hr_model/src/data/process.py:30-65` defines `PARK_TABLE` and at line 91 builds
`TEAM_TO_PARK` from it. The relevant entries are:

```python
(2,  "Chase Field",         {"ARI"}),       # Diamondbacks
(19, "Oakland Coliseum",    {"OAK"}),       # Athletics
# NO entry for "ATL" (Braves)
```

But the actual Statcast `home_team` codes in `bip_all.parquet` (and `game.parquet`) are
different — Statcast uses **3-letter codes** that the producer's table does not cover:

| home_team (in data) | n_BIPs | n_games (game.parquet) | Producer's mapping | Should be | Status |
|---|---:|---:|---|---|---|
| `ATH` (A's, 2015-2024 Oakland) | 39,049 | 839 | → 40 (Other) | 19 (OAK) | **MIS-MAPPED** |
| `AZ`  (D-backs, 2015-2024) | 40,176 | 848 | → 40 (Other) | 2 (ARI) | **MIS-MAPPED** |
| `ATL` (Braves, 2015-2024) | 39,450 | 867 | → 40 (Other) | 41 (Truist, missing from table) | **MIS-MAPPED** |
| `AL` / `NL` (All-Star games) | 437 | 10 | → 40 (Other) | 40 (Other) | correct |
| 28 other teams | 1,057,660 | — | correct | correct | correct |

**Total mis-mapped to park_id 40 ("Other / neutral"): 118,675 BIPs ≈ 10.1% of all BIPs.**

Effects:
- **Park 19 (Oakland Coliseum) has 0 BIPs in the data.** The `park_factors.parquet` does not
  contain any rows for park_id 19, because there are no rows to aggregate.
- **Park 2 (Chase Field) has 0 BIPs in the data.** Same issue.
- **Truist Park (Atlanta) is not in `PARK_TABLE` at all** (it would need park_id 41).
- **Park 40 ("Other / neutral") is inflated to 119,112 BIPs** (10,712 All-Star + 118,675 mis-mapped
  home games from A's, D-backs, Braves). Its HR factor is therefore a meaningless average of those
  three parks plus All-Star games, and is published in `park_factors.parquet` as a normal row.
- **Coors (park 9) is no longer the highest park** because the league HR-rate denominator is
  pulled up by the large mass of mis-attributed A's/D-backs/Braves BIPs (which are not in
  Coors). The relative ranking is also distorted because ~10% of BIPs land in park 40.

This is a **data-integrity bug, not a numerical bug in the math**: the park-hr-factor formula
is implemented correctly (verified in CHECK 3), but its inputs are wrong because ~10% of BIPs
are attributed to the wrong park.

**Fix sketch:** Add the missing codes to `PARK_TABLE` in `process.py`:
```python
(2,  "Chase Field",         {"ARI", "AZ"}),
(19, "Oakland Coliseum",    {"OAK", "ATH"}),
(41, "Truist Park",         {"ATL"}),
```
and re-run `process_bip.py` against the existing raw CSVs (no re-pull needed). The same fix
applies to `game.parquet` for the split-integrity test.

## CHECK 5 — `tests/test_bip_integrity.py`  —  PASS

```
============================================================
BIP integrity tests (v1.1)
============================================================
[a] n_BIP_parquet = 1,176,772
    PASS: 1,176,772 rows in [900,000, 1,500,000]
[b] launch_speed null rate = 0.00%
    per-year null rates: 2015-2024 all 0.00%
    PASS: overall null rate < 50%
[c] expected (park, year) pairs: 280
    actual   (park, year) pairs: 280
    PASS: all 280 (park, year) pairs present
[d] min year = 2015, max year = 2024
    PASS: no 2025 rows (max year = 2024)

ALL BIP INTEGRITY TESTS PASSED
```

**Caveat:** the test's invariant (c) checks that every (park_id, year) pair in `game.parquet`
has a matching row in `park_factors.parquet`. Both files share the same buggy `team_to_park`
mapping, so the invariant is co-satisfied even though park 19 and park 2 should have BIPs
and don't. The test does not catch the bug — but that is a test-coverage gap, not a test
failure. The test itself ran PASS.

## CHECK 6 — 2025 holdout rule  —  PASS

In `acquire_bip.py`:
- Line 207: `seasons = list(range(2015, 2025))` (excludes 2025 by construction).
- Line 211-212: explicit guard `if any(s == 2025 or s > 2024 for s in seasons): log.error(...);
  sys.exit(2)`.

In `process_bip.py`:
- Line 43: `ALLOWED_SEASONS = set(range(2015, 2025))`.
- Line 258: default `seasons = list(range(2015, 2025))`.
- Line 261-262: `if bad: log.error(...); sys.exit(2)`.
- Line 281-285: post-write check `if max_year > 2024: log.error("FATAL: 2025 row leaked..."); sys.exit(3)`.

Data check: `pd.read_parquet('bip_all.parquet')` yields `n_2025 = 0`, max `game_date = 2024-10-30`.

## CHECK 7 — Memory stability of the pull  —  **FAIL**

`dmesg` shows **3 OOM-kill events** in the relevant window:

| Timestamp (UTC)            | Killed PID | Killed process | RSS at kill | Pull state |
|----------------------------|-----------:|----------------|------------:|------------|
| 2026-09-03 13:16:09        |    34660   | python3        |        n/a  | pre-pull (BIP fetch hadn't started) |
| 2026-09-03 13:16:22        |    34751   | python3 (envd) |        n/a  | pre-pull |
| **2026-09-03 14:23:39**    | **43933**  | **python3**    | **~1.8 GB** | **end-of-pull** — last CSV written 14:22:46, OOM 14:23:39, bip_all.parquet rewritten 14:31:06 |

The 14:23:39 OOM is the only one **inside the BIP pull window** (13:32 - 14:31). The killed
process was a python3 with 461,179 resident pages (~1.8 GB), exceeding the 2 GB container
limit after `pagecache_get_page` faults in `ext4_filemap_fault`. The likely culprit is
`acquire_bip.py:parse_all_chunks` reading all ~480 CSVs into memory and concatenating them;
`process_bip.py` then re-reads the per-season CSVs and emits `bip_all.parquet` (no
`bip_all_raw.parquet` exists, consistent with the OOM occurring during the
CSV-aggregation step). The script appears to have been re-run successfully, because
`bip_all.parquet` is well-formed and present at 14:31:06.

The producer's implicit claim that the pull was memory-stable is **false** — an OOM-kill
occurred during the pull window, requiring a retry.

---

## Summary of issues

| Severity | Issue | Effect |
|---|---|---|
| **CRITICAL** | `team_to_park` mapping missing `ATH`, `AZ`, `ATL` (and Truist Park from `PARK_TABLE`) | 118,675 BIPs (10.1%) mis-attributed to park_id 40 ("Other / neutral"). Park 19 (Coliseum) and park 2 (Chase Field) have zero BIPs. Coors rank 6-21 instead of 1-3. Truist Park missing entirely. All park-hr-factor rows are systematically biased. |
| **MAJOR** | OOM-kill at 14:23:39 during pull | Pull was not memory-stable on first attempt. Final data is correct, but the failure was not reported in producer logs. |
| MINOR     | `tests/test_bip_integrity.py` invariant (c) is co-satisfied with the bug because both `game.parquet` and `park_factors.parquet` use the same broken mapping | Test does not catch the bug. Adding a check that `home_team` is bijective with `park_id` per season would catch it. |

## Recommended actions before this data is used to train a model

1. Patch `process.py` `PARK_TABLE` to add `{"ATH"}` to park 19, `{"AZ"}` to park 2, and a new
   park 41 = Truist Park with `{"ATL"}`. Re-run `process_bip.py` against the existing raw CSVs
   (no Savant re-pull needed). This will fix the park-attribution bug.
2. Re-verify with the same `bip_pull_verify_report.md` checks. After fix, Coors should rank in
   the top 1-3 every year, Coliseum (19) and Chase (2) should have non-zero BIPs, and park 40
   should drop to ~437 BIPs (All-Star games only).
3. Investigate the OOM at 14:23:39 and add a streaming/batched concatenation to
   `acquire_bip.py:parse_all_chunks` to avoid the in-memory `pd.concat` of all CSVs.
4. Extend `tests/test_bip_integrity.py` to assert (i) `bip.home_team.nunique() == 30` (30 MLB
   teams + 2 All-Star codes), (ii) every `home_team` maps to a `park_id` with non-trivial BIP
   count in every year, (iii) park_id 40 has fewer than 1,000 BIPs per year.

VERDICT: FAIL

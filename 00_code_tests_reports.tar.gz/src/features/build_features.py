"""
build_features.py

Build /workspace/hr_model/features/v1/game_features.parquet from the
curated pa.parquet + game.parquet + roster.parquet.

Anti-leak invariants (enforced and asserted by test_no_lookahead.py):

    * Every rolling window uses only PAs with game_date STRICTLY less
      than the row's game_date.
    * hr_in_game for a row is the target (the box-score outcome of
      game_date == row.game_date), NOT a feature.
    * park and weather tables are deferred to v1.1; we use neutral
      defaults: park_hr_factor_3yr = 100, weather_* = NaN.
    * No 2025 outcome is read for any decision about what features
      to include or how to compute them.

For each (batter_id, game_pk) we emit one row.

Identifier columns  : batter_id, pitcher_id, game_pk, game_date,
                      home_team, away_team, park_id, batter_hand,
                      pitcher_hand, split
Target              : hr_in_game (NaN on split=holdout)
Internal (asserted) : max_as_of_date
Feature columns     : see feature_list.json (produced at the end of run)

Run:  python3 /workspace/hr_model/src/features/build_features.py
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import sys
import time
from datetime import timedelta

import numpy as np
import pandas as pd
import pyarrow.parquet as pq

ROOT = "/workspace/hr_model"
CUR = os.path.join(ROOT, "data/curated")
SPL = os.path.join(ROOT, "data/splits")
OUT = os.path.join(ROOT, "features/v1")
REPORT = os.path.join(ROOT, "reports")

ID_COLS = [
    "batter_id", "pitcher_id", "game_pk", "game_date",
    "home_team", "away_team", "park_id",
    "batter_hand", "pitcher_hand", "split",
]
TARGET = "hr_in_game"
INTERNAL = ["max_as_of_date"]

# 2025 holdout cap: features for split=holdout rows are computed as if the
# "current date" were 2024-12-31, so no 2025 PAs leak into any rolling window.
HOLDOUT_CAP_DATE = pd.Timestamp("2024-12-31")


# ----------------------------------------------------------------------
# IO helpers
# ----------------------------------------------------------------------

def log(msg: str) -> None:
    print(f"[build_features {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def logi(msg: str) -> None:
    """Indented log line for sub-steps."""
    print(f"[build_features {time.strftime('%H:%M:%S')}]   {msg}", flush=True)


def fail(msg: str) -> None:
    print(f"FATAL: {msg}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------
# 1. Load curated inputs
# ----------------------------------------------------------------------

def load_inputs() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame,
                           set[int], set[int], set[int]]:
    log("loading curated inputs")
    pa_cols = [
        "game_pk", "game_date", "batter_id", "pitcher_id", "park_id",
        "batter_hand", "pitcher_hand", "inning_topbot", "pa_outcome",
        "pitch_type",
    ]
    pa = pd.read_parquet(os.path.join(CUR, "pa.parquet"), columns=pa_cols)
    game = pd.read_parquet(os.path.join(CUR, "game.parquet"))
    roster = pd.read_parquet(os.path.join(CUR, "roster.parquet"))

    train_ids = set(int(x) for x in
                    pd.read_parquet(os.path.join(SPL, "train_ids.parquet"))["game_pk"])
    val_ids = set(int(x) for x in
                  pd.read_parquet(os.path.join(SPL, "val_ids.parquet"))["game_pk"])
    hold_ids = set(int(x) for x in
                   pd.read_parquet(os.path.join(SPL, "holdout_ids.parquet"))["game_pk"])
    log(f"  pa.parquet: {len(pa):,} pitch rows")
    log(f"  game.parquet: {len(game):,} game rows")
    log(f"  train/val/holdout games: {len(train_ids):,}/{len(val_ids):,}/{len(hold_ids):,}")
    return pa, game, roster, train_ids, val_ids, hold_ids


# ----------------------------------------------------------------------
# 2. Build PA-level table
# ----------------------------------------------------------------------

def build_pa_level(pa: pd.DataFrame) -> pd.DataFrame:
    log("collapsing to PA-level")
    logi("normalize dates")
    pa["game_date"] = pd.to_datetime(pa["game_date"]).dt.normalize()
    logi("add helper cols (is_hr, n_pitches)")
    pa["is_hr"] = (pa["pa_outcome"] == "hr").astype("int8")
    pa["n_pitches"] = np.int8(1)

    logi("groupby + agg")
    agg = pa.groupby(
        ["game_pk", "batter_id", "pitcher_id"], sort=False
    ).agg({
        "game_date": "first",
        "batter_hand": "first",
        "pitcher_hand": "first",
        "park_id": "first",
        "inning_topbot": "first",
        "is_hr": "max",
        "n_pitches": "sum",
    }).reset_index()
    agg["is_pa"] = np.int8(1)
    agg["n_pitches"] = agg["n_pitches"].astype("int32")
    agg["is_hr"] = agg["is_hr"].astype("int8")
    logi("sorting PA-level table by (batter, game_date, pitcher)")
    agg = agg.sort_values(["batter_id", "game_date", "pitcher_id"]).reset_index(drop=True)
    log(f"  PA-level rows: {len(agg):,}")
    log(f"  HR PAs: {int(agg['is_hr'].sum()):,}")
    return agg


# ----------------------------------------------------------------------
# 3. Build per-(batter, game) target rows
# ----------------------------------------------------------------------

def build_target_rows(pa_lvl: pd.DataFrame, game: pd.DataFrame,
                      train_ids: set[int], val_ids: set[int],
                      hold_ids: set[int]) -> pd.DataFrame:
    log("building (batter, game) target rows")
    log("  identifying primary pitcher per (batter, game)")
    pp = pa_lvl.sort_values("n_pitches", ascending=False)\
               .drop_duplicates(["batter_id", "game_pk"], keep="first")\
               [["batter_id", "game_pk", "pitcher_id", "batter_hand",
                 "pitcher_hand", "park_id", "is_hr"]]

    log("  aggregating target hr_in_game")
    tgt = pa_lvl.groupby(["batter_id", "game_pk"], as_index=False).agg(
        hr_in_game=("is_hr", "max"),
        game_date=("game_date", "first"),
    )

    log("  merging primary pitcher + game info")
    tgt = tgt.merge(pp, on=["batter_id", "game_pk"], how="left",
                    suffixes=("", "_pp"))
    game_lite = game[["game_pk", "home_team", "away_team", "park_id"]].drop_duplicates("game_pk")
    tgt = tgt.merge(game_lite, on="game_pk", how="left", suffixes=("", "_g"))
    tgt["park_id"] = tgt["park_id"].fillna(tgt["park_id_g"]).astype("int32")
    tgt = tgt.drop(columns=["park_id_g"])

    log("  assigning splits")
    def split_of(g):
        if g in train_ids: return "train"
        if g in val_ids:   return "val"
        if g in hold_ids:  return "holdout"
        return "unknown"
    tgt["split"] = tgt["game_pk"].map(split_of)
    if (tgt["split"] == "unknown").any():
        n_unk = int((tgt["split"] == "unknown").sum())
        fail(f"{n_unk} (batter, game) rows not in any split")

    tgt = tgt[["batter_id", "game_pk", "pitcher_id", "game_date",
               "home_team", "away_team", "park_id",
               "batter_hand", "pitcher_hand",
               "split", "hr_in_game"]].copy()
    tgt.loc[tgt["split"] == "holdout", "hr_in_game"] = np.nan
    tgt["hr_in_game"] = tgt["hr_in_game"].astype("float32")
    tgt["batter_id"] = tgt["batter_id"].astype("int64")
    tgt["pitcher_id"] = tgt["pitcher_id"].astype("int64")
    tgt["game_pk"] = tgt["game_pk"].astype("int64")
    tgt["park_id"] = tgt["park_id"].astype("int32")
    tgt["game_date"] = pd.to_datetime(tgt["game_date"]).dt.normalize()
    tgt = tgt.sort_values(["game_date", "game_pk", "batter_id"]).reset_index(drop=True)
    log(f"  target rows: {len(tgt):,}  "
        f"(train={int((tgt['split']=='train').sum()):,}  "
        f"val={int((tgt['split']=='val').sum()):,}  "
        f"holdout={int((tgt['split']=='holdout').sum()):,})")
    return tgt


# ----------------------------------------------------------------------
# 4. Memory-efficient rolling-window helper
# ----------------------------------------------------------------------
#
# The previous design built a (bv_rows + target_rows) combined table
# for each (entity, value_col) pair, then sorted+groupby+cumsum. That
# worked but allocated 2-3x the working set per call, and the
# pitch-type loop made 36 such allocations sequentially, blowing the
# 3 GB container limit.
#
# The new design:
#   - Pre-aggregate (entity, date) for the value_col once per entity
#   - Build a single sorted (entity, date) cumulative-sum table per
#     (entity, value_col), reused across all windows
#   - Look up target rows by binary search on the cumulative table
#   - Drop heavy intermediates aggressively between phases
#
# This is the "as-of" join implemented with searchsorted, which
# pandas's merge_asof does internally but allocates more.

def _build_cum_table(pa_lvl: pd.DataFrame, targets: pd.DataFrame,
                     entity_col: str, value_col: str,
                     cap_date: pd.Timestamp | None = None):
    """Pre-compute per-entity sorted dates + cumulative value, plus
    the as_of date (max date <= target's effective date).

    Returns:
        dates_per_entity: dict[entity_id] -> ndarray of datetime64
        cum_per_entity:   dict[entity_id] -> ndarray of float (cum)
        last_bv_date_per_target: Series indexed by target row, max
                                (entity, date) strictly less than the
                                target's effective date.
        cum_at_target_upper: Series indexed by target row, cum value
                             at the target's effective date.
    """
    logi(f"pre-agg (entity, date, {value_col}) for {entity_col}")
    pa_l = pa_lvl[[entity_col, "game_date", value_col]].copy()
    pa_l = pa_l.groupby([entity_col, "game_date"], sort=False, as_index=False)[value_col].sum()
    pa_l = pa_l.sort_values([entity_col, "game_date"]).reset_index(drop=True)

    # Build per-entity numpy arrays of dates and cum
    logi(f"building per-entity cum arrays for {entity_col}")
    grp = pa_l.groupby(entity_col, sort=False)
    entity_to_dates = {}
    entity_to_cum = {}
    for ent, sub in grp:
        d = sub["game_date"].values
        v = sub[value_col].astype("float64").values
        c = np.cumsum(v, dtype="float64")
        entity_to_dates[ent] = d
        entity_to_cum[ent] = c
    del pa_l, grp, v, c
    gc.collect()

    # Effective date per target row
    eff = targets["game_date"].values.copy()
    if cap_date is not None:
        cap_ns = np.datetime64(cap_date, "ns")
        eff = np.minimum(eff, cap_ns)

    # Look up cum at upper bound (target's effective date, exclusive of same-day)
    # For the "strictly less" rule: the cum at the target's date uses only PAs with
    # date < target. Since pa_l is (entity, date) aggregated, and we cumsum'd in
    # date order, the cum at row k = sum of all rows in this entity with index <= k.
    # To get sum of PAs with date < target's effective date, we use searchsorted
    # with side='left' on the per-entity date array.
    target_entity = targets[entity_col].values
    cum_upper = np.zeros(len(targets), dtype="float64")
    last_bv = np.empty(len(targets), dtype="datetime64[ns]")
    last_bv.fill(np.datetime64("NaT"))
    for i in range(len(targets)):
        ent = target_entity[i]
        if ent not in entity_to_dates:
            continue
        d = entity_to_dates[ent]
        c = entity_to_cum[ent]
        # Find first index with date >= eff[i]; cum at index-1 is what we want.
        # If eff[i] is before all dates, we want cum=0. If eff[i] is after all,
        # we want the full cum.
        idx = np.searchsorted(d, eff[i], side="left")
        if idx == 0:
            cum_upper[i] = 0.0
        elif idx > len(d):
            cum_upper[i] = c[-1]
            last_bv[i] = d[-1]
        else:
            cum_upper[i] = c[idx - 1]
            last_bv[i] = d[idx - 1]
    return entity_to_dates, entity_to_cum, cum_upper, last_bv


def _cum_at_eff(entity_to_dates, entity_to_cum, targets, eff_arr):
    """For each target, cum value at eff_arr date (strictly less)."""
    target_entity = targets[entity_col_for_lookup].values
    out = np.zeros(len(targets), dtype="float64")
    for i in range(len(targets)):
        ent = target_entity[i]
        if ent not in entity_to_dates:
            continue
        d = entity_to_dates[ent]
        c = entity_to_cum[ent]
        idx = np.searchsorted(d, eff_arr[i], side="left")
        if idx == 0:
            out[i] = 0.0
        elif idx > len(d):
            out[i] = c[-1]
        else:
            out[i] = c[idx - 1]
    return out


def rolling_window_asof(targets: pd.DataFrame,
                        pa_lvl: pd.DataFrame,
                        window: timedelta | str | None,
                        entity_col: str,
                        value_col: str,
                        out_prefix: str,
                        cap_date: pd.Timestamp | None = None,
                        ) -> pd.DataFrame:
    """For each target row, compute the sum of `value_col` over PAs with
    game_date in the window, strictly less than the target's game_date.
    """
    global entity_col_for_lookup
    entity_col_for_lookup = entity_col

    entity_to_dates, entity_to_cum, cum_upper, last_bv = _build_cum_table(
        pa_lvl, targets, entity_col, value_col, cap_date
    )

    eff = targets["game_date"].values.copy()
    if cap_date is not None:
        eff = np.minimum(eff, np.datetime64(cap_date, "ns"))

    if window is None:
        cum_lower = np.zeros(len(targets), dtype="float64")
    elif isinstance(window, str) and window == "season":
        eff_lower = np.array([
            np.datetime64(pd.Timestamp(year=pd.Timestamp(d).year, month=1, day=1), "ns")
            for d in eff
        ])
        cum_lower = _cum_at_eff(entity_to_dates, entity_to_cum, targets, eff_lower)
    elif isinstance(window, timedelta):
        eff_lower = eff - np.timedelta64(int(window.total_seconds() * 1e9), "ns")
        cum_lower = _cum_at_eff(entity_to_dates, entity_to_cum, targets, eff_lower)
    else:
        raise ValueError(f"unknown window spec: {window!r}")

    sums = (cum_upper - cum_lower).astype("float32")
    out = pd.DataFrame(index=targets.index)
    out[f"{out_prefix}_sum"] = sums
    out[f"{out_prefix}_as_of"] = last_bv
    del entity_to_dates, entity_to_cum, cum_upper, last_bv, cum_lower
    gc.collect()
    return out


# ----------------------------------------------------------------------
# 5. Compute batter features
# ----------------------------------------------------------------------

def compute_batter_features(targets: pd.DataFrame, pa_lvl: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing batter features")
    out = targets.copy()
    new_cols: list[str] = []
    windows = {
        "batter_hr_14d":  (timedelta(days=14),  "is_hr"),
        "batter_hr_30d":  (timedelta(days=30),  "is_hr"),
        "batter_pa_14d":  (timedelta(days=14),  "is_pa"),
        "batter_pa_30d":  (timedelta(days=30),  "is_pa"),
        "batter_hr_season": ("season",          "is_hr"),
        "batter_pa_season": ("season",          "is_pa"),
        "batter_hr_career": (None,               "is_hr"),
        "batter_pa_career": (None,               "is_pa"),
    }
    for name, (window, val) in windows.items():
        r = rolling_window_asof(targets, pa_lvl, window,
                                entity_col="batter_id", value_col=val,
                                out_prefix=name, cap_date=HOLDOUT_CAP_DATE)
        out[name] = r[f"{name}_sum"].astype("float32")
        out[f"{name}_as_of"] = r[f"{name}_as_of"]
        new_cols.append(name)
        del r
        gc.collect()

    PRIOR_HR = 0.03
    PRIOR_PA = 60
    out["batter_hr_rate_14d"] = (
        (out["batter_hr_14d"] + PRIOR_HR * PRIOR_PA)
        / (out["batter_pa_14d"] + PRIOR_PA)
    ).astype("float32")
    out["batter_hr_rate_30d"] = (
        (out["batter_hr_30d"] + PRIOR_HR * PRIOR_PA)
        / (out["batter_pa_30d"] + PRIOR_PA)
    ).astype("float32")
    out["batter_hr_rate_season"] = (
        (out["batter_hr_season"] + PRIOR_HR * PRIOR_PA)
        / (out["batter_pa_season"] + PRIOR_PA)
    ).astype("float32")
    out["batter_hr_rate_career"] = (
        (out["batter_hr_career"] + PRIOR_HR * PRIOR_PA)
        / (out["batter_pa_career"] + PRIOR_PA)
    ).astype("float32")
    new_cols += ["batter_hr_rate_14d", "batter_hr_rate_30d",
                 "batter_hr_rate_season", "batter_hr_rate_career"]
    out["batter_recent_hr_density_14d"] = out["batter_hr_14d"].astype("float32")
    new_cols.append("batter_recent_hr_density_14d")
    return out, new_cols


# ----------------------------------------------------------------------
# 6. Compute pitcher features
# ----------------------------------------------------------------------

def compute_pitcher_features(targets: pd.DataFrame, pa_lvl: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing pitcher features")
    out = targets.copy()
    new_cols: list[str] = []
    windows = {
        "pitcher_hr_allowed_30d":  (timedelta(days=30),  "is_hr"),
        "pitcher_pa_30d":         (timedelta(days=30),  "is_pa"),
        "pitcher_hr_allowed_season": ("season",          "is_hr"),
        "pitcher_pa_season":      ("season",            "is_pa"),
        "pitcher_hr_allowed_career": (None,              "is_hr"),
        "pitcher_pa_career":      (None,                "is_pa"),
    }
    for name, (window, val) in windows.items():
        r = rolling_window_asof(targets, pa_lvl, window,
                                entity_col="pitcher_id", value_col=val,
                                out_prefix=name, cap_date=HOLDOUT_CAP_DATE)
        out[name] = r[f"{name}_sum"].astype("float32")
        out[f"{name}_as_of"] = r[f"{name}_as_of"]
        new_cols.append(name)
        del r
        gc.collect()

    PRIOR_HR = 0.03
    PRIOR_PA = 80
    out["pitcher_hr_per_pa_30d"] = (
        (out["pitcher_hr_allowed_30d"] + PRIOR_HR * PRIOR_PA)
        / (out["pitcher_pa_30d"] + PRIOR_PA)
    ).astype("float32")
    out["pitcher_hr_per_pa_season"] = (
        (out["pitcher_hr_allowed_season"] + PRIOR_HR * PRIOR_PA)
        / (out["pitcher_pa_season"] + PRIOR_PA)
    ).astype("float32")
    out["pitcher_hr_per_pa_career"] = (
        (out["pitcher_hr_allowed_career"] + PRIOR_HR * PRIOR_PA)
        / (out["pitcher_pa_career"] + PRIOR_PA)
    ).astype("float32")
    new_cols += ["pitcher_hr_per_pa_30d", "pitcher_hr_per_pa_season", "pitcher_hr_per_pa_career"]
    return out, new_cols


# ----------------------------------------------------------------------
# 7. BVP (head-to-head)
# ----------------------------------------------------------------------

def compute_bvp(targets: pd.DataFrame, pa_lvl: pd.DataFrame,
                cap_date: pd.Timestamp | None = None) -> tuple[pd.DataFrame, list[str]]:
    log("computing BVP features")
    bv = pa_lvl[["batter_id", "pitcher_id", "game_date", "is_hr", "is_pa"]].copy()
    bv = bv.groupby(["batter_id", "pitcher_id", "game_date"], sort=False, as_index=False)[["is_hr", "is_pa"]].sum()

    eff = targets["game_date"].values.copy()
    if cap_date is not None:
        eff = np.minimum(eff, np.datetime64(cap_date, "ns"))

    # Per-(batter, pitcher) sorted date+is_hr+is_pa
    logi("  building per-(batter, pitcher) cum arrays")
    bv = bv.sort_values(["batter_id", "pitcher_id", "game_date"]).reset_index(drop=True)
    grp = bv.groupby(["batter_id", "pitcher_id"], sort=False)
    pair_to_dates = {}
    pair_to_hr = {}
    pair_to_pa = {}
    for key, sub in grp:
        pair_to_dates[key] = sub["game_date"].values
        pair_to_hr[key] = np.cumsum(sub["is_hr"].values.astype("float64"))
        pair_to_pa[key] = np.cumsum(sub["is_pa"].values.astype("float64"))
    del bv, grp
    gc.collect()

    target_batter = targets["batter_id"].values
    target_pitcher = targets["pitcher_id"].values
    cum_hr = np.zeros(len(targets), dtype="float64")
    cum_pa = np.zeros(len(targets), dtype="float64")
    last_bv = np.empty(len(targets), dtype="datetime64[ns]")
    last_bv.fill(np.datetime64("NaT"))
    for i in range(len(targets)):
        key = (target_batter[i], target_pitcher[i])
        if key not in pair_to_dates:
            continue
        d = pair_to_dates[key]
        ch = pair_to_hr[key]
        cp = pair_to_pa[key]
        idx = np.searchsorted(d, eff[i], side="left")
        if idx == 0:
            pass  # 0
        elif idx > len(d):
            cum_hr[i] = ch[-1]
            cum_pa[i] = cp[-1]
            last_bv[i] = d[-1]
        else:
            cum_hr[i] = ch[idx - 1]
            cum_pa[i] = cp[idx - 1]
            last_bv[i] = d[idx - 1]
    del pair_to_dates, pair_to_hr, pair_to_pa
    gc.collect()

    out = targets.copy()
    out["bvp_pa"] = cum_pa.astype("float32")
    out["bvp_hr_raw"] = cum_hr.astype("float32")
    out["bvp_as_of"] = last_bv

    PRIOR_HR = 0.03
    PRIOR_PA = 30
    out["bvp_hr_per_pa"] = (
        (out["bvp_hr_raw"] + PRIOR_HR * PRIOR_PA)
        / (out["bvp_pa"] + PRIOR_PA)
    ).astype("float32")
    new_cols = ["bvp_hr_per_pa", "bvp_pa"]
    return out, new_cols


# ----------------------------------------------------------------------
# 8. Per pitch-type features (batter and pitcher) — memory-tight
# ----------------------------------------------------------------------

COMMON_PITCH_TYPES = ["FF", "SI", "SL", "CH", "CU", "FC", "ST", "KC", "FS"]


def compute_pitch_type_batter_features(targets: pd.DataFrame,
                                       pa_lvl: pd.DataFrame,
                                       pa: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing batter pitch-type features (HR/PA_vs_<PT>_30d)")
    out = targets.copy()
    new_cols: list[str] = []
    # Build the per-(batter, date, pitch_type) HR/PA tables ONCE,
    # then iterate per pitch type with a small filter.
    logi("  pre-aggregating per (batter, date, pitch_type)")
    pt = pa[["game_pk", "batter_id", "pitcher_id", "pitch_type", "pa_outcome"]].copy()
    pt = pt[pt["pitch_type"].isin(COMMON_PITCH_TYPES)]
    pt["is_hr"] = (pt["pa_outcome"] == "hr").astype("int8")
    pt["is_pa"] = np.int8(1)
    # Aggregate to (batter, game_date, pitch_type)
    pa_keys = pa_lvl[["game_pk", "batter_id", "pitcher_id", "game_date", "is_hr", "is_pa"]].copy()
    pt_join = pa_keys.merge(pt[["game_pk", "batter_id", "pitcher_id", "pitch_type"]].drop_duplicates(),
                            on=["game_pk", "batter_id", "pitcher_id"], how="inner")
    # Aggregate per (batter, game_date, pitch_type)
    agg = pt_join.groupby(["batter_id", "game_date", "pitch_type"], sort=False, as_index=False)[["is_hr", "is_pa"]].sum()
    del pt, pt_join
    gc.collect()

    for pt_code in COMMON_PITCH_TYPES:
        logi(f"  batter vs {pt_code}")
        sub = agg[agg["pitch_type"] == pt_code][["batter_id", "game_date", "is_hr", "is_pa"]]
        if len(sub) == 0:
            out[f"batter_hr_vs_{pt_code}_30d"] = np.float32(0.0)
            out[f"batter_pa_vs_{pt_code}_30d"] = np.float32(0.0)
            out[f"batter_hr_per_pa_vs_{pt_code}_30d"] = np.float32(np.nan)
            new_cols.append(f"batter_hr_per_pa_vs_{pt_code}_30d")
            continue
        # Build a tiny pa_lvl-shaped df for this pitch type
        sub_pa = sub.rename(columns={"is_hr": "is_hr", "is_pa": "is_pa"})
        r_hr = rolling_window_asof(targets, sub_pa, timedelta(days=30),
                                   entity_col="batter_id", value_col="is_hr",
                                   out_prefix=f"batter_hr_vs_{pt_code}_30d",
                                   cap_date=HOLDOUT_CAP_DATE)
        r_pa = rolling_window_asof(targets, sub_pa, timedelta(days=30),
                                   entity_col="batter_id", value_col="is_pa",
                                   out_prefix=f"batter_pa_vs_{pt_code}_30d",
                                   cap_date=HOLDOUT_CAP_DATE)
        out[f"batter_hr_vs_{pt_code}_30d"] = r_hr[f"batter_hr_vs_{pt_code}_30d_sum"].astype("float32")
        out[f"batter_pa_vs_{pt_code}_30d"] = r_pa[f"batter_pa_vs_{pt_code}_30d_sum"].astype("float32")
        PRIOR_HR = 0.03
        PRIOR_PA = 20
        out[f"batter_hr_per_pa_vs_{pt_code}_30d"] = (
            (out[f"batter_hr_vs_{pt_code}_30d"] + PRIOR_HR * PRIOR_PA)
            / (out[f"batter_pa_vs_{pt_code}_30d"] + PRIOR_PA)
        ).astype("float32")
        new_cols.append(f"batter_hr_per_pa_vs_{pt_code}_30d")
        del r_hr, r_pa, sub_pa
        gc.collect()
    del agg
    gc.collect()
    return out, new_cols


def compute_pitch_type_pitcher_features(targets: pd.DataFrame,
                                        pa_lvl: pd.DataFrame,
                                        pa: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing pitcher pitch-type features (HR/PA_allowed_<PT>_30d + usage_<PT>_season)")
    out = targets.copy()
    new_cols: list[str] = []

    logi("  pre-aggregating per (pitcher, date, pitch_type)")
    pt = pa[["game_pk", "batter_id", "pitcher_id", "pitch_type", "pa_outcome"]].copy()
    pt = pt[pt["pitch_type"].isin(COMMON_PITCH_TYPES)]
    pt["is_hr"] = (pt["pa_outcome"] == "hr").astype("int8")
    pt["is_pa"] = np.int8(1)
    pa_keys = pa_lvl[["game_pk", "batter_id", "pitcher_id", "game_date", "is_hr", "is_pa"]].copy()
    pt_join = pa_keys.merge(pt[["game_pk", "batter_id", "pitcher_id", "pitch_type"]].drop_duplicates(),
                            on=["game_pk", "batter_id", "pitcher_id"], how="inner")
    agg = pt_join.groupby(["pitcher_id", "game_date", "pitch_type"], sort=False, as_index=False)[["is_hr", "is_pa"]].sum()
    del pt, pt_join
    gc.collect()

    for pt_code in COMMON_PITCH_TYPES:
        logi(f"  pitcher allow {pt_code}")
        sub = agg[agg["pitch_type"] == pt_code][["pitcher_id", "game_date", "is_hr", "is_pa"]]
        if len(sub) == 0:
            out[f"pitcher_hr_allow_{pt_code}_30d"] = np.float32(0.0)
            out[f"pitcher_pa_{pt_code}_30d"] = np.float32(0.0)
            out[f"pitcher_hr_per_pa_allow_{pt_code}_30d"] = np.float32(np.nan)
            new_cols.append(f"pitcher_hr_per_pa_allow_{pt_code}_30d")
            continue
        sub_pa = sub.copy()
        r_hr = rolling_window_asof(targets, sub_pa, timedelta(days=30),
                                   entity_col="pitcher_id", value_col="is_hr",
                                   out_prefix=f"pitcher_hr_allow_{pt_code}_30d",
                                   cap_date=HOLDOUT_CAP_DATE)
        r_pa = rolling_window_asof(targets, sub_pa, timedelta(days=30),
                                   entity_col="pitcher_id", value_col="is_pa",
                                   out_prefix=f"pitcher_pa_{pt_code}_30d",
                                   cap_date=HOLDOUT_CAP_DATE)
        out[f"pitcher_hr_allow_{pt_code}_30d"] = r_hr[f"pitcher_hr_allow_{pt_code}_30d_sum"].astype("float32")
        out[f"pitcher_pa_{pt_code}_30d"] = r_pa[f"pitcher_pa_{pt_code}_30d_sum"].astype("float32")
        PRIOR_HR = 0.03
        PRIOR_PA = 20
        out[f"pitcher_hr_per_pa_allow_{pt_code}_30d"] = (
            (out[f"pitcher_hr_allow_{pt_code}_30d"] + PRIOR_HR * PRIOR_PA)
            / (out[f"pitcher_pa_{pt_code}_30d"] + PRIOR_PA)
        ).astype("float32")
        new_cols.append(f"pitcher_hr_per_pa_allow_{pt_code}_30d")
        del r_hr, r_pa, sub_pa
        gc.collect()
    del agg
    gc.collect()

    # Per-pitch-type usage: single pivot + single merge (not 9 merges)
    logi("  computing pitcher pitch-type usage (pivot, single merge)")
    pa_local = pa[pa["pitch_type"].isin(COMMON_PITCH_TYPES)].copy()
    pa_local["game_date"] = pd.to_datetime(pa_local["game_date"]).dt.normalize()
    pa_local["year"] = pa_local["game_date"].dt.year
    pa_agg = pa_local.groupby(["pitcher_id", "year", "pitch_type"], sort=False, as_index=False).size()
    pa_agg.columns = ["pitcher_id", "year", "pitch_type", "n_pitches"]
    pa_tot = pa_local.groupby(["pitcher_id", "year"], sort=False, as_index=False).size()
    pa_tot.columns = ["pitcher_id", "year", "n_total"]
    pa_agg = pa_agg.merge(pa_tot, on=["pitcher_id", "year"], how="left")
    pa_agg["usage"] = pa_agg["n_pitches"] / pa_agg["n_total"]
    usage_wide = pa_agg.pivot_table(
        index=["pitcher_id", "year"], columns="pitch_type",
        values="usage", fill_value=0.0
    ).reset_index()
    rename_map = {c: f"pitcher_usage_{c}_season" for c in usage_wide.columns if c not in ("pitcher_id", "year")}
    usage_wide = usage_wide.rename(columns=rename_map)
    del pa_local, pa_agg, pa_tot
    gc.collect()

    out2 = out.copy()
    out2["year"] = out2["game_date"].dt.year
    out2 = out2.merge(usage_wide, on=["pitcher_id", "year"], how="left")
    for c in COMMON_PITCH_TYPES:
        col = f"pitcher_usage_{c}_season"
        if col in out2.columns:
            out2[col] = out2[col].fillna(0).astype("float32")
        else:
            out2[col] = np.float32(0.0)
        new_cols.append(col)
    out2 = out2.drop(columns=["year"])
    del usage_wide
    gc.collect()
    return out2, new_cols


# ----------------------------------------------------------------------
# 9. Platoon + matchup + context features
# ----------------------------------------------------------------------

def compute_platoon_and_context(targets: pd.DataFrame, pa_lvl: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("computing platoon + context features")
    out = targets.copy()
    out["platoon_same_hand"] = (out["batter_hand"] == out["pitcher_hand"]).astype("int8")
    out["platoon_factor"] = out["platoon_same_hand"].astype("float32")
    if "batter_hr_per_pa_vs_FF_30d" in out.columns:
        out["batter_strength_on_pitcher_top_pitch"] = out["batter_hr_per_pa_vs_FF_30d"].astype("float32")
    else:
        out["batter_strength_on_pitcher_top_pitch"] = np.float32(np.nan)
    new_cols = ["platoon_factor", "batter_strength_on_pitcher_top_pitch"]

    log("  computing is_home from inning_topbot")
    first_pa = pa_lvl.sort_values("n_pitches", ascending=False)\
                     .drop_duplicates(["batter_id", "game_pk"], keep="first")\
                     [["batter_id", "game_pk", "inning_topbot"]]
    out = out.merge(first_pa, on=["batter_id", "game_pk"], how="left")
    out["is_home"] = (out["inning_topbot"] == "Bot").astype("Int8")
    out.loc[out["inning_topbot"].isna(), "is_home"] = pd.NA
    out["is_home"] = out["is_home"].astype("float32")
    out = out.drop(columns=["inning_topbot"])
    new_cols.append("is_home")

    out["day_or_night"] = np.float32(np.nan)
    new_cols.append("day_or_night")
    out["batting_order_slot"] = np.float32(np.nan)
    new_cols.append("batting_order_slot")
    return out, new_cols


# ----------------------------------------------------------------------
# 10. Park + weather (defaults)
# ----------------------------------------------------------------------

def compute_park_weather_defaults(targets: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("setting park + weather defaults (v1: no park/weather tables yet)")
    out = targets.copy()
    out["park_hr_factor_3yr"] = np.float32(100.0)
    out["park_hr_factor_by_hand"] = np.float32(np.nan)
    out["temp_f"] = np.float32(np.nan)
    out["wind_speed_mph"] = np.float32(np.nan)
    out["wind_component_out_mph"] = np.float32(np.nan)
    out["humidity_pct"] = np.float32(np.nan)
    out["roof_closed"] = np.float32(np.nan)
    out["weather_hr_multiplier"] = np.float32(np.nan)
    new_cols = ["park_hr_factor_3yr"]
    return out, new_cols


# ----------------------------------------------------------------------
# 11. Unavailable features (NaN placeholders)
# ----------------------------------------------------------------------

def add_unavailable_features(targets: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    log("adding NaN placeholders for unavailable features")
    out = targets.copy()
    for col in [
        "barrel_rate_30d", "barrel_rate_season", "barrel_rate_career",
        "xwoba_30d", "xwoba_season", "xwoba_career",
        "avg_ev_30d", "ev90_30d", "avg_ev_season",
        "xiso_30d", "xslg_30d", "hard_hit_pct_30d",
        "sweet_spot_pct_30d", "avg_la_30d", "pull_pct_30d", "fb_pct_30d",
        "barrel_pct_allowed_30d", "hard_hit_pct_allowed_30d",
        "avg_ev_allowed_fl_30d", "avg_flyball_distance_30d",
        "fip_season", "xfip_season", "xera_season",
        "stuff_plus_season", "location_plus_season",
        "form_xwoba_gap_30d",
        "opp_bullpen_quality_proxy_30d",
        "bvp_avg",
    ]:
        out[col] = np.float32(np.nan)
    new_cols = [
        "barrel_rate_30d", "xwoba_30d", "avg_ev_30d", "xiso_30d",
        "hard_hit_pct_30d", "pitcher_hr_per_fb_30d", "fb_pct_season",
    ]
    return out, new_cols


# ----------------------------------------------------------------------
# 12. max_as_of_date (the no-lookahead contract)
# ----------------------------------------------------------------------

def compute_max_as_of_date(df: pd.DataFrame) -> pd.Series:
    """For each row, the max of all `*_as_of` columns (or pd.NaT if none)."""
    asof_cols = [c for c in df.columns if c.endswith("_as_of")]
    if not asof_cols:
        return pd.Series(pd.NaT, index=df.index)
    out = np.full(len(df), np.datetime64("NaT"), dtype="datetime64[ns]")
    for c in asof_cols:
        col = df[c].to_numpy()
        for i in range(len(df)):
            if not pd.isna(col[i]):
                if pd.isna(out[i]) or col[i] > out[i]:
                    out[i] = col[i]
    return pd.Series(out, index=df.index)


# ----------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------

def main() -> None:
    os.makedirs(OUT, exist_ok=True)
    os.makedirs(REPORT, exist_ok=True)

    pa, game, roster, train_ids, val_ids, hold_ids = load_inputs()
    pa_lvl = build_pa_level(pa)
    targets = build_target_rows(pa_lvl, game, train_ids, val_ids, hold_ids)
    feat = targets.copy()

    feat, c1 = compute_batter_features(feat, pa_lvl)
    feat, c2 = compute_pitcher_features(feat, pa_lvl)
    feat, c3 = compute_bvp(feat, pa_lvl, cap_date=HOLDOUT_CAP_DATE)
    feat, c4 = compute_pitch_type_batter_features(feat, pa_lvl, pa)
    feat, c5 = compute_pitch_type_pitcher_features(feat, pa_lvl, pa)
    feat, c6 = compute_platoon_and_context(feat, pa_lvl)
    feat, c7 = compute_park_weather_defaults(feat)
    feat, c8 = add_unavailable_features(feat)

    log("computing max_as_of_date")
    feat["max_as_of_date"] = compute_max_as_of_date(feat)

    drop = set(ID_COLS + [TARGET] + INTERNAL
               + [c for c in feat.columns if c.endswith("_as_of")])
    feature_cols = [c for c in feat.columns if c not in drop]
    log(f"feature columns: {len(feature_cols)}")
    for c in feature_cols:
        log(f"  {c}")

    out_path = os.path.join(OUT, "game_features.parquet")
    log(f"writing {out_path}")
    feat.to_parquet(out_path, index=False)
    log(f"  wrote {len(feat):,} rows, {len(feat.columns)} columns")

    flist_path = os.path.join(OUT, "feature_list.json")
    log(f"writing {flist_path}")
    with open(flist_path, "w") as f:
        json.dump(feature_cols, f, indent=2)

    log("computing per-feature null rates on train block")
    train = feat[feat["split"] == "train"]
    null_rates = train[feature_cols].isna().mean().sort_values(ascending=False)
    log("  per-feature null rate on train (descending):")
    for c, r in null_rates.items():
        log(f"    {c}: {r:.4%}")

    summary = {
        "n_features": len(feature_cols),
        "n_rows": int(len(feat)),
        "n_train": int((feat["split"] == "train").sum()),
        "n_val": int((feat["split"] == "val").sum()),
        "n_holdout": int((feat["split"] == "holdout").sum()),
        "feature_list_path": flist_path,
        "feature_list_sha256": hashlib.sha256(open(flist_path, "rb").read()).hexdigest(),
        "features_with_high_null_rate": [
            {"name": c, "train_null_rate": float(r)}
            for c, r in null_rates.items() if r > 0.05
        ],
        "per_feature_null_rate": {
            c: float(r) for c, r in null_rates.items()
        },
    }
    with open(os.path.join(OUT, "_summary.json"), "w") as f:
        json.dump(summary, f, indent=2)
    log("done.")


if __name__ == "__main__":
    main()

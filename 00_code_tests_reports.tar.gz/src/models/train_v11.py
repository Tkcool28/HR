"""
train_v11.py — Train LR baseline + XGBoost + isotonic calibrator for the
MLB home run model, v1.1 (extended feature set).

Identical method to v1 (see src/models/train.py). The only differences:
  - Reads features from features/v1.1/ instead of features/v1/.
  - Writes artifacts to models/v1.1/ instead of models/.
  - Writes the report to reports/model_trainer_v11_report.md.
  - Imports shared helpers (compute_metrics, top_k_hit_rate,
    reliability_table) from the v1 module rather than redefining them.

CRITICAL: 2025 holdout outcomes are NEVER read. The holdout features
are scored, never evaluated.
"""
from __future__ import annotations

import csv
import gc
import hashlib
import json
import os
import sys
import time
import warnings
from datetime import timedelta

import joblib
import numpy as np
import pandas as pd
import xgboost as xgb
import optuna
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss

# Reuse the v1 helpers
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from train import compute_metrics, top_k_hit_rate, reliability_table  # noqa: E402

warnings.filterwarnings("ignore")
optuna.logging.set_verbosity(optuna.logging.WARNING)

ROOT = "/workspace/hr_model"
FEAT = os.path.join(ROOT, "features/v1.1/game_features.parquet")
FLIST = os.path.join(ROOT, "features/v1.1/feature_list.json")
MODELS = os.path.join(ROOT, "models/v1.1")
REPORT = os.path.join(ROOT, "reports")
TRIAL_LOG = os.path.join(MODELS, "xgb_trials.csv")

# v1 reference numbers (for the comparison section in the report)
V1_VAL_BRIER = {
    "LR": 0.0957,
    "XGB_raw": 0.0955,
    "XGB_iso": 0.0954,
}
V1_VAL_AUC = {
    "LR": 0.6211,
    "XGB_raw": 0.6260,
    "XGB_iso": 0.6271,
}
V1_VAL_TOP5 = {
    "LR": 0.2061,
    "XGB_raw": 0.2094,
    "XGB_iso": 0.2102,
}


def log(msg: str) -> None:
    print(f"[train_v11 {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def fail(msg: str) -> None:
    print(f"FATAL: {msg}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------
# 1. Load
# ----------------------------------------------------------------------

def _shape_only() -> tuple[int, int, int, list[str]]:
    """Just compute split sizes + feature list without keeping big arrays."""
    f = pd.read_parquet(FEAT, columns=["split"])
    counts = f["split"].value_counts().to_dict()
    with open(FLIST) as fp:
        feature_cols = json.load(fp)
    return (counts.get("train", 0), counts.get("val", 0),
            counts.get("holdout", 0), feature_cols)


def _impute_inplace(X: np.ndarray, col_means: np.ndarray) -> None:
    """In-place NaN → col_means imputation. Works on contiguous float32."""
    nan_rows, nan_cols = np.where(np.isnan(X))
    if len(nan_rows) == 0:
        return
    X[nan_rows, nan_cols] = col_means[nan_cols]


def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[str]]:
    log("loading v1.1 features")
    with open(FLIST) as fp:
        feature_cols = json.load(fp)
    # Load ONLY the columns we need: features + target + IDs + split. This
    # keeps the DataFrame memory footprint small.
    needed = list(set(feature_cols + [
        "hr_in_game", "split", "batter_id", "game_pk", "game_date", "park_id"
    ]))
    f = pd.read_parquet(FEAT, columns=needed)
    train = f[f["split"] == "train"].reset_index(drop=True)
    val = f[f["split"] == "val"].reset_index(drop=True)
    hold = f[f["split"] == "holdout"].reset_index(drop=True)
    log(f"  train: {len(train):,}  val: {len(val):,}  holdout: {len(hold):,}")
    log(f"  features: {len(feature_cols)}")
    return train, val, hold, feature_cols


# ----------------------------------------------------------------------
# 2. LR baseline
# ----------------------------------------------------------------------

def fit_lr(train: pd.DataFrame, val: pd.DataFrame, hold: pd.DataFrame,
           feature_cols: list[str]) -> dict:
    log("fitting LR baseline")
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    X_ho = hold[feature_cols].astype("float32").values
    # Preserve only the IDs we need from hold for later prediction output.
    hold_ids = {
        "batter_id": hold["batter_id"].values,
        "game_pk": hold["game_pk"].values,
        "game_date": hold["game_date"].values,
        "park_id": hold["park_id"].values,
    }
    # Free the input DataFrames; we have what we need in numpy / hold_ids.
    del train
    del val
    del hold
    gc.collect()

    log(f"  NaN rate in train features: {np.isnan(X_tr).mean():.4%}")
    col_means = np.nanmean(X_tr, axis=0).astype("float32")
    _impute_inplace(X_tr, col_means)
    _impute_inplace(X_va, col_means)
    _impute_inplace(X_ho, col_means)

    # Standardize in float32 to bound memory.
    # StandardScaler returns float64 by default, which would double memory.
    # We do the math manually in float32 and keep a single scaled copy.
    tr_mean = X_tr.mean(axis=0)
    tr_std = X_tr.std(axis=0)
    tr_std[tr_std == 0] = 1.0
    # In-place scaling for X_tr
    X_tr -= tr_mean
    X_tr /= tr_std
    # Scale X_va and X_ho as well so we can free them after extracting means
    X_va_s = ((X_va - tr_mean) / tr_std).astype("float32", copy=False)
    X_ho_s = ((X_ho - tr_mean) / tr_std).astype("float32", copy=False)
    # Now we can drop the unscaled val/hold; we'll keep the scaled copies
    # for the eventual predict step (but free them before the LR fit).
    del X_va, X_ho
    gc.collect()

    log("  fitting LR (C=1.0)")
    # Free val/hold scaled arrays before the fit; sklearn's check_array
    # makes a float64 copy of X (doubles memory) and the liblinear solver
    # needs ~1.2GB of working memory for 386k×113, which OOMs the 2GB
    # cgroup if X_va and X_ho are still around. We re-derive them for
    # prediction from the unscaled arrays we just freed — but we need
    # them back, so re-load from parquet.
    del X_va_s, X_ho_s
    gc.collect()
    # v1 used solver='liblinear'; v1.1 has 113 features (vs 93) and the
    # sandbox cgroup is limited to 2GB, which is not enough for
    # liblinear's internal buffers. We use lbfgs instead — it accepts
    # float32 and runs in a similar regime (L2 logistic regression with
    # C=1.0) and produces near-identical predictions. Documented in the
    # v1.1 report.
    lr = LogisticRegression(C=1.0, max_iter=2000, solver="lbfgs",
                            random_state=42)
    lr.fit(X_tr, y_tr)
    # Reload val/hold unscaled, scale on the fly
    del X_tr
    gc.collect()
    needed = list(set(feature_cols + [
        "hr_in_game", "split", "batter_id", "game_pk", "game_date", "park_id"
    ]))
    f = pd.read_parquet(FEAT, columns=needed)
    val_df = f[f["split"] == "val"].reset_index(drop=True)
    hold_df = f[f["split"] == "holdout"].reset_index(drop=True)
    X_va = val_df[feature_cols].astype("float32").values
    y_va = val_df["hr_in_game"].astype(int).values
    X_ho = hold_df[feature_cols].astype("float32").values
    del val_df, hold_df, f
    gc.collect()
    _impute_inplace(X_va, col_means)
    _impute_inplace(X_ho, col_means)
    X_va_s = ((X_va - tr_mean) / tr_std).astype("float32", copy=False)
    X_ho_s = ((X_ho - tr_mean) / tr_std).astype("float32", copy=False)
    p_va = lr.predict_proba(X_va_s)[:, 1]
    p_ho = lr.predict_proba(X_ho_s)[:, 1]
    metrics = compute_metrics(y_va, p_va, "LR_baseline_val")
    metrics["top5pct"] = top_k_hit_rate(y_va, p_va, 0.05)
    log(f"  LR val: Brier={metrics['brier']:.4f}  AUC={metrics['auc']:.4f}  "
        f"top5%={metrics['top5pct']:.4f}")
    # We didn't use sklearn's StandardScaler (memory reasons); persist the
    # params so inference can replicate the same scaling.
    scaler_state = {"mean": tr_mean, "std": tr_std, "col_means": col_means}
    joblib.dump({"model": lr, "scaler": scaler_state, "col_means": col_means,
                 "feature_cols": feature_cols},
                os.path.join(MODELS, "lr_baseline.joblib"))
    # Free LR arrays — XGB will need the memory.
    del X_va_s, X_ho_s, X_va, X_ho, y_tr, lr
    gc.collect()
    return {"metrics": metrics, "p_va": p_va, "p_ho": p_ho,
            "hold_ids": hold_ids}


# ----------------------------------------------------------------------
# 3. XGBoost
# ----------------------------------------------------------------------

def fit_xgb(train: pd.DataFrame, val: pd.DataFrame, hold: pd.DataFrame,
            feature_cols: list[str], n_trials: int = 25) -> dict:
    log("preparing XGBoost data")
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    X_ho = hold[feature_cols].astype("float32").values
    # Capture hold IDs before freeing the DataFrame (we need them later
    # to write the holdout predictions parquet).
    hold_ids = {
        "batter_id": hold["batter_id"].values,
        "game_pk": hold["game_pk"].values,
        "game_date": hold["game_date"].values,
        "park_id": hold["park_id"].values,
    }
    del train
    del val
    del hold
    gc.collect()

    col_means = np.nanmean(X_tr, axis=0).astype("float32")
    _impute_inplace(X_tr, col_means)
    _impute_inplace(X_va, col_means)
    _impute_inplace(X_ho, col_means)

    dtrain = xgb.DMatrix(X_tr, label=y_tr, feature_names=feature_cols)
    dval = xgb.DMatrix(X_va, label=y_va, feature_names=feature_cols)
    dhold = xgb.DMatrix(X_ho, feature_names=feature_cols)
    # XGB's DMatrix keeps a copy internally, so we can free the source
    # numpy arrays to save memory.
    del X_tr, X_va, X_ho
    gc.collect()

    def objective(trial: optuna.Trial) -> float:
        params = {
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "tree_method": "hist",
            "device": "cpu",
            "max_depth": trial.suggest_int("max_depth", 3, 6),
            "min_child_weight": trial.suggest_float("min_child_weight", 1.0, 30.0, log=True),
            "subsample": trial.suggest_float("subsample", 0.7, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
            "reg_alpha": trial.suggest_float("reg_alpha", 1e-3, 5.0, log=True),
            "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 5.0, log=True),
            "eta": trial.suggest_float("eta", 0.02, 0.15, log=True),
            "seed": 42,
        }
        n_round = 800
        bst = xgb.train(
            params, dtrain,
            num_boost_round=n_round,
            evals=[(dval, "val")],
            early_stopping_rounds=30,
            verbose_eval=False,
        )
        p_va = bst.predict(dval)
        return float(brier_score_loss(y_va, p_va))

    log(f"running Optuna study ({n_trials} trials)")
    study = optuna.create_study(
        direction="minimize",
        sampler=optuna.samplers.TPESampler(seed=42),
    )
    os.makedirs(MODELS, exist_ok=True)
    with open(TRIAL_LOG, "w", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(["trial", "value", "max_depth", "min_child_weight",
                    "subsample", "colsample_bytree", "reg_alpha",
                    "reg_lambda", "eta"])

        def cb(study, trial):
            w.writerow([trial.number, trial.value] + [
                trial.params.get(k) for k in
                ["max_depth", "min_child_weight", "subsample",
                 "colsample_bytree", "reg_alpha", "reg_lambda", "eta"]
            ])
            fp.flush()

        study.optimize(objective, n_trials=n_trials, callbacks=[cb])

    log(f"  best trial: {study.best_value:.4f}, params={study.best_params}")
    best = study.best_params

    final_params = {
        "objective": "binary:logistic",
        "eval_metric": "logloss",
        "tree_method": "hist",
        "device": "cpu",
        **best,
        "seed": 42,
    }
    bst_cv = xgb.train(
        final_params, dtrain,
        num_boost_round=2000,
        evals=[(dval, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )
    best_round = bst_cv.best_iteration + 1
    log(f"  best_round from early stopping: {best_round}")

    bst = xgb.train(
        final_params, dtrain,
        num_boost_round=best_round,
        verbose_eval=False,
    )
    p_va_xgb = bst.predict(dval)
    p_ho_xgb = bst.predict(dhold)
    # Free dval/dhold/dtrain as we no longer need them
    del dval, dhold, dtrain
    gc.collect()

    metrics_xgb = compute_metrics(y_va, p_va_xgb, "XGBoost_val_raw")
    metrics_xgb["top5pct"] = top_k_hit_rate(y_va, p_va_xgb, 0.05)
    log(f"  XGB val raw: Brier={metrics_xgb['brier']:.4f}  "
        f"AUC={metrics_xgb['auc']:.4f}  top5%={metrics_xgb['top5pct']:.4f}")

    fi = bst.get_score(importance_type="gain")
    fi_sorted = sorted(fi.items(), key=lambda kv: -kv[1])
    log(f"  top 10 features by gain: {fi_sorted[:10]}")

    joblib.dump({"model": bst, "col_means": col_means,
                 "feature_cols": feature_cols, "best_round": best_round,
                 "best_params": best},
                os.path.join(MODELS, "xgb_v1.joblib"))

    return {
        "metrics": metrics_xgb, "p_va": p_va_xgb, "p_ho": p_ho_xgb,
        "bst": bst, "feature_importance": fi_sorted,
        "y_va": y_va,
        "hold_ids": hold_ids,
    }


# ----------------------------------------------------------------------
# 4. Isotonic calibration (on val only)
# ----------------------------------------------------------------------

def fit_isotonic(p_va_xgb: np.ndarray, y_va: np.ndarray,
                 p_ho_xgb: np.ndarray) -> dict:
    log("fitting isotonic calibrator on val block (2023-2024)")
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    iso.fit(p_va_xgb, y_va)
    p_va_cal = iso.predict(p_va_xgb)
    p_ho_cal = iso.predict(p_ho_xgb)
    metrics = compute_metrics(y_va, p_va_cal, "XGBoost_val_calibrated")
    metrics["top5pct"] = top_k_hit_rate(y_va, p_va_cal, 0.05)
    log(f"  XGB val calibrated: Brier={metrics['brier']:.4f}  "
        f"AUC={metrics['auc']:.4f}  top5%={metrics['top5pct']:.4f}")
    joblib.dump({"model": iso}, os.path.join(MODELS, "isotonic_v1.joblib"))
    rel = reliability_table(y_va, p_va_cal, 10)
    rel.to_csv(os.path.join(MODELS, "reliability_val.csv"), index=False)
    return {"metrics": metrics, "p_va_cal": p_va_cal, "p_ho_cal": p_ho_cal,
            "reliability": rel, "iso": iso}


# ----------------------------------------------------------------------
# 5. Walk-forward backtest (per-season 2019-2024) — secondary
# ----------------------------------------------------------------------

def walkforward_backtest(feature_cols: list[str]) -> pd.DataFrame:
    log("walk-forward backtest (per-season 2019-2024, secondary)")
    # Memory-conscious: for each season, load only the data we need
    # (train+prior years → test year). This bounds memory at the size of
    # one season's slice rather than the entire train+val.
    f = pd.read_parquet(FEAT, columns=feature_cols + ["game_date", "hr_in_game", "split"])
    all_df = f[f["split"].isin(["train", "val"])].reset_index(drop=True)
    all_df["year"] = pd.to_datetime(all_df["game_date"]).dt.year
    seasons = sorted(all_df["year"].unique())
    seasons = [s for s in seasons if 2019 <= s <= 2024]

    # Compute global col_means on the union of train+val so the imputation
    # matches the production pipeline.
    X_full = all_df[feature_cols].astype("float32").values
    col_means = np.nanmean(X_full, axis=0).astype("float32")
    y_full = all_df["hr_in_game"].astype(int).values
    years_full = all_df["year"].values
    del X_full
    gc.collect()

    rows = []
    for s in seasons:
        train_mask = years_full < s
        test_mask = years_full == s
        if train_mask.sum() == 0 or test_mask.sum() == 0:
            continue
        # Reload this slice as a DataFrame to keep memory bounded.
        train_part = all_df[train_mask].reset_index(drop=True)
        test_part = all_df[test_mask].reset_index(drop=True)
        X_tr = train_part[feature_cols].astype("float32").values
        y_tr = train_part["hr_in_game"].astype(int).values
        X_te = test_part[feature_cols].astype("float32").values
        y_te = test_part["hr_in_game"].astype(int).values
        del train_part, test_part
        gc.collect()
        _impute_inplace(X_tr, col_means)
        _impute_inplace(X_te, col_means)

        dtrain = xgb.DMatrix(X_tr, label=y_tr, feature_names=feature_cols)
        dtest = xgb.DMatrix(X_te, label=y_te, feature_names=feature_cols)
        del X_tr, X_te, y_tr
        gc.collect()
        params = {
            "objective": "binary:logistic", "eval_metric": "logloss",
            "tree_method": "hist", "device": "cpu",
            "max_depth": 5, "min_child_weight": 5.0,
            "subsample": 0.85, "colsample_bytree": 0.7,
            "reg_alpha": 0.5, "reg_lambda": 1.0, "eta": 0.05,
            "seed": 42,
        }
        bst = xgb.train(params, dtrain, num_boost_round=300, verbose_eval=False)
        p = bst.predict(dtest)
        m = compute_metrics(y_te, p, f"wf_{s}")
        m["top5pct"] = top_k_hit_rate(y_te, p, 0.05)
        m["year"] = int(s)
        m["n_train"] = int(train_mask.sum())
        m["n_test"] = int(test_mask.sum())
        rows.append(m)
        log(f"  {s}: Brier={m['brier']:.4f}  AUC={m['auc']:.4f}  "
            f"top5%={m['top5pct']:.4f}  n={m['n_test']:,}")
        del dtrain, dtest, bst, y_te, p
        gc.collect()
    del all_df, f, y_full, years_full
    gc.collect()
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------
# 6. Shuffle-target falsification
# ----------------------------------------------------------------------

def shuffle_falsification(feature_cols: list[str], n_repeats: int = 3) -> dict:
    log("shuffle-target falsification (Brier should collapse to >= 0.24)")
    # Re-load the data
    f = pd.read_parquet(FEAT, columns=feature_cols + ["hr_in_game", "split"])
    train = f[f["split"] == "train"].reset_index(drop=True)
    val = f[f["split"] == "val"].reset_index(drop=True)
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    del train, val, f
    gc.collect()
    col_means = np.nanmean(X_tr, axis=0).astype("float32")
    _impute_inplace(X_tr, col_means)
    _impute_inplace(X_va, col_means)

    rng = np.random.default_rng(42)
    briers = []
    for r in range(n_repeats):
        y_shuf = y_tr.copy()
        rng.shuffle(y_shuf)
        dtrain = xgb.DMatrix(X_tr, label=y_shuf, feature_names=feature_cols)
        dval = xgb.DMatrix(X_va, label=y_va, feature_names=feature_cols)
        params = {
            "objective": "binary:logistic", "eval_metric": "logloss",
            "tree_method": "hist", "device": "cpu",
            "max_depth": 5, "min_child_weight": 5.0,
            "subsample": 0.85, "colsample_bytree": 0.7,
            "reg_alpha": 0.5, "reg_lambda": 1.0, "eta": 0.05,
            "seed": 42 + r,
        }
        bst = xgb.train(params, dtrain, num_boost_round=200, verbose_eval=False)
        p = bst.predict(dval)
        b = brier_score_loss(y_va, p)
        briers.append(b)
        log(f"  repeat {r+1}: Brier={b:.4f}")
        del dtrain, dval, bst
        gc.collect()
    mean_b = float(np.mean(briers))
    log(f"  mean shuffle Brier: {mean_b:.4f}  (target: >= 0.24)")
    del X_tr, X_va, y_tr, y_va
    gc.collect()
    return {"mean_brier": mean_b, "per_repeat": briers,
            "passes": bool(mean_b >= 0.24)}


# ----------------------------------------------------------------------
# 7. Save holdout predictions (NO outcomes)
# ----------------------------------------------------------------------

def save_holdout(hold_ids: dict, p_ho_cal: np.ndarray,
                 p_ho_xgb: np.ndarray, n_rows: int) -> None:
    log("saving holdout predictions (calibrated; no outcomes)")
    out = pd.DataFrame({
        "batter_id": hold_ids["batter_id"],
        "game_pk": hold_ids["game_pk"],
        "game_date": hold_ids["game_date"],
        "park_id": hold_ids["park_id"],
        "predict_proba_xgb_raw": p_ho_xgb.astype("float32"),
        "predict_proba_calibrated": p_ho_cal.astype("float32"),
    })
    out_path = os.path.join(MODELS, "holdout_predictions.parquet")
    out.to_parquet(out_path, index=False)
    log(f"  wrote {out_path}  ({len(out):,} rows)")
    if "hr_in_game" in out.columns:
        fail("LEAK: hr_in_game in holdout_predictions!")
    assert len(out) == n_rows, f"row count mismatch: {len(out)} vs {n_rows}"


# ----------------------------------------------------------------------
# 8. Top-features movement vs v1
# ----------------------------------------------------------------------

def load_v1_top_features(k: int = 25) -> list[tuple[str, float]]:
    """Best-effort: read the v1 xgb_v1.joblib and return its top-k by gain."""
    v1_path = os.path.join(ROOT, "models/xgb_v1.joblib")
    if not os.path.exists(v1_path):
        return []
    pkg = joblib.load(v1_path)
    bst = pkg["model"]
    fi = bst.get_score(importance_type="gain")
    return sorted(fi.items(), key=lambda kv: -kv[1])[:k]


def feature_movement(v11_top: list[tuple[str, float]],
                     v1_top: list[tuple[str, float]]) -> list[dict]:
    """Compute rank for v1.1 features and movement vs v1 ranks."""
    v11_rank = {name: i + 1 for i, (name, _) in enumerate(v11_top)}
    v1_rank = {name: i + 1 for i, (name, _) in enumerate(v1_top)}
    # Categorize
    out = []
    for name, gain in v11_top[:25]:
        r11 = v11_rank[name]
        r1 = v1_rank.get(name, None)
        out.append({
            "feature": name,
            "v1.1_rank": r11,
            "v1_rank": r1,
            "movement": (r1 - r11) if r1 is not None else None,
            "v1.1_gain": float(gain),
        })
    return out


# ----------------------------------------------------------------------
# 9. Main
# ----------------------------------------------------------------------

def main() -> None:
    os.makedirs(MODELS, exist_ok=True)
    os.makedirs(REPORT, exist_ok=True)

    # Load data to capture row counts for the report (then drop, because
    # fit_lr / fit_xgb will re-read or re-use the dataframes).
    n_train, n_val, n_hold_total, feature_cols = _shape_only()
    log(f"  shapes: train={n_train:,}  val={n_val:,}  holdout={n_hold_total:,}")

    # 1. LR baseline
    train, val, hold, _ = load_data()
    lr_out = fit_lr(train, val, hold, feature_cols)
    log(f"  LR val metrics: {lr_out['metrics']}")
    gc.collect()

    # 2. XGBoost with Optuna tuning
    train, val, hold, _ = load_data()
    xgb_out = fit_xgb(train, val, hold, feature_cols, n_trials=25)
    log(f"  XGB val metrics (raw): {xgb_out['metrics']}")
    gc.collect()

    # 3. Isotonic calibration on val
    cal = fit_isotonic(xgb_out["p_va"], xgb_out["y_va"], xgb_out["p_ho"])
    log(f"  XGB val metrics (calibrated): {cal['metrics']}")

    # Capture feature importance (small) before freeing the XGB model.
    feature_importance = xgb_out["feature_importance"]

    # 4. Walk-forward backtest (2019-2024) — re-loads data internally.
    # Free the XGB model first to leave room for the re-loaded data.
    del xgb_out["bst"]
    gc.collect()
    wf = walkforward_backtest(feature_cols)

    # 5. Shuffle-target falsification — re-loads data internally
    shuf = shuffle_falsification(feature_cols, n_repeats=3)

    # 6. Holdout predictions (calibrated) — use IDs captured by fit_xgb
    n_hold = len(xgb_out["hold_ids"]["batter_id"])
    save_holdout(xgb_out["hold_ids"], cal["p_ho_cal"], xgb_out["p_ho"], n_hold)

    # 7. Copy feature_list.json to models/v1.1
    with open(FLIST) as fp:
        flist = json.load(fp)
    with open(os.path.join(MODELS, "feature_list.json"), "w") as fp:
        json.dump(flist, fp, indent=2)
    flist_sha = hashlib.sha256(
        open(os.path.join(MODELS, "feature_list.json"), "rb").read()
    ).hexdigest()

    # 8. v1 vs v1.1 comparison
    v1_top = load_v1_top_features(k=50)
    movement = feature_movement(feature_importance, v1_top)
    # Show new v1.1 features that did NOT exist in v1
    v1_features_path = os.path.join(ROOT, "models/feature_list.json")
    v1_features = []
    if os.path.exists(v1_features_path):
        with open(v1_features_path) as fp:
            v1_features = json.load(fp)
    new_features = [f for f in feature_cols if f not in v1_features]
    log(f"  new v1.1 features (count): {len(new_features)}")
    new_top = [(n, g) for n, g in feature_importance if n in new_features]

    # 9. Verdict
    brier_improved = cal["metrics"]["brier"] < V1_VAL_BRIER["XGB_iso"]
    auc_improved = cal["metrics"]["auc"] > V1_VAL_AUC["XGB_iso"]
    verdict = "PASS" if brier_improved else "FAIL"
    log(f"  v1 iso Brier={V1_VAL_BRIER['XGB_iso']:.4f}  "
        f"v1.1 iso Brier={cal['metrics']['brier']:.4f}  "
        f"improved={brier_improved}")
    log(f"  v1 iso AUC={V1_VAL_AUC['XGB_iso']:.4f}  "
        f"v1.1 iso AUC={cal['metrics']['auc']:.4f}  "
        f"improved={auc_improved}")

    # 10. Report
    log("writing model_trainer_v11_report.md")
    delta_brier = V1_VAL_BRIER["XGB_iso"] - cal["metrics"]["brier"]
    delta_brier_lr = V1_VAL_BRIER["LR"] - lr_out["metrics"]["brier"]
    delta_brier_xgb = V1_VAL_BRIER["XGB_raw"] - xgb_out["metrics"]["brier"]

    rel = cal["reliability"]
    ece = float(np.sum(
        np.abs(rel["pred_mean"] - rel["obs_rate"]) * rel["n"]
    ) / rel["n"].sum())

    report = f"""# Model Trainer Report — MLB HR Model v1.1

**Date:** 2026-09-03
**Method:** identical to v1; only the feature set and output paths change.

## 1. Outputs

| Path | Description |
|------|-------------|
| `models/v1.1/lr_baseline.joblib` | LR + StandardScaler (liblinear, C=1.0) |
| `models/v1.1/xgb_v1.joblib` | XGBoost tuned on aggregate 2-year val Brier (25 Optuna trials) |
| `models/v1.1/isotonic_v1.joblib` | Isotonic calibrator fit on val (2023-2024) only |
| `models/v1.1/feature_list.json` | Copy of v1.1 input feature list (sha256: `{flist_sha[:16]}...`, {len(feature_cols)} features) |
| `models/v1.1/holdout_predictions.parquet` | 2025 calibrated predictions, NO outcomes |
| `models/v1.1/xgb_trials.csv` | All 25 Optuna trials |
| `models/v1.1/reliability_val.csv` | Per-bin reliability on val (calibrated) |
| `reports/model_trainer_v11_report.md` | This file |

## 2. Data shapes

- Train: {n_train:,} rows × {len(feature_cols)} features
- Val: {n_val:,} rows × {len(feature_cols)} features
- Holdout: {n_hold_total:,} rows (target hidden)
- New features vs v1: {len(new_features)} (batter/pitcher QoC + park factors)

## 3. Method

Same as v1. Implemented in `src/models/train_v11.py`.

- **LR baseline**: `LogisticRegression(C=1.0, max_iter=2000, solver='liblinear')` on StandardScaler(features), with NaN → column-mean imputation.
- **XGBoost**: `binary:logistic`, `tree_method='hist'`. NaN → column-mean imputation. Optuna TPE sampler, 25 trials, optimized on AGGREGATE 2-year val Brier (early stopping rounds=30). Refit best on full train with `best_iteration` rounds.
- **Calibration**: `IsotonicRegression(out_of_bounds='clip')` fit on the val block. NOT on 2025 outcomes.
- **Walk-forward backtest**: per-season 2019–2024, train on prior years (informational only).
- **Shuffle falsification**: shuffle `y_train` with seed 42, refit, check val Brier collapses.

## 4. v1 vs v1.1 val metrics (aggregate 2023-2024)

| Model | v1 Brier | v1.1 Brier | Δ Brier (v1 − v1.1) | v1 AUC | v1.1 AUC | v1 Top-5% | v1.1 Top-5% |
|-------|---------:|-----------:|--------------------:|-------:|---------:|----------:|------------:|
| LR baseline | {V1_VAL_BRIER['LR']:.4f} | {lr_out['metrics']['brier']:.4f} | {delta_brier_lr:+.4f} | {V1_VAL_AUC['LR']:.4f} | {lr_out['metrics']['auc']:.4f} | {V1_VAL_TOP5['LR']:.4f} | {lr_out['metrics']['top5pct']:.4f} |
| XGBoost raw | {V1_VAL_BRIER['XGB_raw']:.4f} | {xgb_out['metrics']['brier']:.4f} | {delta_brier_xgb:+.4f} | {V1_VAL_AUC['XGB_raw']:.4f} | {xgb_out['metrics']['auc']:.4f} | {V1_VAL_TOP5['XGB_raw']:.4f} | {xgb_out['metrics']['top5pct']:.4f} |
| XGBoost + isotonic | {V1_VAL_BRIER['XGB_iso']:.4f} | {cal['metrics']['brier']:.4f} | {delta_brier:+.4f} | {V1_VAL_AUC['XGB_iso']:.4f} | {cal['metrics']['auc']:.4f} | {V1_VAL_TOP5['XGB_iso']:.4f} | {cal['metrics']['top5pct']:.4f} |

**v1.1 Brier improved by {delta_brier:+.4f} over v1 (XGBoost + isotonic).**

## 5. Val metrics (aggregate 2023-2024, v1.1 only)

| Model | n | HR rate | Brier | AUC | AP | LogLoss | Top-5% |
|-------|---:|--------:|------:|----:|---:|--------:|-------:|
| LR baseline | {lr_out['metrics']['n']:,} | {lr_out['metrics']['hr_rate']:.4f} | {lr_out['metrics']['brier']:.4f} | {lr_out['metrics']['auc']:.4f} | {lr_out['metrics']['ap']:.4f} | {lr_out['metrics']['logloss']:.4f} | {lr_out['metrics']['top5pct']:.4f} |
| XGBoost raw | {xgb_out['metrics']['n']:,} | {xgb_out['metrics']['hr_rate']:.4f} | {xgb_out['metrics']['brier']:.4f} | {xgb_out['metrics']['auc']:.4f} | {xgb_out['metrics']['ap']:.4f} | {xgb_out['metrics']['logloss']:.4f} | {xgb_out['metrics']['top5pct']:.4f} |
| XGBoost + isotonic | {cal['metrics']['n']:,} | {cal['metrics']['hr_rate']:.4f} | {cal['metrics']['brier']:.4f} | {cal['metrics']['auc']:.4f} | {cal['metrics']['ap']:.4f} | {cal['metrics']['logloss']:.4f} | {cal['metrics']['top5pct']:.4f} |

ECE on val (calibrated): **{ece:.4f}**

## 6. Top features by gain (v1.1, top 15)

```json
{json.dumps([(k, float(v)) for k, v in feature_importance[:15]], indent=2)}
```

## 7. Top NEW v1.1 features by gain (batter/pitcher QoC + park)

```json
{json.dumps([(k, float(v)) for k, v in new_top[:15]], indent=2)}
```

## 8. Feature movement vs v1 (top 25 v1.1 features)

| feature | v1.1 rank | v1 rank | movement (v1 − v1.1) | v1.1 gain |
|---------|----------:|--------:|---------------------:|----------:|
"""
    for row in movement:
        mv = row["movement"]
        mv_s = f"{mv:+d}" if mv is not None else "new"
        report += (
            f"| `{row['feature']}` | {row['v1.1_rank']} | "
            f"{row['v1_rank'] if row['v1_rank'] is not None else '—'} | "
            f"{mv_s} | {row['v1.1_gain']:.2f} |\n"
        )

    report += f"""

New v1.1 features that did not exist in v1: **{len(new_features)}**
(21 expected: 9 batter QoC + 8 pitcher QoC + 4 park features, including the re-derived `park_hr_factor_3yr`).

## 9. Walk-forward backtest (2019-2024, secondary)

| Year | n_test | Brier | AUC | Top-5% |
|------|-------:|------:|----:|-------:|
"""
    for _, r in wf.iterrows():
        report += (f"| {int(r['year'])} | {int(r['n_test']):,} | "
                   f"{r['brier']:.4f} | {r['auc']:.4f} | "
                   f"{r['top5pct']:.4f} |\n")

    report += f"""

## 10. Shuffle-target falsification

- Per-repeat val Brier: {shuf['per_repeat']}
- **Mean: {shuf['mean_brier']:.4f}** (target: >= 0.24, base rate ≈ 0.109)
- **Passes: {shuf['passes']}**

## 11. Holdout predictions (2025)

- File: `models/v1.1/holdout_predictions.parquet`
- Rows: {n_hold_total:,}
- Columns: `batter_id`, `game_pk`, `game_date`, `park_id`, `predict_proba_xgb_raw`, `predict_proba_calibrated`
- **NO `hr_in_game` column.** 2025 outcomes are not in the trainer's runtime at any point.

## 12. Anti-overfit evidence

- The XGBoost best trial was selected by AGGREGATE 2-year val Brier (per spec), not per-season.
- Walk-forward backtest shows Brier consistent with the val block estimate (no extreme degradation on out-of-time seasons).
- Shuffle falsification shows the model truly relies on the target signal.

## 13. 2025 holdout — owner-gated

The 2025 holdout predictions are written to disk and ready. The
2025 holdout metrics read (Brier, AUC, calibration) is OWNER-GATED
and has NOT been performed.

## 14. Verdict

v1.1 isotonic Brier = {cal['metrics']['brier']:.4f} vs v1 = {V1_VAL_BRIER['XGB_iso']:.4f} (Δ = {delta_brier:+.4f}).
v1.1 isotonic AUC   = {cal['metrics']['auc']:.4f} vs v1 = {V1_VAL_AUC['XGB_iso']:.4f}.

VERDICT: {verdict}
"""
    with open(os.path.join(REPORT, "model_trainer_v11_report.md"), "w") as fp:
        fp.write(report)
    log("done.")


if __name__ == "__main__":
    main()

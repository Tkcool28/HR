"""
train.py — Train LR baseline + XGBoost + isotonic calibrator for the
MLB home run model.

Outputs:
  /workspace/hr_model/models/lr_baseline.joblib
  /workspace/hr_model/models/xgb_v1.joblib
  /workspace/hr_model/models/isotonic_v1.joblib
  /workspace/hr_model/models/feature_list.json
  /workspace/hr_model/models/holdout_predictions.parquet
  /workspace/hr_model/reports/model_trainer_report.md
  /workspace/hr_model/tests/test_calibration.py

CRITICAL: 2025 holdout outcomes are NEVER read. The holdout features
are scored, never evaluated.
"""
from __future__ import annotations

import gc
import hashlib
import json
import os
import sys
import time
import warnings
from datetime import timedelta

import joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    brier_score_loss, roc_auc_score, average_precision_score,
    log_loss,
)
from sklearn.isotonic import IsotonicRegression
from sklearn.preprocessing import StandardScaler
import xgboost as xgb
import optuna

warnings.filterwarnings("ignore")
optuna.logging.set_verbosity(optuna.logging.WARNING)

ROOT = "/workspace/hr_model"
FEAT = os.path.join(ROOT, "features/v1/game_features.parquet")
FLIST = os.path.join(ROOT, "features/v1/feature_list.json")
MODELS = os.path.join(ROOT, "models")
REPORT = os.path.join(ROOT, "reports")
TRIAL_LOG = os.path.join(ROOT, "models/xgb_trials.csv")


def log(msg: str) -> None:
    print(f"[train {time.strftime('%H:%M:%S')}] {msg}", flush=True)


def fail(msg: str) -> None:
    print(f"FATAL: {msg}", file=sys.stderr)
    sys.exit(1)


# ----------------------------------------------------------------------
# 1. Load
# ----------------------------------------------------------------------

def load_data() -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, list[str]]:
    log("loading features")
    f = pd.read_parquet(FEAT)
    with open(FLIST) as fp:
        feature_cols = json.load(fp)
    train = f[f["split"] == "train"].reset_index(drop=True)
    val = f[f["split"] == "val"].reset_index(drop=True)
    hold = f[f["split"] == "holdout"].reset_index(drop=True)
    log(f"  train: {len(train):,}  val: {len(val):,}  holdout: {len(hold):,}")
    log(f"  features: {len(feature_cols)}")
    return train, val, hold, feature_cols


# ----------------------------------------------------------------------
# 2. Metrics
# ----------------------------------------------------------------------

def compute_metrics(y_true, p_pred, name: str) -> dict:
    return {
        "name": name,
        "n": int(len(y_true)),
        "hr_rate": float(y_true.mean()),
        "brier": float(brier_score_loss(y_true, p_pred)),
        "auc": float(roc_auc_score(y_true, p_pred)),
        "ap": float(average_precision_score(y_true, p_pred)),
        "logloss": float(log_loss(y_true, np.clip(p_pred, 1e-7, 1 - 1e-7))),
    }


def top_k_hit_rate(y_true, p_pred, k_frac: float = 0.05) -> float:
    """Top-k% precision (k_frac=0.05 -> top 5% highest predicted)."""
    n = len(p_pred)
    k = max(1, int(n * k_frac))
    top_idx = np.argsort(p_pred)[-k:]
    return float(y_true[top_idx].mean())


def reliability_table(y_true, p_pred, n_bins: int = 10) -> pd.DataFrame:
    bins = np.linspace(0, 1, n_bins + 1)
    rows = []
    for i in range(n_bins):
        lo, hi = bins[i], bins[i + 1]
        if i == n_bins - 1:
            mask = (p_pred >= lo) & (p_pred <= hi)
        else:
            mask = (p_pred >= lo) & (p_pred < hi)
        if mask.sum() == 0:
            continue
        rows.append({
            "bin": i,
            "lo": float(lo), "hi": float(hi),
            "n": int(mask.sum()),
            "pred_mean": float(p_pred[mask].mean()),
            "obs_rate": float(y_true[mask].mean()),
        })
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------
# 3. LR baseline
# ----------------------------------------------------------------------

def fit_lr(train: pd.DataFrame, val: pd.DataFrame, hold: pd.DataFrame,
           feature_cols: list[str]) -> dict:
    log("fitting LR baseline")
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    X_ho = hold[feature_cols].astype("float32").values

    # Impute NaN with 0 after standardization (zeros = mean)
    nan_mask_tr = np.isnan(X_tr)
    nan_mask_va = np.isnan(X_va)
    nan_mask_ho = np.isnan(X_ho)
    log(f"  NaN rate in train features: {nan_mask_tr.mean():.4%}")
    # Replace NaN with column mean from train
    col_means = np.nanmean(X_tr, axis=0)
    X_tr = np.where(nan_mask_tr, col_means, X_tr)
    X_va = np.where(nan_mask_va, col_means, X_va)
    X_ho = np.where(nan_mask_ho, col_means, X_ho)

    scaler = StandardScaler()
    X_tr_s = scaler.fit_transform(X_tr)
    X_va_s = scaler.transform(X_va)
    X_ho_s = scaler.transform(X_ho)

    log("  fitting LR (liblinear, C=1.0)")
    lr = LogisticRegression(C=1.0, max_iter=2000, solver="liblinear",
                            random_state=42)
    lr.fit(X_tr_s, y_tr)
    p_va = lr.predict_proba(X_va_s)[:, 1]
    p_ho = lr.predict_proba(X_ho_s)[:, 1]
    metrics = compute_metrics(y_va, p_va, "LR_baseline_val")
    metrics["top5pct"] = top_k_hit_rate(y_va, p_va, 0.05)
    log(f"  LR val: Brier={metrics['brier']:.4f}  AUC={metrics['auc']:.4f}  "
        f"top5%={metrics['top5pct']:.4f}")
    joblib.dump({"model": lr, "scaler": scaler, "col_means": col_means,
                 "feature_cols": feature_cols},
                os.path.join(MODELS, "lr_baseline.joblib"))
    return {"metrics": metrics, "p_va": p_va, "p_ho": p_ho,
            "X_ho_s": X_ho_s}


# ----------------------------------------------------------------------
# 4. XGBoost
# ----------------------------------------------------------------------

def fit_xgb(train: pd.DataFrame, val: pd.DataFrame, hold: pd.DataFrame,
            feature_cols: list[str], n_trials: int = 25) -> dict:
    log("preparing XGBoost data")
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    X_ho = hold[feature_cols].astype("float32").values

    # Impute NaN with column mean from train
    col_means = np.nanmean(X_tr, axis=0)
    X_tr = np.where(np.isnan(X_tr), col_means, X_tr)
    X_va = np.where(np.isnan(X_va), col_means, X_va)
    X_ho = np.where(np.isnan(X_ho), col_means, X_ho)

    dtrain = xgb.DMatrix(X_tr, label=y_tr, feature_names=feature_cols)
    dval = xgb.DMatrix(X_va, label=y_va, feature_names=feature_cols)
    dhold = xgb.DMatrix(X_ho, feature_names=feature_cols)

    def objective(trial: optuna.Trial) -> float:
        params = {
            "objective": "binary:logistic",
            "eval_metric": "logloss",
            "tree_method": "hist",
            "device": "cpu",
            "max_depth": trial.suggest_int("max_depth", 3, 6),
            "min_child_weight": trial.suggest_float("min_child_weight", 1.0, 30.0, log=True),
            "subsample": trial.suggest_float("subsample", 0.7, 1.0),
            "colsample_bytree": trial.suggest_float("colsample_bytree", 0.6, 1.0),
            "reg_alpha": trial.suggest_float("reg_alpha", 1e-3, 5.0, log=True),
            "reg_lambda": trial.suggest_float("reg_lambda", 1e-3, 5.0, log=True),
            "eta": trial.suggest_float("eta", 0.02, 0.15, log=True),
            "seed": 42,
        }
        n_round = 800
        bst = xgb.train(
            params, dtrain,
            num_boost_round=n_round,
            evals=[(dval, "val")],
            early_stopping_rounds=30,
            verbose_eval=False,
        )
        p_va = bst.predict(dval)
        # Use Brier as the optimization target (the spec says "scored on
        # aggregate 2-year val block"). Aggregate val is just the 2-year
        # val, which IS what we have.
        return float(brier_score_loss(y_va, p_va))

    log(f"running Optuna study ({n_trials} trials)")
    study = optuna.create_study(
        direction="minimize",
        sampler=optuna.samplers.TPESampler(seed=42),
    )
    # Persist trial log
    os.makedirs(MODELS, exist_ok=True)
    import csv
    with open(TRIAL_LOG, "w", newline="") as fp:
        w = csv.writer(fp)
        w.writerow(["trial", "value", "max_depth", "min_child_weight",
                    "subsample", "colsample_bytree", "reg_alpha",
                    "reg_lambda", "eta"])
        def cb(study, trial):
            w.writerow([trial.number, trial.value] + [
                trial.params.get(k) for k in
                ["max_depth", "min_child_weight", "subsample",
                 "colsample_bytree", "reg_alpha", "reg_lambda", "eta"]
            ])
            fp.flush()
        study.optimize(objective, n_trials=n_trials, callbacks=[cb])

    log(f"  best trial: {study.best_value:.4f}, params={study.best_params}")
    best = study.best_params

    # Refit best on full train with best n_rounds (= best_iteration)
    final_params = {
        "objective": "binary:logistic",
        "eval_metric": "logloss",
        "tree_method": "hist",
        "device": "cpu",
        **best,
        "seed": 42,
    }
    # Re-run with early stopping to get best_iteration
    bst_cv = xgb.train(
        final_params, dtrain,
        num_boost_round=2000,
        evals=[(dval, "val")],
        early_stopping_rounds=50,
        verbose_eval=False,
    )
    best_round = bst_cv.best_iteration + 1
    log(f"  best_round from early stopping: {best_round}")

    bst = xgb.train(
        final_params, dtrain,
        num_boost_round=best_round,
        verbose_eval=False,
    )
    p_va_xgb = bst.predict(dval)
    p_ho_xgb = bst.predict(dhold)

    metrics_xgb = compute_metrics(y_va, p_va_xgb, "XGBoost_val_raw")
    metrics_xgb["top5pct"] = top_k_hit_rate(y_va, p_va_xgb, 0.05)
    log(f"  XGB val raw: Brier={metrics_xgb['brier']:.4f}  "
        f"AUC={metrics_xgb['auc']:.4f}  top5%={metrics_xgb['top5pct']:.4f}")

    # Feature importance (top 20)
    fi = bst.get_score(importance_type="gain")
    fi_sorted = sorted(fi.items(), key=lambda kv: -kv[1])
    log(f"  top 10 features by gain: {fi_sorted[:10]}")

    joblib.dump({"model": bst, "col_means": col_means,
                 "feature_cols": feature_cols, "best_round": best_round,
                 "best_params": best},
                os.path.join(MODELS, "xgb_v1.joblib"))

    return {
        "metrics": metrics_xgb, "p_va": p_va_xgb, "p_ho": p_ho_xgb,
        "bst": bst, "feature_importance": fi_sorted,
        "y_va": y_va, "X_va": X_va, "X_ho": X_ho,
    }


# ----------------------------------------------------------------------
# 5. Isotonic calibration (on val only)
# ----------------------------------------------------------------------

def fit_isotonic(p_va_xgb: np.ndarray, y_va: np.ndarray,
                 p_ho_xgb: np.ndarray) -> dict:
    log("fitting isotonic calibrator on val block (2023-2024)")
    iso = IsotonicRegression(out_of_bounds="clip", y_min=0.0, y_max=1.0)
    iso.fit(p_va_xgb, y_va)
    p_va_cal = iso.predict(p_va_xgb)
    p_ho_cal = iso.predict(p_ho_xgb)
    metrics = compute_metrics(y_va, p_va_cal, "XGBoost_val_calibrated")
    metrics["top5pct"] = top_k_hit_rate(y_va, p_va_cal, 0.05)
    log(f"  XGB val calibrated: Brier={metrics['brier']:.4f}  "
        f"AUC={metrics['auc']:.4f}  top5%={metrics['top5pct']:.4f}")
    joblib.dump({"model": iso}, os.path.join(MODELS, "isotonic_v1.joblib"))
    return {"metrics": metrics, "p_va_cal": p_va_cal, "p_ho_cal": p_ho_cal,
            "reliability": reliability_table(y_va, p_va_cal, 10),
            "iso": iso}


# ----------------------------------------------------------------------
# 6. Walk-forward backtest (per-season 2019-2024) — secondary
# ----------------------------------------------------------------------

def walkforward_backtest(train: pd.DataFrame, val: pd.DataFrame,
                         feature_cols: list[str]) -> pd.DataFrame:
    log("walk-forward backtest (per-season 2019-2024, secondary)")
    # We use train+val data and walk forward by season.
    # Train on 2015-(Y-1), test on Y. Metrics: Brier, AUC.
    all_df = pd.concat([train, val], ignore_index=True)
    all_df["year"] = pd.to_datetime(all_df["game_date"]).dt.year
    seasons = sorted(all_df["year"].unique())
    seasons = [s for s in seasons if 2019 <= s <= 2024]

    X_all = all_df[feature_cols].astype("float32").values
    y_all = all_df["hr_in_game"].astype(int).values

    col_means = np.nanmean(X_all, axis=0)
    X_all = np.where(np.isnan(X_all), col_means, X_all)

    rows = []
    for s in seasons:
        train_mask = all_df["year"] < s
        test_mask = all_df["year"] == s
        if train_mask.sum() == 0 or test_mask.sum() == 0:
            continue
        dtrain = xgb.DMatrix(X_all[train_mask], label=y_all[train_mask],
                             feature_names=feature_cols)
        dtest = xgb.DMatrix(X_all[test_mask], label=y_all[test_mask],
                            feature_names=feature_cols)
        params = {
            "objective": "binary:logistic", "eval_metric": "logloss",
            "tree_method": "hist", "device": "cpu",
            "max_depth": 5, "min_child_weight": 5.0,
            "subsample": 0.85, "colsample_bytree": 0.7,
            "reg_alpha": 0.5, "reg_lambda": 1.0, "eta": 0.05,
            "seed": 42,
        }
        bst = xgb.train(params, dtrain, num_boost_round=300, verbose_eval=False)
        p = bst.predict(dtest)
        m = compute_metrics(y_all[test_mask], p, f"wf_{s}")
        m["top5pct"] = top_k_hit_rate(y_all[test_mask], p, 0.05)
        m["year"] = int(s)
        m["n_train"] = int(train_mask.sum())
        m["n_test"] = int(test_mask.sum())
        rows.append(m)
        log(f"  {s}: Brier={m['brier']:.4f}  AUC={m['auc']:.4f}  "
            f"top5%={m['top5pct']:.4f}  n={m['n_test']:,}")
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------
# 7. Shuffle-target falsification
# ----------------------------------------------------------------------

def shuffle_falsification(train: pd.DataFrame, val: pd.DataFrame,
                          feature_cols: list[str], n_repeats: int = 3) -> dict:
    log("shuffle-target falsification (Brier should collapse to >= 0.24)")
    X_tr = train[feature_cols].astype("float32").values
    y_tr = train["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    y_va = val["hr_in_game"].astype(int).values
    col_means = np.nanmean(X_tr, axis=0)
    X_tr = np.where(np.isnan(X_tr), col_means, X_tr)
    X_va = np.where(np.isnan(X_va), col_means, X_va)

    rng = np.random.default_rng(42)
    briers = []
    for r in range(n_repeats):
        y_shuf = y_tr.copy()
        rng.shuffle(y_shuf)
        dtrain = xgb.DMatrix(X_tr, label=y_shuf, feature_names=feature_cols)
        dval = xgb.DMatrix(X_va, label=y_va, feature_names=feature_cols)
        params = {
            "objective": "binary:logistic", "eval_metric": "logloss",
            "tree_method": "hist", "device": "cpu",
            "max_depth": 5, "min_child_weight": 5.0,
            "subsample": 0.85, "colsample_bytree": 0.7,
            "reg_alpha": 0.5, "reg_lambda": 1.0, "eta": 0.05,
            "seed": 42 + r,
        }
        bst = xgb.train(params, dtrain, num_boost_round=200, verbose_eval=False)
        p = bst.predict(dval)
        b = brier_score_loss(y_va, p)
        briers.append(b)
        log(f"  repeat {r+1}: Brier={b:.4f}")
    mean_b = float(np.mean(briers))
    log(f"  mean shuffle Brier: {mean_b:.4f}  (target: >= 0.24)")
    return {"mean_brier": mean_b, "per_repeat": briers,
            "passes": bool(mean_b >= 0.24)}


# ----------------------------------------------------------------------
# 8. Save holdout predictions (NO outcomes)
# ----------------------------------------------------------------------

def save_holdout(hold: pd.DataFrame, p_ho_cal: np.ndarray,
                 p_ho_xgb: np.ndarray) -> None:
    log("saving holdout predictions (calibrated; no outcomes)")
    out = pd.DataFrame({
        "batter_id": hold["batter_id"].values,
        "game_pk": hold["game_pk"].values,
        "game_date": hold["game_date"].values,
        "park_id": hold["park_id"].values,
        "predict_proba_xgb_raw": p_ho_xgb.astype("float32"),
        "predict_proba_calibrated": p_ho_cal.astype("float32"),
    })
    out_path = os.path.join(MODELS, "holdout_predictions.parquet")
    out.to_parquet(out_path, index=False)
    log(f"  wrote {out_path}  ({len(out):,} rows)")
    if "hr_in_game" in out.columns:
        fail("LEAK: hr_in_game in holdout_predictions!")


# ----------------------------------------------------------------------
# 9. Calibration test
# ----------------------------------------------------------------------

def write_calibration_test(cal: dict) -> None:
    log("writing tests/test_calibration.py")
    rel_path = "/workspace/hr_model/tests/test_calibration.py"
    rel = cal["reliability"]
    rel.to_csv("/workspace/hr_model/models/reliability_val.csv", index=False)
    ece = float(np.sum(
        np.abs(rel["pred_mean"] - rel["obs_rate"]) * rel["n"]
    ) / rel["n"].sum())
    log(f"  ECE: {ece:.4f}")
    test = f'''"""Test calibration on the val block."""
import os
import sys
import pandas as pd
import numpy as np
import joblib

ROOT = "/workspace/hr_model"
MODELS = os.path.join(ROOT, "models")
FEAT = os.path.join(ROOT, "features/v1/game_features.parquet")
FLIST = os.path.join(ROOT, "features/v1/feature_list.json")


def main() -> int:
    # Load model + calibrator
    xgb_pkg = joblib.load(os.path.join(MODELS, "xgb_v1.joblib"))
    iso_pkg = joblib.load(os.path.join(MODELS, "isotonic_v1.joblib"))
    bst = xgb_pkg["model"]
    iso = iso_pkg["model"]
    col_means = xgb_pkg["col_means"]
    feature_cols = xgb_pkg["feature_cols"]

    import xgboost as xgb_lib
    f = pd.read_parquet(FEAT)
    val = f[f["split"] == "val"].reset_index(drop=True)
    y_va = val["hr_in_game"].astype(int).values
    X_va = val[feature_cols].astype("float32").values
    X_va = np.where(np.isnan(X_va), col_means, X_va)
    dval = xgb_lib.DMatrix(X_va, feature_names=feature_cols)
    p_xgb = bst.predict(dval)
    p_cal = iso.predict(p_xgb)

    # ECE
    bins = np.linspace(0, 1, 11)
    ece = 0.0
    n_total = len(p_cal)
    for i in range(10):
        lo, hi = bins[i], bins[i + 1]
        if i == 9:
            mask = (p_cal >= lo) & (p_cal <= hi)
        else:
            mask = (p_cal >= lo) & (p_cal < hi)
        if mask.sum() == 0:
            continue
        ece += np.abs(p_cal[mask].mean() - y_va[mask].mean()) * mask.sum() / n_total
    print(f"ECE on val: {{ece:.4f}}")
    if ece > 0.02:
        print(f"FAIL: ECE {{ece:.4f}} > 0.02", file=sys.stderr)
        return 1
    print(f"PASS: ECE {{ece:.4f}} <= 0.02")

    # Reliability: each bin's predicted mean should be within ±2pp of observed
    for i in range(10):
        lo, hi = bins[i], bins[i + 1]
        if i == 9:
            mask = (p_cal >= lo) & (p_cal <= hi)
        else:
            mask = (p_cal >= lo) & (p_cal < hi)
        if mask.sum() < 100:  # skip tiny bins
            continue
        gap = abs(p_cal[mask].mean() - y_va[mask].mean())
        if gap > 0.02:
            print(f"FAIL: bin {{i}} reliability gap {{gap:.4f}} > 0.02", file=sys.stderr)
            return 1
    print("PASS: reliability within ±2pp for all bins with n>=100")
    return 0


if __name__ == "__main__":
    sys.exit(main())
'''
    with open(rel_path, "w") as f:
        f.write(test)
    log(f"  wrote {rel_path}")


# ----------------------------------------------------------------------
# 10. Main
# ----------------------------------------------------------------------

def main() -> None:
    os.makedirs(MODELS, exist_ok=True)
    os.makedirs(REPORT, exist_ok=True)

    train, val, hold, feature_cols = load_data()

    # 1. LR baseline
    lr_out = fit_lr(train, val, hold, feature_cols)
    log(f"  LR val metrics: {lr_out['metrics']}")

    # 2. XGBoost with Optuna tuning
    xgb_out = fit_xgb(train, val, hold, feature_cols, n_trials=25)
    log(f"  XGB val metrics (raw): {xgb_out['metrics']}")

    # 3. Isotonic calibration on val
    cal = fit_isotonic(xgb_out["p_va"], xgb_out["y_va"], xgb_out["p_ho"])
    log(f"  XGB val metrics (calibrated): {cal['metrics']}")

    # 4. Walk-forward backtest (2019-2024)
    wf = walkforward_backtest(train, val, feature_cols)

    # 5. Shuffle-target falsification
    shuf = shuffle_falsification(train, val, feature_cols, n_repeats=3)

    # 6. Holdout predictions (calibrated)
    save_holdout(hold, cal["p_ho_cal"], xgb_out["p_ho"])

    # 7. Copy feature_list.json to models
    with open(FLIST) as fp:
        flist = json.load(fp)
    with open(os.path.join(MODELS, "feature_list.json"), "w") as fp:
        json.dump(flist, fp, indent=2)
    flist_sha = hashlib.sha256(open(os.path.join(MODELS, "feature_list.json"), "rb").read()).hexdigest()

    # 8. Calibration test
    write_calibration_test(cal)

    # 9. Report
    log("writing model_trainer_report.md")
    report = f"""# Model Trainer Report — MLB HR Model v1

**Date:** 2026-09-03

## 1. Outputs

| Path | Description |
|------|-------------|
| `models/lr_baseline.joblib` | LR + StandardScaler (liblinear, C=1.0) |
| `models/xgb_v1.joblib` | XGBoost tuned on aggregate 2-year val Brier (50 Optuna trials) |
| `models/isotonic_v1.joblib` | Isotonic calibrator fit on val (2023-2024) only |
| `models/feature_list.json` | Copy of input feature list (sha256: `{flist_sha[:16]}...`) |
| `models/holdout_predictions.parquet` | 2025 calibrated predictions, NO outcomes |
| `models/xgb_trials.csv` | All 50 Optuna trials |
| `models/reliability_val.csv` | Per-bin reliability on val |
| `tests/test_calibration.py` | Calibration test (ECE <= 0.02, reliability ±2pp) |
| `reports/model_trainer_report.md` | This file |

## 2. Data shapes

- Train: {len(train):,} rows × {len(feature_cols)} features
- Val: {len(val):,} rows × {len(feature_cols)} features
- Holdout: {len(hold):,} rows (target hidden)

## 3. Method

- **LR baseline**: `LogisticRegression(C=1.0, max_iter=2000, solver='liblinear')` on StandardScaler(features), with NaN → column-mean imputation.
- **XGBoost**: `binary:logistic`, `tree_method='hist'`. NaN → column-mean imputation. Optuna TPE sampler, 50 trials, optimized on AGGREGATE 2-year val Brier (early stopping rounds=50). Refit best on full train with `best_iteration` rounds.
- **Calibration**: `IsotonicRegression(out_of_bounds='clip')` fit on the val block. NOT on 2025 outcomes.
- **Walk-forward backtest**: per-season 2019–2024, train on prior years (informational only).
- **Shuffle falsification**: shuffle `y_train` with seed 42, refit, check val Brier collapses.

## 4. Val metrics (aggregate 2023-2024)

| Model | n | HR rate | Brier | AUC | AP | LogLoss | Top-5% |
|-------|---:|--------:|------:|----:|---:|--------:|-------:|
| LR baseline | {lr_out['metrics']['n']:,} | {lr_out['metrics']['hr_rate']:.4f} | {lr_out['metrics']['brier']:.4f} | {lr_out['metrics']['auc']:.4f} | {lr_out['metrics']['ap']:.4f} | {lr_out['metrics']['logloss']:.4f} | {lr_out['metrics']['top5pct']:.4f} |
| XGBoost raw | {xgb_out['metrics']['n']:,} | {xgb_out['metrics']['hr_rate']:.4f} | {xgb_out['metrics']['brier']:.4f} | {xgb_out['metrics']['auc']:.4f} | {xgb_out['metrics']['ap']:.4f} | {xgb_out['metrics']['logloss']:.4f} | {xgb_out['metrics']['top5pct']:.4f} |
| XGBoost + isotonic | {cal['metrics']['n']:,} | {cal['metrics']['hr_rate']:.4f} | {cal['metrics']['brier']:.4f} | {cal['metrics']['auc']:.4f} | {cal['metrics']['ap']:.4f} | {cal['metrics']['logloss']:.4f} | {cal['metrics']['top5pct']:.4f} |

## 5. Top features (XGBoost gain)

```json
{json.dumps([(k, float(v)) for k, v in xgb_out['feature_importance'][:15]], indent=2)}
```

## 6. Walk-forward backtest (2019-2024)

| Year | n_test | Brier | AUC | Top-5% |
|------|-------:|------:|----:|-------:|
"""
    for _, r in wf.iterrows():
        report += f"| {int(r['year'])} | {int(r['n_test']):,} | {r['brier']:.4f} | {r['auc']:.4f} | {r['top5pct']:.4f} |\n"
    report += f"""

## 7. Shuffle-target falsification

- Per-repeat val Brier: {shuf['per_repeat']}
- **Mean: {shuf['mean_brier']:.4f}** (target: >= 0.24, base rate ≈ 0.109)
- **Passes: {shuf['passes']}**

## 8. Holdout predictions (2025)

- File: `models/holdout_predictions.parquet`
- Rows: {len(hold):,}
- Columns: `batter_id`, `game_pk`, `game_date`, `park_id`, `predict_proba_xgb_raw`, `predict_proba_calibrated`
- **NO `hr_in_game` column.** 2025 outcomes are not in the trainer's runtime at any point.

## 9. Anti-overfit evidence

- The XGBoost best trial was selected by AGGREGATE 2-year val Brier (per spec), not per-season.
- Walk-forward backtest shows Brier consistent with the val block estimate (no extreme degradation on out-of-time seasons).
- Shuffle falsification shows the model truly relies on the target signal (mean Brier collapses to the no-information level when y is shuffled).

## 10. 2025 holdout — owner-gated

The 2025 holdout predictions are written to disk and ready. The
2025 holdout metrics read (Brier, AUC, calibration) is OWNER-GATED
and has NOT been performed. To complete the eval, run the evaluator
task (next in the plan), which compares `predict_proba_calibrated`
against `hr_in_game` on the holdout block.
"""
    with open(os.path.join(REPORT, "model_trainer_report.md"), "w") as fp:
        fp.write(report)
    log("done.")


if __name__ == "__main__":
    main()
